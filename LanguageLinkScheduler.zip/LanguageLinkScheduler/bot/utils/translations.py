import discord
from googletrans import Translator
import asyncio

# Initialize translator
translator = Translator()

# Language codes and names mapping
LANGUAGES = {
    'af': 'Afrikaans', 'sq': 'Albanian', 'am': 'Amharic', 'ar': 'Arabic',
    'hy': 'Armenian', 'az': 'Azerbaijani', 'eu': 'Basque', 'be': 'Belarusian',
    'bn': 'Bengali', 'bs': 'Bosnian', 'bg': 'Bulgarian', 'ca': 'Catalan',
    'ceb': 'Cebuano', 'ny': 'Chichewa', 'zh': 'Chinese', 'co': 'Corsican',
    'hr': 'Croatian', 'cs': 'Czech', 'da': 'Danish', 'nl': 'Dutch',
    'en': 'English', 'eo': 'Esperanto', 'et': 'Estonian', 'tl': 'Filipino',
    'fi': 'Finnish', 'fr': 'French', 'fy': 'Frisian', 'gl': 'Galician',
    'ka': 'Georgian', 'de': 'German', 'el': 'Greek', 'gu': 'Gujarati',
    'ht': 'Haitian Creole', 'ha': 'Hausa', 'haw': 'Hawaiian', 'he': 'Hebrew',
    'hi': 'Hindi', 'hmn': 'Hmong', 'hu': 'Hungarian', 'is': 'Icelandic',
    'ig': 'Igbo', 'id': 'Indonesian', 'ga': 'Irish', 'it': 'Italian',
    'ja': 'Japanese', 'jw': 'Javanese', 'kn': 'Kannada', 'kk': 'Kazakh',
    'km': 'Khmer', 'ko': 'Korean', 'ku': 'Kurdish', 'ky': 'Kyrgyz',
    'lo': 'Lao', 'la': 'Latin', 'lv': 'Latvian', 'lt': 'Lithuanian',
    'lb': 'Luxembourgish', 'mk': 'Macedonian', 'mg': 'Malagasy', 'ms': 'Malay',
    'ml': 'Malayalam', 'mt': 'Maltese', 'mi': 'Maori', 'mr': 'Marathi',
    'mn': 'Mongolian', 'my': 'Myanmar', 'ne': 'Nepali', 'no': 'Norwegian',
    'ps': 'Pashto', 'fa': 'Persian', 'pl': 'Polish', 'pt': 'Portuguese',
    'pa': 'Punjabi', 'ro': 'Romanian', 'ru': 'Russian', 'sm': 'Samoan',
    'gd': 'Scots Gaelic', 'sr': 'Serbian', 'st': 'Sesotho', 'sn': 'Shona',
    'sd': 'Sindhi', 'si': 'Sinhala', 'sk': 'Slovak', 'sl': 'Slovenian',
    'so': 'Somali', 'es': 'Spanish', 'su': 'Sundanese', 'sw': 'Swahili',
    'sv': 'Swedish', 'tg': 'Tajik', 'ta': 'Tamil', 'te': 'Telugu',
    'th': 'Thai', 'tr': 'Turkish', 'uk': 'Ukrainian', 'ur': 'Urdu',
    'uz': 'Uzbek', 'vi': 'Vietnamese', 'cy': 'Welsh', 'xh': 'Xhosa',
    'yi': 'Yiddish', 'yo': 'Yoruba', 'zu': 'Zulu'
}

async def translate_text(interaction: discord.Interaction, text: str, target_lang: str):
    """Translate text to target language"""
    try:
        # Validate target language
        target_lang = target_lang.lower()
        if target_lang not in LANGUAGES:
            # Try to find language by name
            lang_by_name = {name.lower(): code for code, name in LANGUAGES.items()}
            if target_lang in lang_by_name:
                target_lang = lang_by_name[target_lang]
            else:
                await interaction.response.send_message(
                    f"❌ Unsupported language: `{target_lang}`\n"
                    f"Use `/translate help` to see supported languages.",
                    ephemeral=True
                )
                return
        
        # Check text length
        if len(text) > 1000:
            await interaction.response.send_message(
                "❌ Text is too long! Maximum 1000 characters allowed.",
                ephemeral=True
            )
            return
        
        # Show typing indicator
        await interaction.response.defer()
        
        # Perform translation
        try:
            result = translator.translate(text, dest=target_lang)
            source_lang = result.src
            translated_text = result.text
            confidence = getattr(result, 'confidence', None)
            
            # Create embed
            embed = discord.Embed(
                title="🌍 Translation Result",
                color=0x3498db
            )
            
            embed.add_field(
                name=f"📝 Original ({LANGUAGES.get(source_lang, source_lang).title()})",
                value=f"```{text}```",
                inline=False
            )
            
            embed.add_field(
                name=f"🔄 Translation ({LANGUAGES.get(target_lang, target_lang).title()})",
                value=f"```{translated_text}```",
                inline=False
            )
            
            # Add confidence if available
            if confidence:
                embed.add_field(
                    name="📊 Confidence",
                    value=f"{confidence * 100:.1f}%",
                    inline=True
                )
            
            embed.add_field(
                name="🔗 Language Codes",
                value=f"{source_lang} → {target_lang}",
                inline=True
            )
            
            embed.set_footer(text=f"Translation by {interaction.user.display_name} • Powered by Google Translate")
            
            await interaction.followup.send(embed=embed)
            
        except Exception as translation_error:
            if "Unable to detect" in str(translation_error):
                await interaction.followup.send(
                    "❌ Unable to detect the source language. Please check your text.",
                    ephemeral=True
                )
            else:
                await interaction.followup.send(
                    f"❌ Translation failed: {str(translation_error)}",
                    ephemeral=True
                )
        
    except Exception as e:
        await interaction.followup.send(
            "❌ An error occurred during translation. Please try again!",
            ephemeral=True
        )
        print(f"Translation error: {e}")

async def show_language_help(interaction: discord.Interaction):
    """Show supported languages"""
    try:
        # Popular languages
        popular_langs = {
            'en': 'English', 'es': 'Spanish', 'fr': 'French', 'de': 'German',
            'it': 'Italian', 'pt': 'Portuguese', 'ru': 'Russian', 'ja': 'Japanese',
            'ko': 'Korean', 'zh': 'Chinese', 'ar': 'Arabic', 'hi': 'Hindi',
            'tr': 'Turkish', 'pl': 'Polish', 'nl': 'Dutch', 'sv': 'Swedish'
        }
        
        embed = discord.Embed(
            title="🌍 Translation Help",
            description="How to use the translation feature",
            color=0x2ecc71
        )
        
        embed.add_field(
            name="📝 Usage",
            value="```/translate <text> <target_language>```",
            inline=False
        )
        
        embed.add_field(
            name="💡 Examples",
            value="```/translate Hello World es\n/translate ¡Hola Mundo! en\n/translate Bonjour le monde de```",
            inline=False
        )
        
        # Popular language codes
        popular_list = []
        for code, name in popular_langs.items():
            popular_list.append(f"`{code}` - {name}")
        
        embed.add_field(
            name="🌟 Popular Languages",
            value="\n".join(popular_list[:8]),
            inline=True
        )
        
        embed.add_field(
            name="🌟 More Popular Languages",
            value="\n".join(popular_list[8:]),
            inline=True
        )
        
        embed.add_field(
            name="📚 All Languages",
            value=f"**{len(LANGUAGES)}** languages supported!\n[View full list](https://cloud.google.com/translate/docs/languages)",
            inline=False
        )
        
        embed.add_field(
            name="🔍 Auto-Detection",
            value="The source language is automatically detected!",
            inline=True
        )
        
        embed.add_field(
            name="📏 Limits",
            value="Maximum 1000 characters per translation",
            inline=True
        )
        
        embed.add_field(
            name="⚡ Tips",
            value="• Use language codes (e.g., `es`, `fr`, `de`)\n• You can also use full language names\n• Shorter texts translate better",
            inline=False
        )
        
        embed.set_footer(text="Powered by Google Translate")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ Error showing translation help!",
            ephemeral=True
        )
        print(f"Translation help error: {e}")

async def detect_language(interaction: discord.Interaction, text: str):
    """Detect the language of given text"""
    try:
        if len(text) > 500:
            await interaction.response.send_message(
                "❌ Text is too long for language detection! Maximum 500 characters.",
                ephemeral=True
            )
            return
        
        await interaction.response.defer()
        
        try:
            detection = translator.detect(text)
            lang_code = detection.lang
            confidence = detection.confidence
            lang_name = LANGUAGES.get(lang_code, lang_code)
            
            embed = discord.Embed(
                title="🔍 Language Detection",
                color=0x9b59b6
            )
            
            embed.add_field(
                name="📝 Text Sample",
                value=f"```{text[:200]}{'...' if len(text) > 200 else ''}```",
                inline=False
            )
            
            embed.add_field(
                name="🌍 Detected Language",
                value=f"**{lang_name}** (`{lang_code}`)",
                inline=True
            )
            
            embed.add_field(
                name="📊 Confidence",
                value=f"**{confidence * 100:.1f}%**",
                inline=True
            )
            
            # Add confidence indicator
            if confidence > 0.9:
                embed.add_field(
                    name="✅ Reliability",
                    value="Very High",
                    inline=True
                )
                embed.color = 0x2ecc71
            elif confidence > 0.7:
                embed.add_field(
                    name="⚠️ Reliability",
                    value="Good",
                    inline=True
                )
                embed.color = 0xf39c12
            else:
                embed.add_field(
                    name="❌ Reliability",
                    value="Low - Mixed languages?",
                    inline=True
                )
                embed.color = 0xe74c3c
            
            embed.set_footer(text=f"Detection by {interaction.user.display_name}")
            
            await interaction.followup.send(embed=embed)
            
        except Exception as detection_error:
            await interaction.followup.send(
                f"❌ Language detection failed: {str(detection_error)}",
                ephemeral=True
            )
        
    except Exception as e:
        await interaction.followup.send(
            "❌ An error occurred during language detection!",
            ephemeral=True
        )
        print(f"Language detection error: {e}")

# Extended translate command with help
async def translate_command_handler(interaction: discord.Interaction, text: str, target_lang: str):
    """Main translation command handler"""
    if text.lower() == "help":
        await show_language_help(interaction)
    elif text.lower().startswith("detect:"):
        detect_text = text[7:].strip()
        await detect_language(interaction, detect_text)
    else:
        await translate_text(interaction, text, target_lang)
