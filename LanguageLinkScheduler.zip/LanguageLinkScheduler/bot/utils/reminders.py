import discord
import asyncio
import sqlite3
from datetime import datetime, timedelta
import re

DATABASE_PATH = "bot_data.db"

def parse_time_string(time_str: str) -> int:
    """Parse time string and return seconds"""
    time_str = time_str.lower().strip()
    
    # Pattern to match time formats like "5m", "2h", "1d", "30s"
    pattern = r'^(\d+)([smhd])$'
    match = re.match(pattern, time_str)
    
    if not match:
        return None
    
    amount, unit = match.groups()
    amount = int(amount)
    
    multipliers = {
        's': 1,           # seconds
        'm': 60,          # minutes
        'h': 3600,        # hours
        'd': 86400        # days
    }
    
    return amount * multipliers[unit]

def format_time_remaining(seconds: int) -> str:
    """Format seconds into human readable time"""
    if seconds < 60:
        return f"{seconds}s"
    elif seconds < 3600:
        minutes = seconds // 60
        return f"{minutes}m"
    elif seconds < 86400:
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        return f"{hours}h {minutes}m" if minutes > 0 else f"{hours}h"
    else:
        days = seconds // 86400
        hours = (seconds % 86400) // 3600
        return f"{days}d {hours}h" if hours > 0 else f"{days}d"

async def set_reminder(interaction: discord.Interaction, time: str, message: str):
    """Set a reminder for the user"""
    try:
        user_id = str(interaction.user.id)
        
        # Parse time
        seconds = parse_time_string(time)
        if seconds is None:
            await interaction.response.send_message(
                "❌ Invalid time format! Use formats like:\n"
                "• `30s` (30 seconds)\n"
                "• `5m` (5 minutes)\n" 
                "• `2h` (2 hours)\n"
                "• `1d` (1 day)",
                ephemeral=True
            )
            return
        
        # Validate time limits
        if seconds < 10:
            await interaction.response.send_message(
                "❌ Minimum reminder time is 10 seconds!",
                ephemeral=True
            )
            return
        
        if seconds > 7 * 86400:  # 7 days
            await interaction.response.send_message(
                "❌ Maximum reminder time is 7 days!",
                ephemeral=True
            )
            return
        
        # Check message length
        if len(message) > 500:
            await interaction.response.send_message(
                "❌ Reminder message too long! Maximum 500 characters.",
                ephemeral=True
            )
            return
        
        # Calculate when to send reminder
        scheduled_time = datetime.now() + timedelta(seconds=seconds)
        
        # Save to database
        try:
            conn = sqlite3.connect(DATABASE_PATH)
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO reminders (user_id, message, scheduled_for)
                VALUES (?, ?, ?)
            """, (user_id, message, scheduled_time.isoformat()))
            
            reminder_id = cursor.lastrowid
            conn.commit()
            conn.close()
            
            # Create confirmation embed
            embed = discord.Embed(
                title="⏰ Reminder Set!",
                description="Your reminder has been scheduled successfully!",
                color=0x2ecc71
            )
            
            embed.add_field(
                name="💬 Message",
                value=f"```{message}```",
                inline=False
            )
            
            embed.add_field(
                name="⏱️ Time",
                value=f"In **{format_time_remaining(seconds)}**",
                inline=True
            )
            
            embed.add_field(
                name="📅 Scheduled For",
                value=f"<t:{int(scheduled_time.timestamp())}:F>",
                inline=True
            )
            
            embed.add_field(
                name="🔢 Reminder ID",
                value=f"`{reminder_id}`",
                inline=True
            )
            
            embed.add_field(
                name="💡 Note",
                value="I'll send you a DM when it's time!",
                inline=False
            )
            
            embed.set_footer(text=f"Reminder for {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except Exception as db_error:
            await interaction.response.send_message(
                "❌ Failed to save reminder to database!",
                ephemeral=True
            )
            print(f"Database error in set_reminder: {db_error}")
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while setting the reminder!",
            ephemeral=True
        )
        print(f"Reminder error: {e}")

async def list_reminders(interaction: discord.Interaction):
    """List user's active reminders"""
    try:
        user_id = str(interaction.user.id)
        
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, message, scheduled_for, created_at
            FROM reminders 
            WHERE user_id = ? AND completed = FALSE
            ORDER BY scheduled_for ASC
            LIMIT 10
        """, (user_id,))
        
        reminders = cursor.fetchall()
        conn.close()
        
        if not reminders:
            await interaction.response.send_message(
                "📅 You have no active reminders!\nUse `/reminder` to set one.",
                ephemeral=True
            )
            return
        
        embed = discord.Embed(
            title="⏰ Your Active Reminders",
            description=f"You have {len(reminders)} active reminder(s)",
            color=0x3498db
        )
        
        now = datetime.now()
        
        for reminder in reminders:
            reminder_id, message, scheduled_for_str, created_at = reminder
            scheduled_for = datetime.fromisoformat(scheduled_for_str)
            
            # Calculate time remaining
            time_diff = scheduled_for - now
            if time_diff.total_seconds() > 0:
                time_remaining = format_time_remaining(int(time_diff.total_seconds()))
                status = f"⏱️ In {time_remaining}"
            else:
                status = "🔴 Overdue"
            
            embed.add_field(
                name=f"🔔 Reminder #{reminder_id}",
                value=f"**Message:** {message[:100]}{'...' if len(message) > 100 else ''}\n"
                      f"**Time:** <t:{int(scheduled_for.timestamp())}:R>\n"
                      f"**Status:** {status}",
                inline=False
            )
        
        embed.add_field(
            name="💡 Tips",
            value="• Use `/reminder cancel <id>` to cancel a reminder\n• Reminders are sent via DM",
            inline=False
        )
        
        embed.set_footer(text=f"Reminders for {interaction.user.display_name}")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ Error retrieving reminders!",
            ephemeral=True
        )
        print(f"List reminders error: {e}")

async def cancel_reminder(interaction: discord.Interaction, reminder_id: int):
    """Cancel a specific reminder"""
    try:
        user_id = str(interaction.user.id)
        
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Check if reminder exists and belongs to user
        cursor.execute("""
            SELECT message, scheduled_for FROM reminders 
            WHERE id = ? AND user_id = ? AND completed = FALSE
        """, (reminder_id, user_id))
        
        reminder = cursor.fetchone()
        
        if not reminder:
            await interaction.response.send_message(
                f"❌ Reminder #{reminder_id} not found or already completed!",
                ephemeral=True
            )
            conn.close()
            return
        
        # Mark as completed (cancelled)
        cursor.execute("""
            UPDATE reminders 
            SET completed = TRUE 
            WHERE id = ? AND user_id = ?
        """, (reminder_id, user_id))
        
        conn.commit()
        conn.close()
        
        message, scheduled_for_str = reminder
        
        embed = discord.Embed(
            title="🗑️ Reminder Cancelled",
            description=f"Reminder #{reminder_id} has been cancelled.",
            color=0xe74c3c
        )
        
        embed.add_field(
            name="💬 Cancelled Message",
            value=f"```{message}```",
            inline=False
        )
        
        embed.add_field(
            name="📅 Was Scheduled For",
            value=f"<t:{int(datetime.fromisoformat(scheduled_for_str).timestamp())}:F>",
            inline=False
        )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ Error cancelling reminder!",
            ephemeral=True
        )
        print(f"Cancel reminder error: {e}")

async def reminder_loop(bot):
    """Background task to check and send reminders"""
    while True:
        try:
            await asyncio.sleep(30)  # Check every 30 seconds
            
            conn = sqlite3.connect(DATABASE_PATH)
            cursor = conn.cursor()
            
            # Get reminders that are due
            now = datetime.now()
            cursor.execute("""
                SELECT id, user_id, message, scheduled_for
                FROM reminders 
                WHERE completed = FALSE AND scheduled_for <= ?
            """, (now.isoformat(),))
            
            due_reminders = cursor.fetchall()
            
            for reminder in due_reminders:
                reminder_id, user_id, message, scheduled_for_str = reminder
                
                try:
                    # Get user
                    user = bot.get_user(int(user_id))
                    if user:
                        # Create reminder embed
                        embed = discord.Embed(
                            title="⏰ Reminder Alert!",
                            description="Your scheduled reminder is here!",
                            color=0xf39c12
                        )
                        
                        embed.add_field(
                            name="💬 Your Message",
                            value=f"```{message}```",
                            inline=False
                        )
                        
                        embed.add_field(
                            name="📅 Originally Scheduled",
                            value=f"<t:{int(datetime.fromisoformat(scheduled_for_str).timestamp())}:F>",
                            inline=False
                        )
                        
                        embed.add_field(
                            name="🔔 Reminder ID",
                            value=f"`#{reminder_id}`",
                            inline=True
                        )
                        
                        embed.set_footer(text="Reminder from your Discord bot")
                        
                        # Send DM
                        try:
                            await user.send(embed=embed)
                        except discord.Forbidden:
                            # If DM fails, we'll still mark as completed
                            print(f"Could not send reminder DM to user {user_id}")
                    
                    # Mark reminder as completed
                    cursor.execute(
                        "UPDATE reminders SET completed = TRUE WHERE id = ?",
                        (reminder_id,)
                    )
                    
                except Exception as send_error:
                    print(f"Error sending reminder {reminder_id}: {send_error}")
                    # Still mark as completed to avoid spam
                    cursor.execute(
                        "UPDATE reminders SET completed = TRUE WHERE id = ?",
                        (reminder_id,)
                    )
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            print(f"Reminder loop error: {e}")
            await asyncio.sleep(60)  # Wait longer on error

async def reminder_stats(interaction: discord.Interaction):
    """Show reminder statistics"""
    try:
        user_id = str(interaction.user.id)
        
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Get stats
        cursor.execute("""
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN completed = TRUE THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN completed = FALSE THEN 1 ELSE 0 END) as active
            FROM reminders 
            WHERE user_id = ?
        """, (user_id,))
        
        stats = cursor.fetchone()
        total, completed, active = stats if stats else (0, 0, 0)
        
        # Get next reminder
        cursor.execute("""
            SELECT message, scheduled_for
            FROM reminders 
            WHERE user_id = ? AND completed = FALSE
            ORDER BY scheduled_for ASC
            LIMIT 1
        """, (user_id,))
        
        next_reminder = cursor.fetchone()
        conn.close()
        
        embed = discord.Embed(
            title="📊 Reminder Statistics",
            color=0x9b59b6
        )
        
        embed.add_field(
            name="📈 Overall Stats",
            value=f"**Total:** {total}\n**Completed:** {completed}\n**Active:** {active}",
            inline=True
        )
        
        if next_reminder:
            message, scheduled_for_str = next_reminder
            scheduled_for = datetime.fromisoformat(scheduled_for_str)
            
            embed.add_field(
                name="⏰ Next Reminder",
                value=f"**Message:** {message[:50]}{'...' if len(message) > 50 else ''}\n"
                      f"**Time:** <t:{int(scheduled_for.timestamp())}:R>",
                inline=True
            )
        else:
            embed.add_field(
                name="⏰ Next Reminder",
                value="No active reminders",
                inline=True
            )
        
        # Calculate completion rate
        completion_rate = (completed / total * 100) if total > 0 else 0
        
        embed.add_field(
            name="🎯 Completion Rate",
            value=f"**{completion_rate:.1f}%**",
            inline=False
        )
        
        embed.set_footer(text=f"Statistics for {interaction.user.display_name}")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ Error retrieving reminder statistics!",
            ephemeral=True
        )
        print(f"Reminder stats error: {e}")
