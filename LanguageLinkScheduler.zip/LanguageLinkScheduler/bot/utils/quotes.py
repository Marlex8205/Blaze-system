import discord
import sqlite3
import random
from datetime import datetime

DATABASE_PATH = "bot_data.db"

async def random_quote(interaction: discord.Interaction):
    """Send a random inspirational quote"""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        cursor.execute("SELECT content, author FROM quotes ORDER BY RANDOM() LIMIT 1")
        quote_data = cursor.fetchone()
        conn.close()
        
        if not quote_data:
            await interaction.response.send_message(
                "📝 No quotes available! Add some quotes with `/addquote`",
                ephemeral=True
            )
            return
        
        content, author = quote_data
        
        # Create beautiful quote embed
        embed = discord.Embed(
            description=f"*\"{content}\"*",
            color=0x9b59b6
        )
        
        if author:
            embed.set_footer(text=f"— {author}")
        else:
            embed.set_footer(text="— Unknown")
        
        # Add decorative title
        embed.set_author(
            name="💭 Daily Inspiration",
            icon_url="https://cdn.discordapp.com/emojis/1234567890123456789.png"  # Optional: quote icon
        )
        
        # Add random inspirational emoji
        quote_emojis = ["✨", "🌟", "💫", "🎯", "🚀", "💡", "🌈", "🎪"]
        embed.title = f"{random.choice(quote_emojis)} Quote of the Moment"
        
        await interaction.response.send_message(embed=embed)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ Error retrieving quote!",
            ephemeral=True
        )
        print(f"Random quote error: {e}")

async def add_quote(interaction: discord.Interaction, content: str, author: str = None):
    """Add a new quote to the collection"""
    try:
        user_id = str(interaction.user.id)
        username = interaction.user.display_name
        
        # Validate content
        if len(content) < 10:
            await interaction.response.send_message(
                "❌ Quote is too short! Minimum 10 characters required.",
                ephemeral=True
            )
            return
        
        if len(content) > 500:
            await interaction.response.send_message(
                "❌ Quote is too long! Maximum 500 characters allowed.",
                ephemeral=True
            )
            return
        
        # Validate author if provided
        if author and len(author) > 100:
            await interaction.response.send_message(
                "❌ Author name is too long! Maximum 100 characters.",
                ephemeral=True
            )
            return
        
        # Check for duplicate quotes
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT id FROM quotes WHERE LOWER(content) = LOWER(?)",
            (content,)
        )
        
        if cursor.fetchone():
            await interaction.response.send_message(
                "❌ This quote already exists in the collection!",
                ephemeral=True
            )
            conn.close()
            return
        
        # Add quote to database
        cursor.execute("""
            INSERT INTO quotes (content, author, added_by)
            VALUES (?, ?, ?)
        """, (content, author, username))
        
        quote_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        # Create confirmation embed
        embed = discord.Embed(
            title="✅ Quote Added Successfully!",
            description="Your quote has been added to the collection.",
            color=0x2ecc71
        )
        
        embed.add_field(
            name="💬 Quote Content",
            value=f"*\"{content}\"*",
            inline=False
        )
        
        if author:
            embed.add_field(
                name="👤 Author",
                value=f"**{author}**",
                inline=True
            )
        
        embed.add_field(
            name="🔢 Quote ID",
            value=f"`#{quote_id}`",
            inline=True
        )
        
        embed.add_field(
            name="👥 Added By",
            value=f"{username}",
            inline=True
        )
        
        embed.add_field(
            name="💡 Tip",
            value="Use `/quote` to see random quotes from the collection!",
            inline=False
        )
        
        embed.set_footer(text="Thank you for contributing to our quote collection!")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ Error adding quote to collection!",
            ephemeral=True
        )
        print(f"Add quote error: {e}")

async def list_quotes(interaction: discord.Interaction, page: int = 1):
    """List quotes with pagination"""
    try:
        quotes_per_page = 5
        offset = (page - 1) * quotes_per_page
        
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Get total count
        cursor.execute("SELECT COUNT(*) FROM quotes")
        total_quotes = cursor.fetchone()[0]
        
        if total_quotes == 0:
            await interaction.response.send_message(
                "📝 No quotes in the collection yet! Add some with `/addquote`",
                ephemeral=True
            )
            return
        
        # Get quotes for current page
        cursor.execute("""
            SELECT id, content, author, added_by, added_at
            FROM quotes 
            ORDER BY added_at DESC 
            LIMIT ? OFFSET ?
        """, (quotes_per_page, offset))
        
        quotes = cursor.fetchall()
        conn.close()
        
        total_pages = (total_quotes + quotes_per_page - 1) // quotes_per_page
        
        embed = discord.Embed(
            title="📚 Quote Collection",
            description=f"Page {page} of {total_pages} • {total_quotes} total quotes",
            color=0x3498db
        )
        
        for quote in quotes:
            quote_id, content, author, added_by, added_at = quote
            
            # Truncate long quotes
            display_content = content[:150] + "..." if len(content) > 150 else content
            
            author_text = f"— {author}" if author else "— Unknown"
            
            embed.add_field(
                name=f"💭 Quote #{quote_id}",
                value=f"*\"{display_content}\"*\n{author_text}\n*Added by {added_by}*",
                inline=False
            )
        
        # Add navigation info
        if total_pages > 1:
            embed.add_field(
                name="📄 Navigation",
                value=f"Use `/quotes {page+1}` for next page" if page < total_pages else "This is the last page",
                inline=False
            )
        
        embed.set_footer(text=f"Quote collection • Page {page}/{total_pages}")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ Error retrieving quotes!",
            ephemeral=True
        )
        print(f"List quotes error: {e}")

async def search_quotes(interaction: discord.Interaction, search_term: str):
    """Search quotes by content or author"""
    try:
        if len(search_term) < 3:
            await interaction.response.send_message(
                "❌ Search term must be at least 3 characters long!",
                ephemeral=True
            )
            return
        
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, content, author, added_by
            FROM quotes 
            WHERE LOWER(content) LIKE LOWER(?) 
               OR LOWER(author) LIKE LOWER(?)
            ORDER BY added_at DESC
            LIMIT 10
        """, (f"%{search_term}%", f"%{search_term}%"))
        
        results = cursor.fetchall()
        conn.close()
        
        if not results:
            await interaction.response.send_message(
                f"🔍 No quotes found matching '{search_term}'",
                ephemeral=True
            )
            return
        
        embed = discord.Embed(
            title=f"🔍 Search Results for '{search_term}'",
            description=f"Found {len(results)} matching quote(s)",
            color=0xf39c12
        )
        
        for quote in results:
            quote_id, content, author, added_by = quote
            
            # Highlight search term (simple version)
            display_content = content[:200] + "..." if len(content) > 200 else content
            author_text = f"— {author}" if author else "— Unknown"
            
            embed.add_field(
                name=f"💭 Quote #{quote_id}",
                value=f"*\"{display_content}\"*\n{author_text}\n*Added by {added_by}*",
                inline=False
            )
        
        embed.set_footer(text=f"Search results for '{search_term}'")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ Error searching quotes!",
            ephemeral=True
        )
        print(f"Search quotes error: {e}")

async def delete_quote(interaction: discord.Interaction, quote_id: int):
    """Delete a quote (admin only or quote author)"""
    try:
        user_id = str(interaction.user.id)
        username = interaction.user.display_name
        
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Get quote details
        cursor.execute(
            "SELECT content, author, added_by FROM quotes WHERE id = ?",
            (quote_id,)
        )
        
        quote_data = cursor.fetchone()
        
        if not quote_data:
            await interaction.response.send_message(
                f"❌ Quote #{quote_id} not found!",
                ephemeral=True
            )
            conn.close()
            return
        
        content, author, added_by = quote_data
        
        # Check permissions (admin IDs should be defined in your main bot file)
        ADMIN_IDS = {"1292477169833869365", "1366437624377774182"}  # Replace with actual admin IDs
        
        if user_id not in ADMIN_IDS and username != added_by:
            await interaction.response.send_message(
                "❌ You can only delete quotes that you added!",
                ephemeral=True
            )
            conn.close()
            return
        
        # Delete the quote
        cursor.execute("DELETE FROM quotes WHERE id = ?", (quote_id,))
        conn.commit()
        conn.close()
        
        embed = discord.Embed(
            title="🗑️ Quote Deleted",
            description=f"Quote #{quote_id} has been removed from the collection.",
            color=0xe74c3c
        )
        
        embed.add_field(
            name="💬 Deleted Quote",
            value=f"*\"{content}\"*\n— {author if author else 'Unknown'}",
            inline=False
        )
        
        embed.add_field(
            name="👤 Originally Added By",
            value=added_by,
            inline=True
        )
        
        embed.add_field(
            name="🗑️ Deleted By",
            value=username,
            inline=True
        )
        
        embed.set_footer(text="Quote successfully removed from collection")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ Error deleting quote!",
            ephemeral=True
        )
        print(f"Delete quote error: {e}")

async def quote_stats(interaction: discord.Interaction):
    """Show quote collection statistics"""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Get total quotes
        cursor.execute("SELECT COUNT(*) FROM quotes")
        total_quotes = cursor.fetchone()[0]
        
        # Get top contributors
        cursor.execute("""
            SELECT added_by, COUNT(*) as count
            FROM quotes 
            GROUP BY added_by 
            ORDER BY count DESC 
            LIMIT 5
        """)
        top_contributors = cursor.fetchall()
        
        # Get quotes with and without authors
        cursor.execute("SELECT COUNT(*) FROM quotes WHERE author IS NOT NULL AND author != ''")
        quotes_with_authors = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM quotes WHERE author IS NULL OR author = ''")
        quotes_without_authors = cursor.fetchone()[0]
        
        # Get most recent quote
        cursor.execute("""
            SELECT content, author, added_by, added_at
            FROM quotes 
            ORDER BY added_at DESC 
            LIMIT 1
        """)
        recent_quote = cursor.fetchone()
        
        conn.close()
        
        embed = discord.Embed(
            title="📊 Quote Collection Statistics",
            color=0x9b59b6
        )
        
        embed.add_field(
            name="📚 Collection Size",
            value=f"**{total_quotes}** total quotes",
            inline=True
        )
        
        embed.add_field(
            name="👤 Authorship",
            value=f"**{quotes_with_authors}** with authors\n**{quotes_without_authors}** anonymous",
            inline=True
        )
        
        if top_contributors:
            contributors_text = "\n".join([
                f"**{name}:** {count} quotes" 
                for name, count in top_contributors[:3]
            ])
            embed.add_field(
                name="🏆 Top Contributors",
                value=contributors_text,
                inline=False
            )
        
        if recent_quote:
            content, author, added_by, added_at = recent_quote
            display_content = content[:100] + "..." if len(content) > 100 else content
            author_text = f"— {author}" if author else "— Unknown"
            
            embed.add_field(
                name="📅 Most Recent Quote",
                value=f"*\"{display_content}\"*\n{author_text}\n*Added by {added_by}*",
                inline=False
            )
        
        embed.add_field(
            name="💡 Fun Fact",
            value=f"That's enough quotes to inspire someone for {total_quotes // 365} years if you read one per day!" if total_quotes > 365 else "Keep adding quotes to build an amazing collection!",
            inline=False
        )
        
        embed.set_footer(text="Quote collection statistics")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ Error retrieving quote statistics!",
            ephemeral=True
        )
        print(f"Quote stats error: {e}")
