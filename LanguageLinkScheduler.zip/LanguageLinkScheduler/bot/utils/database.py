import sqlite3
import os
from datetime import datetime

DATABASE_PATH = "bot_data.db"

def init_db():
    """Initialize the database with required tables"""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Users table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                discord_id TEXT UNIQUE NOT NULL,
                username TEXT NOT NULL,
                coins INTEGER DEFAULT 1000,
                level INTEGER DEFAULT 1,
                experience INTEGER DEFAULT 0,
                games_played INTEGER DEFAULT 0,
                games_won INTEGER DEFAULT 0,
                last_daily TEXT,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Game statistics table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS game_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                game_name TEXT NOT NULL,
                played INTEGER DEFAULT 0,
                won INTEGER DEFAULT 0,
                total_score INTEGER DEFAULT 0,
                best_score INTEGER DEFAULT 0,
                last_played TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, game_name)
            )
        """)
        
        # Quotes table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS quotes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL,
                author TEXT,
                added_by TEXT NOT NULL,
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Reminders table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS reminders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                message TEXT NOT NULL,
                scheduled_for TIMESTAMP NOT NULL,
                completed BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Bot configuration table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS bot_config (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT UNIQUE NOT NULL,
                value TEXT NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Insert default quotes if none exist
        cursor.execute("SELECT COUNT(*) FROM quotes")
        quote_count = cursor.fetchone()[0]
        
        if quote_count == 0:
            default_quotes = [
                ("The only way to do great work is to love what you do.", "Steve Jobs", "System"),
                ("Life is what happens to you while you're busy making other plans.", "John Lennon", "System"),
                ("The future belongs to those who believe in the beauty of their dreams.", "Eleanor Roosevelt", "System"),
                ("It is during our darkest moments that we must focus to see the light.", "Aristotle", "System"),
                ("Success is not final, failure is not fatal: it is the courage to continue that counts.", "Winston Churchill", "System"),
                ("The only impossible journey is the one you never begin.", "Tony Robbins", "System"),
                ("In the middle of difficulty lies opportunity.", "Albert Einstein", "System"),
                ("Believe you can and you're halfway there.", "Theodore Roosevelt", "System"),
                ("The greatest glory in living lies not in never falling, but in rising every time we fall.", "Nelson Mandela", "System"),
                ("Don't watch the clock; do what it does. Keep going.", "Sam Levenson", "System")
            ]
            
            cursor.executemany(
                "INSERT INTO quotes (content, author, added_by) VALUES (?, ?, ?)",
                default_quotes
            )
        
        # Insert default bot configuration
        default_configs = [
            ("prefix", "!"),
            ("starting_coins", "1000"),
            ("daily_coins", "100"),
            ("level_up_bonus", "50"),
            ("economy_enabled", "true"),
            ("leaderboards_enabled", "true"),
            ("daily_rewards_enabled", "true")
        ]
        
        for key, value in default_configs:
            cursor.execute(
                "INSERT OR IGNORE INTO bot_config (key, value) VALUES (?, ?)",
                (key, value)
            )
        
        conn.commit()
        conn.close()
        print("✅ Database initialized successfully")
        
    except Exception as e:
        print(f"❌ Database initialization error: {e}")

def create_user(discord_id: str, username: str) -> bool:
    """Create a new user in the database"""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT OR IGNORE INTO users (discord_id, username) 
            VALUES (?, ?)
        """, (discord_id, username))
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error creating user {discord_id}: {e}")
        return False

def get_user(discord_id: str) -> dict:
    """Get user data from database"""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT * FROM users WHERE discord_id = ?",
            (discord_id,)
        )
        result = cursor.fetchone()
        conn.close()
        
        return dict(result) if result else None
    except Exception as e:
        print(f"Error getting user {discord_id}: {e}")
        return None

def update_user(discord_id: str, **kwargs) -> bool:
    """Update user data"""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Build dynamic update query
        fields = []
        values = []
        for key, value in kwargs.items():
            fields.append(f"{key} = ?")
            values.append(value)
        
        if not fields:
            return False
        
        values.append(discord_id)
        
        cursor.execute(
            f"UPDATE users SET {', '.join(fields)} WHERE discord_id = ?",
            values
        )
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error updating user {discord_id}: {e}")
        return False

def get_all_users() -> list:
    """Get all users from database"""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM users ORDER BY coins DESC")
        results = cursor.fetchall()
        conn.close()
        
        return [dict(row) for row in results]
    except Exception as e:
        print(f"Error getting all users: {e}")
        return []

def cleanup_old_data():
    """Clean up old reminders and other temporary data"""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Remove completed reminders older than 7 days
        cursor.execute("""
            DELETE FROM reminders 
            WHERE completed = TRUE 
            AND created_at < datetime('now', '-7 days')
        """)
        
        # Remove old game statistics (keep only last 1000 entries per user)
        cursor.execute("""
            DELETE FROM game_stats 
            WHERE id NOT IN (
                SELECT id FROM game_stats 
                ORDER BY last_played DESC 
                LIMIT 1000
            )
        """)
        
        conn.commit()
        conn.close()
        print("✅ Database cleanup completed")
        
    except Exception as e:
        print(f"❌ Database cleanup error: {e}")

def backup_database():
    """Create a backup of the database"""
    try:
        import shutil
        from datetime import datetime
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = f"backups/bot_data_backup_{timestamp}.db"
        
        # Create backups directory if it doesn't exist
        os.makedirs("backups", exist_ok=True)
        
        shutil.copy2(DATABASE_PATH, backup_path)
        print(f"✅ Database backed up to {backup_path}")
        
        # Keep only last 10 backups
        import glob
        backups = sorted(glob.glob("backups/bot_data_backup_*.db"))
        if len(backups) > 10:
            for old_backup in backups[:-10]:
                os.remove(old_backup)
                print(f"🗑️ Removed old backup: {old_backup}")
        
        return backup_path
    except Exception as e:
        print(f"❌ Database backup error: {e}")
        return None

def get_database_stats() -> dict:
    """Get database statistics"""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        stats = {}
        
        # User count
        cursor.execute("SELECT COUNT(*) FROM users")
        stats['total_users'] = cursor.fetchone()[0]
        
        # Total games played
        cursor.execute("SELECT SUM(games_played) FROM users")
        result = cursor.fetchone()[0]
        stats['total_games_played'] = result if result else 0
        
        # Total coins in circulation
        cursor.execute("SELECT SUM(coins) FROM users")
        result = cursor.fetchone()[0]
        stats['total_coins'] = result if result else 0
        
        # Quote count
        cursor.execute("SELECT COUNT(*) FROM quotes")
        stats['total_quotes'] = cursor.fetchone()[0]
        
        # Active reminders
        cursor.execute("SELECT COUNT(*) FROM reminders WHERE completed = FALSE")
        stats['active_reminders'] = cursor.fetchone()[0]
        
        # Database size
        size = os.path.getsize(DATABASE_PATH) if os.path.exists(DATABASE_PATH) else 0
        stats['database_size_mb'] = round(size / (1024 * 1024), 2)
        
        conn.close()
        return stats
        
    except Exception as e:
        print(f"Error getting database stats: {e}")
        return {}

if __name__ == "__main__":
    # Initialize database when run directly
    init_db()
