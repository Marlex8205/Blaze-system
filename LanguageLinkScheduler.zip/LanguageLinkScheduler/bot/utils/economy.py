import sqlite3
from typing import Optional, List, Tuple
import os

DATABASE_PATH = "bot_data.db"

def get_db_connection():
    """Get database connection"""
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def get_user_balance(user_id: str) -> int:
    """Get user's coin balance"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT coins FROM users WHERE discord_id = ?",
            (user_id,)
        )
        result = cursor.fetchone()
        conn.close()
        
        return result['coins'] if result else 0
    except Exception as e:
        print(f"Error getting balance for {user_id}: {e}")
        return 0

def update_coins(user_id: str, amount: int) -> bool:
    """Update user's coin balance"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get current balance
        current_balance = get_user_balance(user_id)
        new_balance = max(0, current_balance + amount)  # Prevent negative balance
        
        # Update balance
        cursor.execute(
            "UPDATE users SET coins = ? WHERE discord_id = ?",
            (new_balance, user_id)
        )
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error updating coins for {user_id}: {e}")
        return False

def update_game_stats(user_id: str, game_name: str, played: int = 0, won: int = 0, score: int = 0) -> bool:
    """Update user's game statistics"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if record exists
        cursor.execute(
            "SELECT * FROM game_stats WHERE user_id = ? AND game_name = ?",
            (user_id, game_name)
        )
        existing = cursor.fetchone()
        
        if existing:
            # Update existing record
            cursor.execute("""
                UPDATE game_stats 
                SET played = played + ?, 
                    won = won + ?, 
                    total_score = total_score + ?,
                    best_score = MAX(best_score, ?),
                    last_played = CURRENT_TIMESTAMP
                WHERE user_id = ? AND game_name = ?
            """, (played, won, score, score, user_id, game_name))
        else:
            # Insert new record
            cursor.execute("""
                INSERT INTO game_stats (user_id, game_name, played, won, total_score, best_score)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (user_id, game_name, played, won, score, score))
        
        # Update user's total games played and won
        cursor.execute("""
            UPDATE users 
            SET games_played = games_played + ?, 
                games_won = games_won + ?,
                experience = experience + ?
            WHERE discord_id = ?
        """, (played, won, score // 10, user_id))  # 1 XP per 10 score points
        
        # Check for level up
        cursor.execute("SELECT experience, level FROM users WHERE discord_id = ?", (user_id,))
        user_data = cursor.fetchone()
        
        if user_data:
            current_xp = user_data['experience']
            current_level = user_data['level']
            required_xp = current_level * 1000  # 1000 XP per level
            
            if current_xp >= required_xp:
                new_level = current_level + 1
                bonus_coins = 50 * new_level  # Level up bonus
                
                cursor.execute("""
                    UPDATE users 
                    SET level = ?, coins = coins + ?
                    WHERE discord_id = ?
                """, (new_level, bonus_coins, user_id))
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error updating game stats for {user_id}: {e}")
        return False

async def show_balance(interaction):
    """Show user's balance"""
    try:
        user_id = str(interaction.user.id)
        balance = get_user_balance(user_id)
        
        # Get user level and XP
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT level, experience, games_played, games_won FROM users WHERE discord_id = ?",
            (user_id,)
        )
        user_data = cursor.fetchone()
        conn.close()
        
        if user_data:
            level = user_data['level']
            xp = user_data['experience']
            games_played = user_data['games_played']
            games_won = user_data['games_won']
            win_rate = (games_won / games_played * 100) if games_played > 0 else 0
            
            embed = discord.Embed(
                title="💰 Your Economy Status",
                color=0xffd700
            )
            
            embed.add_field(
                name="💎 Coin Balance",
                value=f"**{balance:,} coins**",
                inline=True
            )
            
            embed.add_field(
                name="⭐ Level",
                value=f"**Level {level}**",
                inline=True
            )
            
            embed.add_field(
                name="🎯 Experience",
                value=f"**{xp:,} XP**",
                inline=True
            )
            
            embed.add_field(
                name="🎮 Games Played",
                value=f"**{games_played}**",
                inline=True
            )
            
            embed.add_field(
                name="🏆 Games Won",
                value=f"**{games_won}**",
                inline=True
            )
            
            embed.add_field(
                name="📊 Win Rate",
                value=f"**{win_rate:.1f}%**",
                inline=True
            )
            
            # XP progress bar
            xp_needed = level * 1000
            xp_progress = (xp % 1000) / 10  # Convert to percentage
            progress_bar = "🟩" * int(xp_progress // 10) + "⬜" * (10 - int(xp_progress // 10))
            
            embed.add_field(
                name="📈 Level Progress",
                value=f"{progress_bar} {xp % 1000}/1000 XP",
                inline=False
            )
            
            embed.set_footer(text=f"Economy data for {interaction.user.display_name}")
            
        else:
            embed = discord.Embed(
                title="💰 Your Economy Status",
                description="No data found. Play some games to get started!",
                color=0x95a5a6
            )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ Error retrieving balance information!",
            ephemeral=True
        )
        print(f"Balance command error: {e}")

async def show_leaderboard(interaction):
    """Show top players leaderboard"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT username, coins, level, games_played, games_won 
            FROM users 
            ORDER BY coins DESC 
            LIMIT 10
        """)
        
        top_players = cursor.fetchall()
        conn.close()
        
        if not top_players:
            await interaction.response.send_message(
                "📊 No players found on the leaderboard yet!",
                ephemeral=True
            )
            return
        
        embed = discord.Embed(
            title="🏆 Leaderboard - Top Players",
            description="The richest players in the server!",
            color=0xffd700
        )
        
        medal_emojis = ["🥇", "🥈", "🥉"]
        
        for i, player in enumerate(top_players):
            rank = i + 1
            medal = medal_emojis[i] if i < 3 else f"{rank}."
            username = player['username']
            coins = player['coins']
            level = player['level']
            games_played = player['games_played']
            games_won = player['games_won']
            win_rate = (games_won / games_played * 100) if games_played > 0 else 0
            
            embed.add_field(
                name=f"{medal} {username}",
                value=f"💰 {coins:,} coins\n⭐ Level {level}\n🎯 {win_rate:.1f}% win rate",
                inline=True
            )
        
        embed.set_footer(text="Play games to climb the leaderboard!")
        
        await interaction.response.send_message(embed=embed)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ Error retrieving leaderboard!",
            ephemeral=True
        )
        print(f"Leaderboard command error: {e}")

async def daily_bonus(interaction):
    """Give daily coin bonus"""
    try:
        user_id = str(interaction.user.id)
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check last daily claim
        cursor.execute(
            "SELECT last_daily FROM users WHERE discord_id = ?",
            (user_id,)
        )
        result = cursor.fetchone()
        
        if result and result['last_daily']:
            # Check if 24 hours have passed
            from datetime import datetime, timedelta
            last_daily = datetime.fromisoformat(result['last_daily'])
            now = datetime.now()
            
            if now - last_daily < timedelta(hours=24):
                time_left = timedelta(hours=24) - (now - last_daily)
                hours, remainder = divmod(time_left.seconds, 3600)
                minutes, _ = divmod(remainder, 60)
                
                await interaction.response.send_message(
                    f"⏰ You already claimed your daily bonus today!\n"
                    f"Come back in {hours}h {minutes}m for your next bonus.",
                    ephemeral=True
                )
                return
        
        # Give daily bonus
        daily_amount = 100
        update_coins(user_id, daily_amount)
        
        # Update last daily claim
        cursor.execute(
            "UPDATE users SET last_daily = CURRENT_TIMESTAMP WHERE discord_id = ?",
            (user_id,)
        )
        conn.commit()
        conn.close()
        
        new_balance = get_user_balance(user_id)
        
        embed = discord.Embed(
            title="🎁 Daily Bonus Claimed!",
            description=f"You received your daily bonus of **{daily_amount} coins**!",
            color=0x2ecc71
        )
        
        embed.add_field(
            name="💰 New Balance",
            value=f"**{new_balance:,} coins**",
            inline=True
        )
        
        embed.add_field(
            name="⏰ Next Bonus",
            value="Available in 24 hours",
            inline=True
        )
        
        embed.set_footer(text="Come back tomorrow for another bonus!")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ Error processing daily bonus!",
            ephemeral=True
        )
        print(f"Daily bonus error: {e}")

async def show_stats(interaction):
    """Show user's detailed game statistics"""
    try:
        user_id = str(interaction.user.id)
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT game_name, played, won, total_score, best_score, last_played
            FROM game_stats 
            WHERE user_id = ?
            ORDER BY played DESC
            LIMIT 10
        """, (user_id,))
        
        game_stats = cursor.fetchall()
        conn.close()
        
        if not game_stats:
            await interaction.response.send_message(
                "📊 No game statistics found. Play some games to see your stats!",
                ephemeral=True
            )
            return
        
        embed = discord.Embed(
            title="📊 Your Game Statistics",
            description="Detailed breakdown of your gaming performance",
            color=0x3498db
        )
        
        total_games = sum(stat['played'] for stat in game_stats)
        total_wins = sum(stat['won'] for stat in game_stats)
        overall_win_rate = (total_wins / total_games * 100) if total_games > 0 else 0
        
        embed.add_field(
            name="🎮 Overall Stats",
            value=f"**{total_games}** games played\n**{total_wins}** games won\n**{overall_win_rate:.1f}%** win rate",
            inline=False
        )
        
        for stat in game_stats[:5]:  # Show top 5 games
            game_name = stat['game_name'].title()
            played = stat['played']
            won = stat['won']
            win_rate = (won / played * 100) if played > 0 else 0
            best_score = stat['best_score']
            
            embed.add_field(
                name=f"🎯 {game_name}",
                value=f"Played: {played}\nWon: {won} ({win_rate:.1f}%)\nBest: {best_score}",
                inline=True
            )
        
        embed.set_footer(text=f"Statistics for {interaction.user.display_name}")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ Error retrieving game statistics!",
            ephemeral=True
        )
        print(f"Stats command error: {e}")

# Import discord here to avoid circular imports
import discord
