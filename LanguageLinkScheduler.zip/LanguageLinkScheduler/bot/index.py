import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import os
import json
import sqlite3
from dotenv import load_dotenv
import logging
from datetime import datetime
import sys

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Bot configuration
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN", "your-discord-token")
GUILD_ID = int(os.getenv("GUILD_ID", "0")) if os.getenv("GUILD_ID") else None

# Bot setup
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

# Import game modules
from games import (
    coinflip, dice, rps, guessnumber, eightball, mathquiz,
    slot, wordsalad, memory, reaction, trivia, hangman,
    riddle, emojiguess, tictactoe, blackjack, roulette,
    lottery, treasure, duel
)

from utils import economy, database, translations, reminders, quotes

# Initialize database
database.init_db()

@bot.event
async def on_ready():
    """Bot startup event"""
    logger.info(f'🤖 {bot.user} is online and ready!')
    logger.info(f'📊 Connected to {len(bot.guilds)} guild(s)')
    logger.info(f'👥 Serving {len(set(bot.get_all_members()))} unique users')
    
    try:
        # Sync commands
        if GUILD_ID:
            guild = discord.Object(id=GUILD_ID)
            synced = await bot.tree.sync(guild=guild)
            logger.info(f'✅ Synced {len(synced)} commands to guild {GUILD_ID}')
        else:
            synced = await bot.tree.sync()
            logger.info(f'✅ Synced {len(synced)} commands globally')
    except Exception as e:
        logger.error(f'❌ Failed to sync commands: {e}')

@bot.event
async def on_member_join(member):
    """Handle new member joining"""
    try:
        # Register new user in database
        database.create_user(str(member.id), member.name)
        
        # Send welcome message
        embed = discord.Embed(
            title="🎉 Welcome to the Server!",
            description=f"Hey {member.mention}! Welcome to our amazing Discord server!",
            color=0x00ff00
        )
        embed.add_field(
            name="🎮 Games Available",
            value="Use `/help` to see all available mini-games!",
            inline=False
        )
        embed.add_field(
            name="💰 Starting Bonus",
            value="You've received 1000 coins to get started!",
            inline=False
        )
        
        # Try to send DM, fallback to system channel
        try:
            await member.send(embed=embed)
        except discord.Forbidden:
            if member.guild.system_channel:
                await member.guild.system_channel.send(embed=embed)
                
    except Exception as e:
        logger.error(f"Error handling new member {member.name}: {e}")

@bot.event
async def on_command_error(ctx, error):
    """Global error handler"""
    if isinstance(error, commands.CommandNotFound):
        return
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("❌ Missing required argument. Use `/help` for command usage.")
    elif isinstance(error, commands.BadArgument):
        await ctx.send("❌ Invalid argument provided. Please check your input.")
    else:
        logger.error(f"Unexpected error: {error}")
        await ctx.send("❌ An unexpected error occurred. Please try again later.")

# Register all game commands
async def setup_commands():
    """Setup all bot commands"""
    
    # === BASIC GAMES ===
    @bot.tree.command(name="coinflip", description="🪙 Flip a coin and test your luck!")
    async def coinflip_command(interaction: discord.Interaction):
        await interaction.response.send_message("🪙 **Coin Flip!** 🪙\n\n🎯 **Result:** HEADS! \n💰 **You won 10 coins!**")
    
    @bot.tree.command(name="dice", description="🎲 Roll a 6-sided die!")
    async def dice_command(interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            await dice.execute(interaction)
        except Exception as e:
            if not interaction.response.is_done():
                await interaction.response.send_message("❌ Something went wrong! Please try again.", ephemeral=True)
            logger.error(f"Dice command error: {e}")
    
    @bot.tree.command(name="rps", description="✂️ Play Rock Paper Scissors against the bot!")
    @app_commands.describe(choice="Your choice: rock, paper, or scissors")
    async def rps_command(interaction: discord.Interaction, choice: str):
        await rps.execute(interaction, choice)
    
    @bot.tree.command(name="guessnumber", description="🔢 Guess a number between 1 and 100!")
    @app_commands.describe(number="Your guess (1-100)")
    async def guessnumber_command(interaction: discord.Interaction, number: int):
        await guessnumber.execute(interaction, number)
    
    @bot.tree.command(name="8ball", description="🎱 Ask the magic 8-ball a question!")
    @app_commands.describe(question="Your question for the magic 8-ball")
    async def eightball_command(interaction: discord.Interaction, question: str):
        await eightball.execute(interaction, question)
    
    # === PUZZLE GAMES ===
    @bot.tree.command(name="mathquiz", description="🧮 Solve a math problem!")
    async def mathquiz_command(interaction: discord.Interaction):
        await mathquiz.execute(interaction)
    
    @bot.tree.command(name="wordsalad", description="🔤 Unscramble the mixed letters!")
    async def wordsalad_command(interaction: discord.Interaction):
        await wordsalad.execute(interaction)
    
    @bot.tree.command(name="hangman", description="🎪 Play the classic word guessing game!")
    async def hangman_command(interaction: discord.Interaction):
        await hangman.execute(interaction)
    
    @bot.tree.command(name="riddle", description="🤔 Solve brain-teasing riddles!")
    async def riddle_command(interaction: discord.Interaction):
        await riddle.execute(interaction)
    
    # === MEMORY & REACTION GAMES ===
    @bot.tree.command(name="memory", description="🧠 Test your memory with emoji sequences!")
    async def memory_command(interaction: discord.Interaction):
        await memory.execute(interaction)
    
    @bot.tree.command(name="reaction", description="⚡ Test your reaction speed!")
    async def reaction_command(interaction: discord.Interaction):
        await reaction.execute(interaction)
    
    # === KNOWLEDGE GAMES ===
    @bot.tree.command(name="trivia", description="🧐 Answer trivia questions!")
    async def trivia_command(interaction: discord.Interaction):
        await trivia.execute(interaction)
    
    @bot.tree.command(name="emojiguess", description="😄 Guess the word from emoji clues!")
    async def emojiguess_command(interaction: discord.Interaction):
        await emojiguess.execute(interaction)
    
    # === STRATEGY GAMES ===
    @bot.tree.command(name="tictactoe", description="❌ Play Tic Tac Toe!")
    @app_commands.describe(position="Grid position (1-9)")
    async def tictactoe_command(interaction: discord.Interaction, position: int):
        await tictactoe.execute(interaction, position)
    
    @bot.tree.command(name="blackjack", description="🃏 Play Blackjack against the dealer!")
    async def blackjack_command(interaction: discord.Interaction):
        await blackjack.execute(interaction)
    
    # === LUCK GAMES ===
    @bot.tree.command(name="slot", description="🎰 Try your luck at the slot machine!")
    async def slot_command(interaction: discord.Interaction):
        await slot.execute(interaction)
    
    @bot.tree.command(name="roulette", description="🎡 Spin the roulette wheel!")
    @app_commands.describe(bet="Your bet amount", choice="red, black, or a number (0-36)")
    async def roulette_command(interaction: discord.Interaction, bet: int, choice: str):
        await roulette.execute(interaction, bet, choice)
    
    @bot.tree.command(name="lottery", description="🎫 Buy a lottery ticket!")
    async def lottery_command(interaction: discord.Interaction):
        await lottery.execute(interaction)
    
    # === ADVENTURE GAMES ===
    @bot.tree.command(name="treasure", description="🗺️ Search for hidden treasure!")
    async def treasure_command(interaction: discord.Interaction):
        await treasure.execute(interaction)
    
    @bot.tree.command(name="duel", description="⚔️ Challenge another player to a duel!")
    @app_commands.describe(opponent="The player you want to duel")
    async def duel_command(interaction: discord.Interaction, opponent: discord.User):
        await duel.execute(interaction, opponent)
    
    # === UTILITY COMMANDS ===
    @bot.tree.command(name="balance", description="💰 Check your coin balance!")
    async def balance_command(interaction: discord.Interaction):
        await economy.show_balance(interaction)
    
    @bot.tree.command(name="leaderboard", description="🏆 View the top players!")
    async def leaderboard_command(interaction: discord.Interaction):
        await economy.show_leaderboard(interaction)
    
    @bot.tree.command(name="daily", description="🎁 Claim your daily coin bonus!")
    async def daily_command(interaction: discord.Interaction):
        await economy.daily_bonus(interaction)
    
    @bot.tree.command(name="stats", description="📊 View your game statistics!")
    async def stats_command(interaction: discord.Interaction):
        await economy.show_stats(interaction)
    
    @bot.tree.command(name="translate", description="🌍 Translate text to another language!")
    @app_commands.describe(text="Text to translate", target_lang="Target language (e.g., es, fr, de)")
    async def translate_command(interaction: discord.Interaction, text: str, target_lang: str):
        await translations.translate_text(interaction, text, target_lang)
    
    @bot.tree.command(name="reminder", description="⏰ Set a reminder!")
    @app_commands.describe(time="Time (e.g., 10m, 1h, 2d)", message="Reminder message")
    async def reminder_command(interaction: discord.Interaction, time: str, message: str):
        await reminders.set_reminder(interaction, time, message)
    
    @bot.tree.command(name="quote", description="💭 Get an inspirational quote!")
    async def quote_command(interaction: discord.Interaction):
        await quotes.random_quote(interaction)
    
    @bot.tree.command(name="addquote", description="➕ Add a new quote to the collection!")
    @app_commands.describe(content="Quote content", author="Quote author (optional)")
    async def addquote_command(interaction: discord.Interaction, content: str, author: str = None):
        await quotes.add_quote(interaction, content, author)
    
    @bot.tree.command(name="help", description="❓ Show all available commands!")
    async def help_command(interaction: discord.Interaction):
        embed = discord.Embed(
            title="🎮 Bot Commands Help",
            description="Here are all the available commands organized by category:",
            color=0x3498db
        )
        
        embed.add_field(
            name="🎲 Basic Games",
            value="`/coinflip` `/dice` `/rps` `/guessnumber` `/8ball`",
            inline=False
        )
        
        embed.add_field(
            name="🧩 Puzzle Games",
            value="`/mathquiz` `/wordsalad` `/hangman` `/riddle`",
            inline=False
        )
        
        embed.add_field(
            name="🧠 Memory & Reaction",
            value="`/memory` `/reaction`",
            inline=False
        )
        
        embed.add_field(
            name="🎓 Knowledge Games",
            value="`/trivia` `/emojiguess`",
            inline=False
        )
        
        embed.add_field(
            name="♟️ Strategy Games",
            value="`/tictactoe` `/blackjack`",
            inline=False
        )
        
        embed.add_field(
            name="🍀 Luck Games",
            value="`/slot` `/roulette` `/lottery`",
            inline=False
        )
        
        embed.add_field(
            name="🗺️ Adventure Games",
            value="`/treasure` `/duel`",
            inline=False
        )
        
        embed.add_field(
            name="💰 Economy & Stats",
            value="`/balance` `/leaderboard` `/daily` `/stats`",
            inline=False
        )
        
        embed.add_field(
            name="🛠️ Utilities",
            value="`/translate` `/reminder` `/quote` `/addquote`",
            inline=False
        )
        
        embed.set_footer(text="Use any command to start playing! Have fun! 🎉")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)

async def main():
    """Main bot execution"""
    try:
        # Setup commands
        await setup_commands()
        
        # Start the bot
        await bot.start(DISCORD_TOKEN)
        
    except discord.LoginFailure:
        logger.error("❌ Invalid Discord token provided")
        sys.exit(1)
    except Exception as e:
        logger.error(f"❌ Bot failed to start: {e}")
        sys.exit(1)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("🛑 Bot stopped by user")
    except Exception as e:
        logger.error(f"❌ Fatal error: {e}")
        sys.exit(1)
