import discord
import random
from utils.economy import update_coins, update_game_stats

async def execute(interaction: discord.Interaction, question: str):
    """Execute Magic 8-Ball game"""
    try:
        user_id = str(interaction.user.id)
        
        # 8-ball responses with categories
        responses = {
            "positive": [
                "It is certain 🟢",
                "Without a doubt 🟢", 
                "Yes definitely 🟢",
                "You may rely on it 🟢",
                "As I see it, yes 🟢",
                "Most likely 🟢",
                "Outlook good 🟢",
                "Yes 🟢",
                "Signs point to yes 🟢"
            ],
            "negative": [
                "Don't count on it 🔴",
                "My reply is no 🔴",
                "My sources say no 🔴", 
                "Outlook not so good 🔴",
                "Very doubtful 🔴",
                "No 🔴"
            ],
            "neutral": [
                "Reply hazy, try again 🟡",
                "Ask again later 🟡",
                "Better not tell you now 🟡",
                "Cannot predict now 🟡",
                "Concentrate and ask again 🟡"
            ]
        }
        
        # Choose random category and response
        category = random.choice(list(responses.keys()))
        response = random.choice(responses[category])
        
        # Small coin reward for using the 8-ball
        coins_won = random.randint(1, 5)
        update_coins(user_id, coins_won)
        
        # Update stats
        update_game_stats(user_id, "8ball", played=1, won=1, score=coins_won)
        
        # Color based on response type
        colors = {
            "positive": 0x00ff00,
            "negative": 0xff6b6b, 
            "neutral": 0xf39c12
        }
        
        # Create embed
        embed = discord.Embed(
            title="🎱 Magic 8-Ball",
            color=colors[category]
        )
        
        embed.add_field(
            name="Your Question",
            value=f"*{question}*",
            inline=False
        )
        
        embed.add_field(
            name="🔮 The Magic 8-Ball Says:",
            value=f"**{response}**",
            inline=False
        )
        
        embed.add_field(
            name="💰 Mystical Reward",
            value=f"You received **{coins_won} coins** for consulting the 8-ball!",
            inline=False
        )
        
        embed.set_footer(text=f"Asked by {interaction.user.display_name} • The 8-ball knows all")
        
        await interaction.response.send_message(embed=embed)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while consulting the Magic 8-Ball. Please try again!", 
            ephemeral=True
        )
        print(f"8-Ball error: {e}")
