import discord
import random
from utils.economy import update_coins, update_game_stats

class EmojiGuessView(discord.ui.View):
    def __init__(self, answer: str, user_id: str, category: str):
        super().__init__(timeout=90.0)  # 90 seconds to answer
        self.answer = answer.lower()
        self.user_id = user_id
        self.category = category
        self.answered = False
        
        # Rewards based on category difficulty
        self.rewards = {"movies": 20, "songs": 25, "books": 30, "games": 20, "food": 15}
    
    @discord.ui.button(label="Give Hint", style=discord.ButtonStyle.secondary, emoji="💡")
    async def hint_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != int(self.user_id):
            await interaction.response.send_message(
                "❌ This isn't your emoji guess game!", ephemeral=True
            )
            return
        
        # Disable hint button after use
        button.disabled = True
        
        # Generate hint based on answer
        hints = {
            "titanic": "This 1997 disaster film won 11 Academy Awards",
            "harry potter": "A young wizard's magical adventures at a school",
            "star wars": "Space opera about the force and lightsabers",
            "finding nemo": "Animated fish looking for his lost son",
            "frozen": "Let it go! A Disney princess with ice powers",
            "pizza": "Italian dish with cheese, sauce, and toppings",
            "hamburger": "Popular American sandwich with meat patty",
            "birthday cake": "Sweet celebration dessert with candles",
            "coffee": "Popular caffeinated morning beverage",
            "ice cream": "Cold, sweet frozen dessert",
            "minecraft": "Blocky sandbox building game",
            "fortnite": "Popular battle royale game",
            "pokemon": "Gotta catch 'em all!",
            "super mario": "Italian plumber jumping on mushrooms",
            "the legend of zelda": "Hero saves princess in magical kingdom"
        }
        
        hint = hints.get(self.answer, "Think about the category and emojis!")
        
        await interaction.response.send_message(
            f"💡 **Hint:** {hint}", ephemeral=True
        )
    
    @discord.ui.button(label="Give Up", style=discord.ButtonStyle.danger, emoji="🏳️")
    async def give_up(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != int(self.user_id):
            await interaction.response.send_message(
                "❌ This isn't your emoji guess game!", ephemeral=True
            )
            return
        
        if self.answered:
            return
        
        self.answered = True
        update_game_stats(self.user_id, "emojiguess", played=1, won=0, score=0)
        
        # Disable all buttons
        for item in self.children:
            item.disabled = True
        
        embed = discord.Embed(
            title="😄 Emoji Guess - Given Up",
            description=f"The answer was: **{self.answer.title()}**",
            color=0xff6b6b
        )
        
        embed.add_field(
            name="📱 Keep Practicing!",
            value="Emoji puzzles get easier with practice!",
            inline=False
        )
        
        embed.set_footer(text=f"Game ended by {interaction.user.display_name}")
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def on_timeout(self):
        if not self.answered:
            update_game_stats(self.user_id, "emojiguess", played=1, won=0, score=0)
        
        for item in self.children:
            item.disabled = True

async def execute(interaction: discord.Interaction):
    """Execute emoji guess game"""
    try:
        user_id = str(interaction.user.id)
        
        # Emoji puzzles organized by category
        emoji_puzzles = {
            "movies": [
                {"emojis": "🚢💎❄️", "answer": "titanic"},
                {"emojis": "🧙‍♂️⚡🏰", "answer": "harry potter"},
                {"emojis": "⭐🚀⚔️", "answer": "star wars"},
                {"emojis": "🐠🐟🌊", "answer": "finding nemo"},
                {"emojis": "❄️👑💙", "answer": "frozen"},
                {"emojis": "🦁👑🌍", "answer": "the lion king"},
                {"emojis": "🍎👸🪞", "answer": "snow white"},
                {"emojis": "🕷️🕸️🏢", "answer": "spider man"}
            ],
            "songs": [
                {"emojis": "🌈☀️", "answer": "somewhere over the rainbow"},
                {"emojis": "💖🔥", "answer": "heart on fire"},
                {"emojis": "🌙⭐", "answer": "fly me to the moon"},
                {"emojis": "🎵👑", "answer": "dancing queen"},
                {"emojis": "🌊🎶", "answer": "ocean waves"}
            ],
            "books": [
                {"emojis": "🧙‍♂️📚⚡", "answer": "harry potter"},
                {"emojis": "💍🗻🧙‍♂️", "answer": "lord of the rings"},
                {"emojis": "🐺🌙👨", "answer": "twilight"},
                {"emojis": "🔥🏹👸", "answer": "hunger games"},
                {"emojis": "📖🕊️", "answer": "to kill a mockingbird"}
            ],
            "games": [
                {"emojis": "🧱⛏️🌍", "answer": "minecraft"},
                {"emojis": "🔫🏗️⚡", "answer": "fortnite"},
                {"emojis": "👾⚡🎮", "answer": "pokemon"},
                {"emojis": "🍄🏃‍♂️👑", "answer": "super mario"},
                {"emojis": "🗡️🛡️👸", "answer": "the legend of zelda"}
            ],
            "food": [
                {"emojis": "🍕🧀🍅", "answer": "pizza"},
                {"emojis": "🍔🥩🧀", "answer": "hamburger"},
                {"emojis": "🎂🕯️🎉", "answer": "birthday cake"},
                {"emojis": "☕🌅😴", "answer": "coffee"},
                {"emojis": "🍦❄️🍓", "answer": "ice cream"},
                {"emojis": "🍣🐟🍚", "answer": "sushi"},
                {"emojis": "🌮🌶️🥑", "answer": "tacos"}
            ]
        }
        
        # Choose random category and puzzle
        category = random.choice(list(emoji_puzzles.keys()))
        puzzle = random.choice(emoji_puzzles[category])
        
        # Create embed
        embed = discord.Embed(
            title="😄 Emoji Guess Challenge",
            description=f"Can you guess what these emojis represent?",
            color=0xf39c12
        )
        
        embed.add_field(
            name="🎯 Emoji Clue",
            value=f"**{puzzle['emojis']}**",
            inline=False
        )
        
        embed.add_field(
            name="📂 Category",
            value=f"**{category.title()}**",
            inline=True
        )
        
        embed.add_field(
            name="💰 Reward",
            value=f"**{15 if category == 'food' else 20 if category in ['movies', 'games'] else 25 if category == 'songs' else 30} coins**",
            inline=True
        )
        
        embed.add_field(
            name="⏰ Time Limit",
            value="**90 seconds**",
            inline=True
        )
        
        embed.add_field(
            name="💡 How to Play",
            value="Type your answer in chat! Use the hint button if you're stuck.",
            inline=False
        )
        
        embed.set_footer(text=f"Emoji puzzle for {interaction.user.display_name}")
        
        # Create view
        view = EmojiGuessView(puzzle["answer"], user_id, category)
        
        await interaction.response.send_message(embed=embed, view=view)
        
        # Wait for user response
        def check(message):
            return (message.author.id == interaction.user.id and 
                   message.channel == interaction.channel)
        
        try:
            # Wait for user's answer
            message = await interaction.client.wait_for('message', timeout=90.0, check=check)
            
            if view.answered:
                return  # Game already ended
            
            user_answer = message.content.lower().strip()
            correct_answer = puzzle["answer"].lower()
            
            # Check for correct answer (allow some flexibility)
            is_correct = (user_answer == correct_answer or 
                         all(word in user_answer for word in correct_answer.split()) or
                         correct_answer.replace(" ", "") == user_answer.replace(" ", ""))
            
            if is_correct:
                # Correct answer!
                view.answered = True
                
                coins_earned = view.rewards[category]
                update_coins(user_id, coins_earned)
                update_game_stats(user_id, "emojiguess", played=1, won=1, score=coins_earned)
                
                # Disable all buttons
                for item in view.children:
                    item.disabled = True
                
                # Create success embed
                success_embed = discord.Embed(
                    title="🎉 Emoji Guess - Correct!",
                    description=f"Amazing! You decoded the emojis perfectly!",
                    color=0x00ff00
                )
                
                success_embed.add_field(
                    name="✅ Correct Answer",
                    value=f"**{puzzle['answer'].title()}**",
                    inline=False
                )
                
                success_embed.add_field(
                    name="😄 Emoji Clue",
                    value=puzzle['emojis'],
                    inline=True
                )
                
                success_embed.add_field(
                    name="💰 Coins Earned",
                    value=f"**{coins_earned} coins**",
                    inline=True
                )
                
                success_embed.add_field(
                    name="📂 Category",
                    value=f"**{category.title()}**",
                    inline=True
                )
                
                success_embed.set_footer(text=f"Solved by {interaction.user.display_name}")
                
                await interaction.edit_original_response(embed=success_embed, view=view)
                
                # React to user's message
                try:
                    await message.add_reaction("🎉")
                    await message.add_reaction("😄")
                except:
                    pass
            else:
                # Wrong answer
                await message.add_reaction("❌")
                
                # Send encouragement
                encourage_embed = discord.Embed(
                    title="❌ Not Quite Right",
                    description=f"'{user_answer}' is not the answer. Keep trying!",
                    color=0xff6b6b
                )
                
                encourage_embed.add_field(
                    name="💡 Tip",
                    value=f"Think about {category}! Use the hint button for help.",
                    inline=False
                )
                
                await interaction.followup.send(embed=encourage_embed, ephemeral=True)
                
        except asyncio.TimeoutError:
            if not view.answered:
                # Time's up
                view.answered = True
                update_game_stats(user_id, "emojiguess", played=1, won=0, score=0)
                
                for item in view.children:
                    item.disabled = True
                
                timeout_embed = discord.Embed(
                    title="⏰ Emoji Guess - Time's Up!",
                    description=f"Time ran out! The answer was: **{puzzle['answer'].title()}**",
                    color=0xf39c12
                )
                
                timeout_embed.add_field(
                    name="😄 Emoji Clue",
                    value=puzzle['emojis'],
                    inline=True
                )
                
                timeout_embed.add_field(
                    name="📂 Category",
                    value=f"**{category.title()}**",
                    inline=True
                )
                
                timeout_embed.add_field(
                    name="🧠 Keep Practicing!",
                    value="Emoji puzzles are all about creative thinking!",
                    inline=False
                )
                
                timeout_embed.set_footer(text=f"Game timed out for {interaction.user.display_name}")
                
                await interaction.edit_original_response(embed=timeout_embed, view=view)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while generating the emoji puzzle. Please try again!", 
            ephemeral=True
        )
        print(f"Emoji guess error: {e}")
