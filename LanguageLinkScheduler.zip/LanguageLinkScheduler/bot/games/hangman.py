import discord
import random
from utils.economy import update_coins, update_game_stats

class HangmanView(discord.ui.View):
    def __init__(self, word: str, user_id: str, difficulty: str):
        super().__init__(timeout=120.0)  # 2 minutes to play
        self.word = word.upper()
        self.user_id = user_id
        self.difficulty = difficulty
        self.guessed_letters = set()
        self.wrong_guesses = 0
        self.max_wrong = 6
        self.game_over = False
        
        # Rewards based on difficulty
        self.rewards = {"easy": 20, "medium": 30, "hard": 45}
        
        # Create alphabet buttons
        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        for letter in alphabet:
            button = discord.ui.Button(
                label=letter,
                style=discord.ButtonStyle.secondary,
                custom_id=f"letter_{letter}"
            )
            button.callback = self.letter_callback
            self.add_item(button)
    
    def get_display_word(self):
        """Get the word with guessed letters revealed"""
        return " ".join([letter if letter in self.guessed_letters else "_" for letter in self.word])
    
    def get_hangman_art(self):
        """Get hangman ASCII art based on wrong guesses"""
        stages = [
            "```\n  +---+\n  |   |\n      |\n      |\n      |\n      |\n=========\n```",
            "```\n  +---+\n  |   |\n  O   |\n      |\n      |\n      |\n=========\n```",
            "```\n  +---+\n  |   |\n  O   |\n  |   |\n      |\n      |\n=========\n```",
            "```\n  +---+\n  |   |\n  O   |\n /|   |\n      |\n      |\n=========\n```",
            "```\n  +---+\n  |   |\n  O   |\n /|\\  |\n      |\n      |\n=========\n```",
            "```\n  +---+\n  |   |\n  O   |\n /|\\  |\n /    |\n      |\n=========\n```",
            "```\n  +---+\n  |   |\n  O   |\n /|\\  |\n / \\  |\n      |\n=========\n```"
        ]
        return stages[self.wrong_guesses]
    
    async def letter_callback(self, interaction: discord.Interaction):
        """Handle letter button presses"""
        if interaction.user.id != int(self.user_id):
            await interaction.response.send_message("Das ist nicht dein Spiel!", ephemeral=True)
            return
        
        if self.game_over:
            await interaction.response.send_message("Das Spiel ist bereits beendet!", ephemeral=True)
            return
        
        letter = interaction.data['custom_id'].split('_')[1]
        
        if letter in self.guessed_letters:
            await interaction.response.send_message("Du hast diesen Buchstaben bereits geraten!", ephemeral=True)
            return
        
        self.guessed_letters.add(letter)
        
        # Disable the pressed button
        for item in self.children:
            if item.custom_id == f"letter_{letter}":
                item.disabled = True
                item.style = discord.ButtonStyle.success if letter in self.word else discord.ButtonStyle.danger
                break
        
        if letter not in self.word:
            self.wrong_guesses += 1
        
        # Check win condition
        if all(letter in self.guessed_letters for letter in self.word):
            await self.end_game(interaction, won=True)
            return
        
        # Check lose condition
        if self.wrong_guesses >= self.max_wrong:
            await self.end_game(interaction, won=False)
            return
        
        # Update display
        await self.update_display(interaction)
    
    async def update_display(self, interaction: discord.Interaction):
        """Update the game display"""
        display_word = self.get_display_word()
        hangman_art = self.get_hangman_art()
        
        embed = discord.Embed(
            title="🎪 Hangman",
            description=f"{hangman_art}\n\n**Wort:** {display_word}\n**Falsche Versuche:** {self.wrong_guesses}/{self.max_wrong}",
            color=0x3498db
        )
        
        if self.guessed_letters:
            embed.add_field(
                name="Geratene Buchstaben",
                value=" ".join(sorted(self.guessed_letters)),
                inline=False
            )
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def end_game(self, interaction: discord.Interaction, won: bool):
        """End the hangman game"""
        self.game_over = True
        
        for item in self.children:
            item.disabled = True
        
        if won:
            reward = self.rewards[self.difficulty]
            await update_coins(self.user_id, reward)
            await update_game_stats(self.user_id, "hangman", {"wins": 1, "coins_earned": reward})
            
            embed = discord.Embed(
                title="🎉 Gewonnen!",
                description=f"Glückwunsch! Du hast das Wort **{self.word}** erraten!\n\n💰 +{reward} Münzen verdient!",
                color=0x2ecc71
            )
        else:
            await update_game_stats(self.user_id, "hangman", {"losses": 1})
            hangman_art = self.get_hangman_art()
            
            embed = discord.Embed(
                title="💀 Verloren!",
                description=f"{hangman_art}\n\nDas Wort war: **{self.word}**\nViel Glück beim nächsten Mal!",
                color=0xe74c3c
            )
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def on_timeout(self):
        """Handle timeout"""
        self.game_over = True
        for item in self.children:
            item.disabled = True

async def execute(interaction: discord.Interaction):
    """Execute hangman game"""
    word_lists = {
        "easy": ["KATZE", "HUND", "AUTO", "HAUS", "BAUM", "BUCH", "BALL", "TISCH"],
        "medium": ["COMPUTER", "TELEFON", "FENSTER", "GARTEN", "BLUME", "SCHULE"],
        "hard": ["SCHWIERIGKEITEN", "VERANTWORTUNG", "WISSENSCHAFT", "TECHNOLOGIE"]
    }
    
    # Select random difficulty and word
    difficulty = random.choice(["easy", "medium", "hard"])
    word = random.choice(word_lists[difficulty])
    
    view = HangmanView(word, str(interaction.user.id), difficulty)
    
    embed = discord.Embed(
        title="🎪 Hangman",
        description=f"Rate das Wort! ({difficulty.upper()} - {len(word)} Buchstaben)\n\n{view.get_display_word()}\n\n{view.get_hangman_art()}",
        color=0x3498db
    )
    
    await interaction.response.send_message(embed=embed, view=view)