import discord
import random
from utils.economy import update_coins, update_game_stats

class TriviaView(discord.ui.View):
    def __init__(self, correct_answer: str, user_id: str, difficulty: str):
        super().__init__(timeout=30.0)
        self.correct_answer = correct_answer
        self.user_id = user_id
        self.difficulty = difficulty
        self.answered = False
        
        # Coin rewards based on difficulty
        self.rewards = {"easy": 10, "medium": 20, "hard": 35}
    
    async def answer_callback(self, interaction: discord.Interaction, selected_answer: str):
        if interaction.user.id != int(self.user_id):
            await interaction.response.send_message(
                "❌ This isn't your trivia question!", ephemeral=True
            )
            return
        
        if self.answered:
            await interaction.response.send_message(
                "❌ You already answered this question!", ephemeral=True
            )
            return
        
        self.answered = True
        correct = selected_answer == self.correct_answer
        
        # Update stats and coins
        coins_won = 0
        if correct:
            coins_won = self.rewards[self.difficulty]
            update_coins(self.user_id, coins_won)
        
        update_game_stats(
            self.user_id, 
            "trivia", 
            played=1, 
            won=1 if correct else 0, 
            score=coins_won
        )
        
        # Disable all buttons
        for item in self.children:
            item.disabled = True
            if hasattr(item, 'label') and item.label == self.correct_answer:
                item.style = discord.ButtonStyle.success
            elif hasattr(item, 'label') and item.label == selected_answer and not correct:
                item.style = discord.ButtonStyle.danger
        
        # Create result embed
        embed = discord.Embed(
            title="🧐 Trivia Results",
            color=0x00ff00 if correct else 0xff6b6b
        )
        
        if correct:
            embed.add_field(
                name="🎉 Correct!",
                value=f"Well done! You earned **{coins_won} coins**!",
                inline=False
            )
            embed.add_field(
                name="🧠 Knowledge Level",
                value=f"You mastered this {self.difficulty} question!",
                inline=False
            )
        else:
            embed.add_field(
                name="❌ Incorrect!",
                value=f"The correct answer was: **{self.correct_answer}**",
                inline=False
            )
            embed.add_field(
                name="📚 Keep Learning",
                value="Every question makes you smarter!",
                inline=False
            )
        
        embed.add_field(
            name="Your Answer",
            value=f"**{selected_answer}**",
            inline=True
        )
        
        embed.add_field(
            name="Correct Answer",
            value=f"**{self.correct_answer}**",
            inline=True
        )
        
        embed.add_field(
            name="Difficulty",
            value=f"**{self.difficulty.title()}**",
            inline=True
        )
        
        embed.set_footer(text=f"Trivia completed by {interaction.user.display_name}")
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def on_timeout(self):
        if not self.answered:
            update_game_stats(self.user_id, "trivia", played=1, won=0, score=0)
        
        for item in self.children:
            item.disabled = True

async def execute(interaction: discord.Interaction):
    """Execute trivia game"""
    try:
        user_id = str(interaction.user.id)
        
        # Trivia questions database
        trivia_questions = {
            "easy": [
                {
                    "question": "What is the capital of France?",
                    "correct": "Paris",
                    "options": ["London", "Berlin", "Paris", "Madrid"]
                },
                {
                    "question": "How many legs does a spider have?",
                    "correct": "8",
                    "options": ["6", "8", "10", "12"]
                },
                {
                    "question": "What color do you get when you mix red and blue?",
                    "correct": "Purple",
                    "options": ["Green", "Orange", "Purple", "Yellow"]
                },
                {
                    "question": "Which planet is closest to the Sun?",
                    "correct": "Mercury",
                    "options": ["Venus", "Mercury", "Earth", "Mars"]
                },
                {
                    "question": "What is 5 + 7?",
                    "correct": "12",
                    "options": ["11", "12", "13", "14"]
                }
            ],
            "medium": [
                {
                    "question": "Who painted the Mona Lisa?",
                    "correct": "Leonardo da Vinci",
                    "options": ["Picasso", "Van Gogh", "Leonardo da Vinci", "Michelangelo"]
                },
                {
                    "question": "What is the largest ocean on Earth?",
                    "correct": "Pacific Ocean",
                    "options": ["Atlantic Ocean", "Pacific Ocean", "Indian Ocean", "Arctic Ocean"]
                },
                {
                    "question": "In which year did World War II end?",
                    "correct": "1945",
                    "options": ["1944", "1945", "1946", "1947"]
                },
                {
                    "question": "What is the chemical symbol for gold?",
                    "correct": "Au",
                    "options": ["Go", "Gd", "Au", "Ag"]
                },
                {
                    "question": "Which Shakespeare play features Romeo and Juliet?",
                    "correct": "Romeo and Juliet",
                    "options": ["Hamlet", "Macbeth", "Romeo and Juliet", "Othello"]
                }
            ],
            "hard": [
                {
                    "question": "What is the quantum number that describes electron spin?",
                    "correct": "ms",
                    "options": ["n", "l", "ml", "ms"]
                },
                {
                    "question": "Who developed the theory of general relativity?",
                    "correct": "Albert Einstein",
                    "options": ["Isaac Newton", "Niels Bohr", "Albert Einstein", "Max Planck"]
                },
                {
                    "question": "What is the longest river in the world?",
                    "correct": "Nile River",
                    "options": ["Amazon River", "Nile River", "Yangtze River", "Mississippi River"]
                },
                {
                    "question": "In which programming language was Linux kernel originally written?",
                    "correct": "C",
                    "options": ["C++", "C", "Assembly", "Python"]
                },
                {
                    "question": "What is the study of fungi called?",
                    "correct": "Mycology",
                    "options": ["Biology", "Botany", "Mycology", "Zoology"]
                }
            ]
        }
        
        # Choose difficulty
        difficulty = random.choice(["easy", "medium", "hard"])
        
        # Select random question
        question_data = random.choice(trivia_questions[difficulty])
        
        # Create embed
        embed = discord.Embed(
            title="🧐 Trivia Challenge",
            description=question_data["question"],
            color=0x3498db
        )
        
        embed.add_field(
            name="📊 Difficulty",
            value=f"**{difficulty.title()}**",
            inline=True
        )
        
        embed.add_field(
            name="💰 Reward",
            value=f"**{10 if difficulty == 'easy' else 20 if difficulty == 'medium' else 35} coins**",
            inline=True
        )
        
        embed.add_field(
            name="⏰ Time Limit",
            value="**30 seconds**",
            inline=True
        )
        
        embed.set_footer(text=f"Trivia for {interaction.user.display_name}")
        
        # Create view with answer buttons
        view = TriviaView(question_data["correct"], user_id, difficulty)
        
        # Add buttons for each option
        for option in question_data["options"]:
            button = discord.ui.Button(
                label=option,
                style=discord.ButtonStyle.primary
            )
            
            # Create callback for this specific option
            async def make_callback(selected_option):
                async def callback(button_interaction):
                    await view.answer_callback(button_interaction, selected_option)
                return callback
            
            button.callback = make_callback(option)
            view.add_item(button)
        
        await interaction.response.send_message(embed=embed, view=view)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while generating the trivia question. Please try again!", 
            ephemeral=True
        )
        print(f"Trivia error: {e}")
