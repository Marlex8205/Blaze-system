import discord
import random
from utils.economy import update_coins, update_game_stats

async def execute(interaction: discord.Interaction, number: int):
    """Execute number guessing game"""
    try:
        user_id = str(interaction.user.id)
        
        # Validate input
        if not 1 <= number <= 100:
            await interaction.response.send_message(
                "❌ Please guess a number between 1 and 100!",
                ephemeral=True
            )
            return
        
        # Generate secret number
        secret = random.randint(1, 100)
        
        # Calculate how close the guess was
        difference = abs(number - secret)
        
        # Determine reward based on accuracy
        coins_won = 0
        result_message = ""
        
        if difference == 0:
            coins_won = 100  # Exact match!
            result_message = "🎯 **PERFECT!** Exact match!"
            color = 0xffd700
        elif difference <= 5:
            coins_won = 50  # Very close
            result_message = "🔥 **VERY CLOSE!** Amazing guess!"
            color = 0x00ff00
        elif difference <= 10:
            coins_won = 25  # Close
            result_message = "✨ **CLOSE!** Good guess!"
            color = 0xf39c12
        elif difference <= 20:
            coins_won = 10  # Not bad
            result_message = "👍 **NOT BAD!** Getting warmer!"
            color = 0x3498db
        else:
            result_message = "😔 **FAR OFF** - Keep trying!"
            color = 0xff6b6b
        
        # Update user stats
        if coins_won > 0:
            update_coins(user_id, coins_won)
        
        update_game_stats(
            user_id, 
            "guessnumber", 
            played=1, 
            won=1 if coins_won > 0 else 0, 
            score=100-difference  # Higher score for closer guesses
        )
        
        # Create embed
        embed = discord.Embed(
            title="🔢 Number Guessing Game",
            color=color
        )
        
        embed.add_field(
            name="Your Guess",
            value=f"**{number}**",
            inline=True
        )
        
        embed.add_field(
            name="Secret Number",
            value=f"**{secret}**",
            inline=True
        )
        
        embed.add_field(
            name="Difference",
            value=f"**{difference}**",
            inline=True
        )
        
        embed.add_field(
            name="Result",
            value=result_message,
            inline=False
        )
        
        if coins_won > 0:
            embed.add_field(
                name="💰 Coins Earned",
                value=f"**{coins_won} coins**",
                inline=False
            )
        
        # Add accuracy bar
        accuracy = max(0, 100 - difference)
        bar_length = 10
        filled = int((accuracy / 100) * bar_length)
        bar = "🟩" * filled + "⬜" * (bar_length - filled)
        
        embed.add_field(
            name="🎯 Accuracy",
            value=f"{bar} {accuracy}%",
            inline=False
        )
        
        embed.set_footer(text=f"Game played by {interaction.user.display_name}")
        
        await interaction.response.send_message(embed=embed)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while playing the number guessing game. Please try again!", 
            ephemeral=True
        )
        print(f"Number guessing error: {e}")
