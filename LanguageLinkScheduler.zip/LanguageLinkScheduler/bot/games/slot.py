import discord
import random
from utils.economy import update_coins, update_game_stats

async def execute(interaction: discord.Interaction):
    """Execute slot machine game"""
    try:
        user_id = str(interaction.user.id)
        
        # Slot machine symbols with different rarities
        symbols = {
            "🍒": {"weight": 30, "value": 1},    # Common
            "🍋": {"weight": 25, "value": 2},    # Common
            "🍊": {"weight": 20, "value": 3},    # Uncommon
            "🍇": {"weight": 15, "value": 4},    # Uncommon
            "🔔": {"weight": 7, "value": 6},     # Rare
            "💎": {"weight": 2, "value": 10},    # Very Rare
            "🍀": {"weight": 1, "value": 20}     # Ultra Rare
        }
        
        # Create weighted list for random selection
        weighted_symbols = []
        for symbol, data in symbols.items():
            weighted_symbols.extend([symbol] * data["weight"])
        
        # Spin the reels (3 symbols)
        reels = [random.choice(weighted_symbols) for _ in range(3)]
        
        # Calculate winnings
        coins_won = 0
        multiplier = 1
        win_type = "none"
        
        # Check for wins
        if len(set(reels)) == 1:
            # Three of a kind - JACKPOT!
            symbol = reels[0]
            base_value = symbols[symbol]["value"]
            coins_won = base_value * 50  # Major multiplier for jackpot
            multiplier = 50
            win_type = "jackpot"
        elif len(set(reels)) == 2:
            # Two of a kind
            symbol_counts = {}
            for symbol in reels:
                symbol_counts[symbol] = symbol_counts.get(symbol, 0) + 1
            
            # Find the symbol that appears twice
            for symbol, count in symbol_counts.items():
                if count == 2:
                    base_value = symbols[symbol]["value"]
                    coins_won = base_value * 10  # Smaller multiplier for pair
                    multiplier = 10
                    win_type = "pair"
                    break
        
        # Special combinations
        if set(reels) == {"🍀", "💎", "🔔"}:
            # Lucky combo bonus
            coins_won = max(coins_won, 100)
            win_type = "lucky_combo"
        
        # Update user stats
        if coins_won > 0:
            update_coins(user_id, coins_won)
        
        update_game_stats(
            user_id, 
            "slot", 
            played=1, 
            won=1 if coins_won > 0 else 0, 
            score=coins_won
        )
        
        # Create embed
        embed = discord.Embed(
            title="🎰 Slot Machine",
            color=0xffd700 if coins_won > 0 else 0x808080
        )
        
        # Create slot display
        slot_display = f"""
        ╔═══════════════╗
        ║  {reels[0]}  {reels[1]}  {reels[2]}  ║
        ╚═══════════════╝
        """
        
        embed.add_field(
            name="🎲 Your Spin",
            value=f"```{slot_display}```",
            inline=False
        )
        
        # Result message based on win type
        if win_type == "jackpot":
            embed.add_field(
                name="🎉 JACKPOT! 🎉",
                value=f"THREE OF A KIND! You won **{coins_won} coins**!",
                inline=False
            )
            embed.color = 0xffd700
            embed.set_footer(text="🎰 MEGA WIN! 🎰")
        elif win_type == "pair":
            embed.add_field(
                name="✨ Nice Win!",
                value=f"Two of a kind! You won **{coins_won} coins**!",
                inline=False
            )
            embed.color = 0x00ff00
        elif win_type == "lucky_combo":
            embed.add_field(
                name="🍀 Lucky Combination!",
                value=f"Special combo bonus! You won **{coins_won} coins**!",
                inline=False
            )
            embed.color = 0x9b59b6
        else:
            embed.add_field(
                name="😔 No Win",
                value="Better luck next time! Keep spinning!",
                inline=False
            )
            embed.color = 0xff6b6b
        
        # Add symbol values reference
        symbol_values = "\n".join([f"{symbol} = {data['value']}x" for symbol, data in symbols.items()])
        embed.add_field(
            name="💰 Symbol Values",
            value=f"```{symbol_values}```",
            inline=True
        )
        
        embed.add_field(
            name="🎯 Payouts",
            value="```\n3 of a kind: 50x\n2 of a kind: 10x\nSpecial combo: 100+```",
            inline=True
        )
        
        embed.set_footer(text=f"Spun by {interaction.user.display_name}")
        
        await interaction.response.send_message(embed=embed)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while spinning the slot machine. Please try again!", 
            ephemeral=True
        )
        print(f"Slot machine error: {e}")
