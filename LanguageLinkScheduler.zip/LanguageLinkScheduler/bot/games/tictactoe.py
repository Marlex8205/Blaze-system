import discord
import random
from utils.economy import update_coins, update_game_stats

class TicTacToeView(discord.ui.View):
    def __init__(self, user_id: str):
        super().__init__(timeout=120.0)
        self.user_id = user_id
        self.board = [" "] * 9  # Empty board
        self.game_over = False
        self.user_symbol = "❌"
        self.bot_symbol = "⭕"
        
        # Create 3x3 grid of buttons
        for i in range(9):
            button = discord.ui.Button(
                label="\u200b",  # Invisible character
                style=discord.ButtonStyle.secondary,
                custom_id=f"pos_{i}",
                row=i // 3
            )
            button.callback = self.button_callback
            self.add_item(button)
    
    def check_winner(self):
        """Check if there's a winner"""
        winning_combinations = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8],  # Rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8],  # Columns
            [0, 4, 8], [2, 4, 6]              # Diagonals
        ]
        
        for combo in winning_combinations:
            if (self.board[combo[0]] == self.board[combo[1]] == self.board[combo[2]] != " "):
                return self.board[combo[0]]
        
        if " " not in self.board:
            return "tie"
        
        return None
    
    def get_board_display(self):
        """Get formatted board display"""
        display_board = []
        for cell in self.board:
            if cell == " ":
                display_board.append("⬜")
            else:
                display_board.append(cell)
        
        return f"{display_board[0]}{display_board[1]}{display_board[2]}\n{display_board[3]}{display_board[4]}{display_board[5]}\n{display_board[6]}{display_board[7]}{display_board[8]}"
    
    def make_bot_move(self):
        """Make bot move with simple AI"""
        # Check if bot can win
        for i in range(9):
            if self.board[i] == " ":
                self.board[i] = self.bot_symbol
                if self.check_winner() == self.bot_symbol:
                    return i  # Winning move
                self.board[i] = " "  # Undo
        
        # Check if bot needs to block user
        for i in range(9):
            if self.board[i] == " ":
                self.board[i] = self.user_symbol
                if self.check_winner() == self.user_symbol:
                    self.board[i] = self.bot_symbol
                    return i  # Blocking move
                self.board[i] = " "  # Undo
        
        # Take center if available
        if self.board[4] == " ":
            self.board[4] = self.bot_symbol
            return 4
        
        # Take corners
        corners = [0, 2, 6, 8]
        available_corners = [i for i in corners if self.board[i] == " "]
        if available_corners:
            move = random.choice(available_corners)
            self.board[move] = self.bot_symbol
            return move
        
        # Take any available space
        available = [i for i in range(9) if self.board[i] == " "]
        if available:
            move = random.choice(available)
            self.board[move] = self.bot_symbol
            return move
        
        return None
    
    async def button_callback(self, interaction: discord.Interaction):
        if interaction.user.id != int(self.user_id):
            await interaction.response.send_message(
                "❌ This isn't your Tic Tac Toe game!", ephemeral=True
            )
            return
        
        if self.game_over:
            return
        
        # Get position from button
        position = int(interaction.data['custom_id'].split('_')[1])
        
        # Check if position is available
        if self.board[position] != " ":
            await interaction.response.send_message(
                "❌ That position is already taken!", ephemeral=True
            )
            return
        
        # Make user move
        self.board[position] = self.user_symbol
        
        # Update button
        for item in self.children:
            if hasattr(item, 'custom_id') and item.custom_id == f"pos_{position}":
                item.label = self.user_symbol
                item.disabled = True
                item.style = discord.ButtonStyle.primary
                break
        
        # Check for winner after user move
        winner = self.check_winner()
        if winner:
            self.game_over = True
            await self.end_game(interaction, winner)
            return
        
        # Make bot move
        bot_move = self.make_bot_move()
        if bot_move is not None:
            # Update bot's button
            for item in self.children:
                if hasattr(item, 'custom_id') and item.custom_id == f"pos_{bot_move}":
                    item.label = self.bot_symbol
                    item.disabled = True
                    item.style = discord.ButtonStyle.danger
                    break
        
        # Check for winner after bot move
        winner = self.check_winner()
        if winner:
            self.game_over = True
            await self.end_game(interaction, winner)
            return
        
        # Continue game
        embed = discord.Embed(
            title="❌ Tic Tac Toe",
            description="Your turn! Choose your next move.",
            color=0x3498db
        )
        
        embed.add_field(
            name="🎮 Game Board",
            value=self.get_board_display(),
            inline=False
        )
        
        embed.add_field(
            name="📊 Players",
            value=f"You: {self.user_symbol} | Bot: {self.bot_symbol}",
            inline=False
        )
        
        embed.set_footer(text=f"Tic Tac Toe game for {interaction.user.display_name}")
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def end_game(self, interaction: discord.Interaction, winner):
        """End the game and show results"""
        # Disable all buttons
        for item in self.children:
            item.disabled = True
        
        coins_won = 0
        if winner == self.user_symbol:
            coins_won = 25
            title = "🎉 Tic Tac Toe - You Win!"
            description = "Congratulations! You beat the bot!"
            color = 0x00ff00
            update_coins(self.user_id, coins_won)
            update_game_stats(self.user_id, "tictactoe", played=1, won=1, score=coins_won)
        elif winner == self.bot_symbol:
            title = "🤖 Tic Tac Toe - Bot Wins!"
            description = "The bot outsmarted you this time!"
            color = 0xff6b6b
            update_game_stats(self.user_id, "tictactoe", played=1, won=0, score=0)
        else:  # tie
            coins_won = 10
            title = "🤝 Tic Tac Toe - It's a Tie!"
            description = "Great game! A well-fought battle!"
            color = 0xf39c12
            update_coins(self.user_id, coins_won)
            update_game_stats(self.user_id, "tictactoe", played=1, won=0, score=coins_won)
        
        embed = discord.Embed(
            title=title,
            description=description,
            color=color
        )
        
        embed.add_field(
            name="🎮 Final Board",
            value=self.get_board_display(),
            inline=False
        )
        
        if coins_won > 0:
            embed.add_field(
                name="💰 Coins Earned",
                value=f"**{coins_won} coins**",
                inline=True
            )
        
        embed.add_field(
            name="📊 Game Result",
            value=f"Winner: {winner if winner != 'tie' else 'Nobody (Tie)'}",
            inline=True
        )
        
        embed.add_field(
            name="🎯 Strategy Tip",
            value="Control the center and corners for better chances!",
            inline=False
        )
        
        embed.set_footer(text=f"Game completed by {interaction.user.display_name}")
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def on_timeout(self):
        if not self.game_over:
            update_game_stats(self.user_id, "tictactoe", played=1, won=0, score=0)
        
        for item in self.children:
            item.disabled = True

async def execute(interaction: discord.Interaction):
    """Execute Tic Tac Toe game"""
    try:
        user_id = str(interaction.user.id)
        
        # Create initial embed
        embed = discord.Embed(
            title="❌ Tic Tac Toe Challenge",
            description="Play against the bot! Get three in a row to win!",
            color=0x3498db
        )
        
        embed.add_field(
            name="🎯 How to Play",
            value="Click on any empty square to place your ❌",
            inline=False
        )
        
        embed.add_field(
            name="🏆 Rewards",
            value="**25 coins** for winning, **10 coins** for a tie",
            inline=True
        )
        
        embed.add_field(
            name="⏰ Time Limit",
            value="**2 minutes** per game",
            inline=True
        )
        
        embed.add_field(
            name="🎮 Game Board",
            value="⬜⬜⬜\n⬜⬜⬜\n⬜⬜⬜",
            inline=False
        )
        
        embed.add_field(
            name="📊 Players",
            value="You: ❌ | Bot: ⭕",
            inline=False
        )
        
        embed.set_footer(text=f"Tic Tac Toe game for {interaction.user.display_name}")
        
        # Create view
        view = TicTacToeView(user_id)
        
        await interaction.response.send_message(embed=embed, view=view)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while starting Tic Tac Toe. Please try again!", 
            ephemeral=True
        )
        print(f"Tic Tac Toe error: {e}")
