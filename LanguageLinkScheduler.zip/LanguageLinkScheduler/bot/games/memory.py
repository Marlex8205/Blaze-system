import discord
import random
import asyncio
from utils.economy import update_coins, update_game_stats

class MemoryGameView(discord.ui.View):
    def __init__(self, sequence: list, user_id: str, round_num: int):
        super().__init__(timeout=30.0)
        self.sequence = sequence
        self.user_id = user_id
        self.round_num = round_num
        self.user_sequence = []
        self.answered = False
        
        # Available emojis for memory game
        self.emojis = ["🔴", "🟢", "🔵", "🟡", "🟣", "🟠"]
        
        # Create buttons for each emoji
        for emoji in self.emojis:
            button = discord.ui.Button(
                emoji=emoji,
                style=discord.ButtonStyle.secondary,
                custom_id=f"emoji_{emoji}"
            )
            button.callback = self.emoji_callback
            self.add_item(button)
    
    async def emoji_callback(self, interaction: discord.Interaction):
        if interaction.user.id != int(self.user_id):
            await interaction.response.send_message(
                "❌ This isn't your memory game!", ephemeral=True
            )
            return
        
        if self.answered:
            return
        
        # Get the selected emoji
        selected_emoji = interaction.data['custom_id'].split('_')[1]
        self.user_sequence.append(selected_emoji)
        
        # Check if sequence is complete
        if len(self.user_sequence) == len(self.sequence):
            self.answered = True
            
            # Check if correct
            if self.user_sequence == self.sequence:
                # Correct! Move to next round
                coins_earned = self.round_num * 5  # Escalating rewards
                update_coins(self.user_id, coins_earned)
                update_game_stats(
                    self.user_id, 
                    "memory", 
                    played=1, 
                    won=1, 
                    score=self.round_num
                )
                
                # Disable all buttons
                for item in self.children:
                    item.disabled = True
                
                embed = discord.Embed(
                    title="🧠 Memory Game - Round Complete!",
                    description=f"Perfect memory! You completed round {self.round_num}!",
                    color=0x00ff00
                )
                
                embed.add_field(
                    name="🎉 Success!",
                    value=f"You earned **{coins_earned} coins** for this round!",
                    inline=False
                )
                
                embed.add_field(
                    name="🔄 Next Round",
                    value="Use `/memory` again to try a longer sequence!",
                    inline=False
                )
                
                embed.add_field(
                    name="📊 Your Sequence",
                    value="".join(self.user_sequence),
                    inline=True
                )
                
                embed.add_field(
                    name="✅ Correct Sequence",
                    value="".join(self.sequence),
                    inline=True
                )
                
                embed.set_footer(text=f"Round {self.round_num} completed by {interaction.user.display_name}")
                
                await interaction.response.edit_message(embed=embed, view=self)
            else:
                # Wrong sequence
                update_game_stats(self.user_id, "memory", played=1, won=0, score=0)
                
                # Disable all buttons
                for item in self.children:
                    item.disabled = True
                
                embed = discord.Embed(
                    title="🧠 Memory Game - Game Over",
                    description=f"Oops! Your memory failed you this time.",
                    color=0xff6b6b
                )
                
                embed.add_field(
                    name="❌ Incorrect Sequence",
                    value=f"You made it to round {self.round_num} though!",
                    inline=False
                )
                
                embed.add_field(
                    name="📊 Your Sequence",
                    value="".join(self.user_sequence),
                    inline=True
                )
                
                embed.add_field(
                    name="✅ Correct Sequence",
                    value="".join(self.sequence),
                    inline=True
                )
                
                embed.add_field(
                    name="💡 Tip",
                    value="Try to create mental patterns or stories to remember sequences!",
                    inline=False
                )
                
                embed.set_footer(text=f"Game over for {interaction.user.display_name}")
                
                await interaction.response.edit_message(embed=embed, view=self)
        else:
            # Sequence not complete yet, check current progress
            current_index = len(self.user_sequence) - 1
            if self.user_sequence[current_index] != self.sequence[current_index]:
                # Wrong emoji at this position - game over
                self.answered = True
                update_game_stats(self.user_id, "memory", played=1, won=0, score=0)
                
                # Disable all buttons
                for item in self.children:
                    item.disabled = True
                
                embed = discord.Embed(
                    title="🧠 Memory Game - Game Over",
                    description=f"Wrong emoji! Your sequence broke at position {current_index + 1}.",
                    color=0xff6b6b
                )
                
                embed.add_field(
                    name="📊 Your Progress",
                    value=f"You got {current_index} correct before the mistake.",
                    inline=False
                )
                
                embed.add_field(
                    name="✅ Correct Sequence",
                    value="".join(self.sequence),
                    inline=False
                )
                
                embed.set_footer(text=f"Game over for {interaction.user.display_name}")
                
                await interaction.response.edit_message(embed=embed, view=self)
            else:
                # Correct so far, update the embed to show progress
                progress = "".join(self.user_sequence) + "❓" * (len(self.sequence) - len(self.user_sequence))
                
                embed = discord.Embed(
                    title="🧠 Memory Game - In Progress",
                    description=f"Great! Keep going... ({len(self.user_sequence)}/{len(self.sequence)})",
                    color=0xf39c12
                )
                
                embed.add_field(
                    name="📊 Your Progress",
                    value=progress,
                    inline=False
                )
                
                embed.add_field(
                    name="⏰ Time Remaining",
                    value="30 seconds per round",
                    inline=False
                )
                
                embed.set_footer(text=f"Round {self.round_num} for {interaction.user.display_name}")
                
                await interaction.response.edit_message(embed=embed, view=self)
    
    async def on_timeout(self):
        if not self.answered:
            update_game_stats(self.user_id, "memory", played=1, won=0, score=0)
        
        for item in self.children:
            item.disabled = True

async def execute(interaction: discord.Interaction):
    """Execute memory game"""
    try:
        user_id = str(interaction.user.id)
        
        # Determine round number (start with round 3, can be expanded later)
        round_num = random.randint(3, 6)  # 3-6 emojis to remember
        
        # Available emojis
        emojis = ["🔴", "🟢", "🔵", "🟡", "🟣", "🟠"]
        
        # Generate random sequence
        sequence = [random.choice(emojis) for _ in range(round_num)]
        
        # Create initial embed showing the sequence
        embed = discord.Embed(
            title="🧠 Memory Game Challenge",
            description=f"Memorize this sequence of {round_num} emojis!",
            color=0x3498db
        )
        
        embed.add_field(
            name="📝 Sequence to Remember",
            value="".join(sequence),
            inline=False
        )
        
        embed.add_field(
            name="⏰ Memorization Time",
            value="You have 5 seconds to memorize!",
            inline=False
        )
        
        embed.add_field(
            name="💰 Reward",
            value=f"**{round_num * 5} coins** for completing this round!",
            inline=False
        )
        
        embed.set_footer(text=f"Round {round_num} for {interaction.user.display_name}")
        
        await interaction.response.send_message(embed=embed)
        
        # Wait 5 seconds for memorization
        await asyncio.sleep(5)
        
        # Update embed to hide sequence and show input buttons
        game_embed = discord.Embed(
            title="🧠 Memory Game - Your Turn!",
            description=f"Now repeat the sequence by clicking the emojis in order!",
            color=0xf39c12
        )
        
        game_embed.add_field(
            name="🎯 Your Task",
            value=f"Repeat the {round_num}-emoji sequence you just saw!",
            inline=False
        )
        
        game_embed.add_field(
            name="📊 Progress",
            value="❓" * round_num,
            inline=False
        )
        
        game_embed.add_field(
            name="⏰ Time Limit",
            value="30 seconds to complete the sequence!",
            inline=False
        )
        
        game_embed.set_footer(text=f"Round {round_num} for {interaction.user.display_name}")
        
        # Create view with emoji buttons
        view = MemoryGameView(sequence, user_id, round_num)
        
        await interaction.edit_original_response(embed=game_embed, view=view)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while starting the memory game. Please try again!", 
            ephemeral=True
        )
        print(f"Memory game error: {e}")
