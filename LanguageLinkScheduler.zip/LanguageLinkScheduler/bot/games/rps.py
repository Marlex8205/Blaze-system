import discord
import random
from utils.economy import update_coins, update_game_stats

async def execute(interaction: discord.Interaction, choice: str):
    """Execute Rock Paper Scissors game"""
    try:
        user_id = str(interaction.user.id)
        
        # Validate choice
        valid_choices = ["rock", "paper", "scissors"]
        choice = choice.lower()
        
        if choice not in valid_choices:
            await interaction.response.send_message(
                "❌ Invalid choice! Please choose: rock, paper, or scissors",
                ephemeral=True
            )
            return
        
        # Bot makes a choice
        bot_choice = random.choice(valid_choices)
        
        # Determine winner
        def determine_winner(user, bot):
            if user == bot:
                return "tie"
            elif (user == "rock" and bot == "scissors") or \
                 (user == "paper" and bot == "rock") or \
                 (user == "scissors" and bot == "paper"):
                return "user"
            else:
                return "bot"
        
        result = determine_winner(choice, bot_choice)
        
        # Emoji mapping
        emoji_map = {
            "rock": "🪨",
            "paper": "📄", 
            "scissors": "✂️"
        }
        
        # Calculate coins
        coins_won = 0
        if result == "user":
            coins_won = 15
            update_coins(user_id, coins_won)
        
        # Update stats
        update_game_stats(
            user_id, 
            "rps", 
            played=1, 
            won=1 if result == "user" else 0, 
            score=coins_won
        )
        
        # Create embed
        embed = discord.Embed(title="✂️ Rock Paper Scissors", color=0x9b59b6)
        
        embed.add_field(
            name="Your Choice",
            value=f"{emoji_map[choice]} {choice.title()}",
            inline=True
        )
        
        embed.add_field(
            name="Bot's Choice", 
            value=f"{emoji_map[bot_choice]} {bot_choice.title()}",
            inline=True
        )
        
        embed.add_field(name="\u200b", value="\u200b", inline=True)  # Empty field for spacing
        
        if result == "user":
            embed.add_field(
                name="🎉 You Win!",
                value=f"Congratulations! You earned **{coins_won} coins**!",
                inline=False
            )
            embed.color = 0x00ff00
        elif result == "bot":
            embed.add_field(
                name="😔 You Lose!",
                value="Better luck next time!",
                inline=False
            )
            embed.color = 0xff6b6b
        else:
            embed.add_field(
                name="🤝 It's a Tie!",
                value="Great minds think alike!",
                inline=False
            )
            embed.color = 0xf39c12
        
        embed.set_footer(text=f"Game played by {interaction.user.display_name}")
        
        await interaction.response.send_message(embed=embed)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while playing Rock Paper Scissors. Please try again!", 
            ephemeral=True
        )
        print(f"RPS error: {e}")
