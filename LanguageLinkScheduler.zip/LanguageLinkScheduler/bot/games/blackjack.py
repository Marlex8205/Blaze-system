import discord
import random
from utils.economy import update_coins, update_game_stats

class BlackjackView(discord.ui.View):
    def __init__(self, user_id: str):
        super().__init__(timeout=120.0)
        self.user_id = user_id
        self.deck = self.create_deck()
        self.player_hand = []
        self.dealer_hand = []
        self.game_over = False
        self.bet_amount = 20  # Fixed bet amount
        
        # Deal initial cards
        self.deal_initial_cards()
    
    def create_deck(self):
        """Create a standard 52-card deck"""
        suits = ["♠️", "♥️", "♦️", "♣️"]
        ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
        deck = []
        
        for suit in suits:
            for rank in ranks:
                deck.append(f"{rank}{suit}")
        
        random.shuffle(deck)
        return deck
    
    def deal_card(self):
        """Deal one card from the deck"""
        return self.deck.pop() if self.deck else "A♠️"  # Fallback
    
    def deal_initial_cards(self):
        """Deal initial two cards to player and dealer"""
        self.player_hand = [self.deal_card(), self.deal_card()]
        self.dealer_hand = [self.deal_card(), self.deal_card()]
    
    def get_card_value(self, card):
        """Get numerical value of a card"""
        rank = card[:-2] if len(card) > 2 else card[:-1]
        
        if rank in ["J", "Q", "K"]:
            return 10
        elif rank == "A":
            return 11  # Ace value will be adjusted in hand calculation
        else:
            return int(rank)
    
    def calculate_hand_value(self, hand):
        """Calculate the total value of a hand"""
        total = 0
        aces = 0
        
        for card in hand:
            value = self.get_card_value(card)
            if value == 11:  # Ace
                aces += 1
            total += value
        
        # Adjust for Aces
        while total > 21 and aces > 0:
            total -= 10  # Convert Ace from 11 to 1
            aces -= 1
        
        return total
    
    def get_hand_display(self, hand, hide_first=False):
        """Get formatted display of a hand"""
        if hide_first:
            return f"🂠 {hand[1]}"
        return " ".join(hand)
    
    @discord.ui.button(label="Hit", style=discord.ButtonStyle.primary, emoji="🃏")
    async def hit_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != int(self.user_id):
            await interaction.response.send_message(
                "❌ This isn't your blackjack game!", ephemeral=True
            )
            return
        
        if self.game_over:
            return
        
        # Deal a card to player
        self.player_hand.append(self.deal_card())
        player_value = self.calculate_hand_value(self.player_hand)
        
        if player_value > 21:
            # Player busts
            self.game_over = True
            await self.end_game(interaction, "bust")
        elif player_value == 21:
            # Player got 21, dealer's turn
            await self.dealer_turn(interaction)
        else:
            # Continue game
            await self.update_game_display(interaction)
    
    @discord.ui.button(label="Stand", style=discord.ButtonStyle.secondary, emoji="🛑")
    async def stand_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != int(self.user_id):
            await interaction.response.send_message(
                "❌ This isn't your blackjack game!", ephemeral=True
            )
            return
        
        if self.game_over:
            return
        
        # Player stands, dealer's turn
        await self.dealer_turn(interaction)
    
    @discord.ui.button(label="Double Down", style=discord.ButtonStyle.success, emoji="💰")
    async def double_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != int(self.user_id):
            await interaction.response.send_message(
                "❌ This isn't your blackjack game!", ephemeral=True
            )
            return
        
        if self.game_over or len(self.player_hand) != 2:
            await interaction.response.send_message(
                "❌ Can only double down on first turn!", ephemeral=True
            )
            return
        
        # Double the bet and take exactly one more card
        self.bet_amount *= 2
        self.player_hand.append(self.deal_card())
        
        player_value = self.calculate_hand_value(self.player_hand)
        
        if player_value > 21:
            self.game_over = True
            await self.end_game(interaction, "bust")
        else:
            await self.dealer_turn(interaction)
    
    async def dealer_turn(self, interaction):
        """Handle dealer's turn"""
        dealer_value = self.calculate_hand_value(self.dealer_hand)
        
        # Dealer hits on 16 and below, stands on 17 and above
        while dealer_value < 17:
            self.dealer_hand.append(self.deal_card())
            dealer_value = self.calculate_hand_value(self.dealer_hand)
        
        # Determine winner
        player_value = self.calculate_hand_value(self.player_hand)
        
        if dealer_value > 21:
            await self.end_game(interaction, "dealer_bust")
        elif dealer_value > player_value:
            await self.end_game(interaction, "dealer_wins")
        elif player_value > dealer_value:
            await self.end_game(interaction, "player_wins")
        else:
            await self.end_game(interaction, "tie")
    
    async def update_game_display(self, interaction):
        """Update the game display"""
        player_value = self.calculate_hand_value(self.player_hand)
        
        embed = discord.Embed(
            title="🃏 Blackjack Game",
            description="Choose your next move!",
            color=0x2ecc71
        )
        
        embed.add_field(
            name="🎴 Your Hand",
            value=f"{self.get_hand_display(self.player_hand)}\n**Value: {player_value}**",
            inline=True
        )
        
        embed.add_field(
            name="🤖 Dealer's Hand",
            value=f"{self.get_hand_display(self.dealer_hand, hide_first=True)}\n**Value: ?**",
            inline=True
        )
        
        embed.add_field(
            name="💰 Current Bet",
            value=f"**{self.bet_amount} coins**",
            inline=True
        )
        
        embed.add_field(
            name="🎯 Goal",
            value="Get as close to 21 as possible without going over!",
            inline=False
        )
        
        embed.set_footer(text=f"Blackjack game for {interaction.user.display_name}")
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def end_game(self, interaction, result):
        """End the game and show results"""
        self.game_over = True
        
        # Disable all buttons
        for item in self.children:
            item.disabled = True
        
        player_value = self.calculate_hand_value(self.player_hand)
        dealer_value = self.calculate_hand_value(self.dealer_hand)
        
        coins_change = 0
        title = ""
        description = ""
        color = 0x95a5a6
        
        if result == "bust":
            title = "💥 Bust! You Lose!"
            description = f"Your hand value ({player_value}) exceeded 21!"
            color = 0xe74c3c
            coins_change = -self.bet_amount
        elif result == "dealer_bust":
            title = "🎉 Dealer Busts! You Win!"
            description = f"Dealer went over 21 with {dealer_value}!"
            color = 0x2ecc71
            coins_change = self.bet_amount
        elif result == "player_wins":
            title = "🎉 You Win!"
            description = f"Your {player_value} beats dealer's {dealer_value}!"
            color = 0x2ecc71
            coins_change = self.bet_amount
        elif result == "dealer_wins":
            title = "😔 Dealer Wins!"
            description = f"Dealer's {dealer_value} beats your {player_value}!"
            color = 0xe74c3c
            coins_change = -self.bet_amount
        elif result == "tie":
            title = "🤝 Push (Tie)!"
            description = f"Both have {player_value}. Your bet is returned!"
            color = 0xf39c12
            coins_change = 0
        
        # Check for blackjack bonus
        if len(self.player_hand) == 2 and player_value == 21:
            if result == "player_wins":
                title = "🎰 BLACKJACK!"
                description = "Natural 21! You get a bonus!"
                coins_change = int(self.bet_amount * 1.5)  # 3:2 payout
        
        # Update user stats and coins
        if coins_change > 0:
            update_coins(self.user_id, coins_change)
            update_game_stats(self.user_id, "blackjack", played=1, won=1, score=coins_change)
        else:
            update_game_stats(self.user_id, "blackjack", played=1, won=0, score=0)
        
        embed = discord.Embed(
            title=title,
            description=description,
            color=color
        )
        
        embed.add_field(
            name="🎴 Your Final Hand",
            value=f"{self.get_hand_display(self.player_hand)}\n**Value: {player_value}**",
            inline=True
        )
        
        embed.add_field(
            name="🤖 Dealer's Final Hand",
            value=f"{self.get_hand_display(self.dealer_hand)}\n**Value: {dealer_value}**",
            inline=True
        )
        
        if coins_change > 0:
            embed.add_field(
                name="💰 Coins Won",
                value=f"**+{coins_change} coins**",
                inline=True
            )
        elif coins_change < 0:
            embed.add_field(
                name="💸 Coins Lost",
                value=f"**{coins_change} coins**",
                inline=True
            )
        else:
            embed.add_field(
                name="💰 Coins",
                value="**No change (Push)**",
                inline=True
            )
        
        embed.add_field(
            name="🎯 Game Summary",
            value=f"Bet Amount: {self.bet_amount} coins\nResult: {result.replace('_', ' ').title()}",
            inline=False
        )
        
        embed.set_footer(text=f"Blackjack game completed by {interaction.user.display_name}")
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def on_timeout(self):
        if not self.game_over:
            update_game_stats(self.user_id, "blackjack", played=1, won=0, score=0)
        
        for item in self.children:
            item.disabled = True

async def execute(interaction: discord.Interaction):
    """Execute blackjack game"""
    try:
        user_id = str(interaction.user.id)
        
        # Create initial embed and game
        embed = discord.Embed(
            title="🃏 Blackjack Challenge",
            description="Get as close to 21 as possible without going over!",
            color=0x2ecc71
        )
        
        embed.add_field(
            name="🎯 Rules",
            value="• Get closer to 21 than the dealer\n• Don't go over 21 (bust)\n• Aces = 1 or 11, Face cards = 10",
            inline=False
        )
        
        embed.add_field(
            name="💰 Betting",
            value="**Fixed bet: 20 coins**",
            inline=True
        )
        
        embed.add_field(
            name="🎰 Payouts",
            value="**Win: +20 coins**\n**Blackjack: +30 coins**\n**Lose: -20 coins**",
            inline=True
        )
        
        embed.add_field(
            name="⏰ Time Limit",
            value="**2 minutes** per game",
            inline=True
        )
        
        embed.set_footer(text=f"Blackjack game for {interaction.user.display_name}")
        
        # Create view and start game
        view = BlackjackView(user_id)
        
        # Update embed with initial hands
        player_value = view.calculate_hand_value(view.player_hand)
        
        embed.add_field(
            name="🎴 Your Hand",
            value=f"{view.get_hand_display(view.player_hand)}\n**Value: {player_value}**",
            inline=True
        )
        
        embed.add_field(
            name="🤖 Dealer's Hand",
            value=f"{view.get_hand_display(view.dealer_hand, hide_first=True)}\n**Value: ?**",
            inline=True
        )
        
        # Check for immediate blackjack
        if player_value == 21:
            view.game_over = True
            await view.dealer_turn(interaction)
            return
        
        await interaction.response.send_message(embed=embed, view=view)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while starting blackjack. Please try again!", 
            ephemeral=True
        )
        print(f"Blackjack error: {e}")
