import discord
import random
from utils.economy import update_coins, update_game_stats

class RiddleView(discord.ui.View):
    def __init__(self, answer: str, user_id: str, difficulty: str):
        super().__init__(timeout=120.0)  # 2 minutes to answer
        self.answer = answer.lower()
        self.user_id = user_id
        self.difficulty = difficulty
        self.answered = False
        
        # Rewards based on difficulty
        self.rewards = {"easy": 15, "medium": 25, "hard": 40}
    
    @discord.ui.button(label="Give Up", style=discord.ButtonStyle.danger, emoji="🏳️")
    async def give_up(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != int(self.user_id):
            await interaction.response.send_message(
                "❌ This isn't your riddle!", ephemeral=True
            )
            return
        
        if self.answered:
            return
        
        self.answered = True
        update_game_stats(self.user_id, "riddle", played=1, won=0, score=0)
        
        # Disable button
        button.disabled = True
        
        embed = discord.Embed(
            title="🤔 Riddle - Given Up",
            description=f"The answer was: **{self.answer.title()}**",
            color=0xff6b6b
        )
        
        embed.add_field(
            name="💡 Don't Give Up!",
            value="Keep practicing your problem-solving skills!",
            inline=False
        )
        
        embed.set_footer(text=f"Riddle ended by {interaction.user.display_name}")
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def on_timeout(self):
        if not self.answered:
            update_game_stats(self.user_id, "riddle", played=1, won=0, score=0)
        
        for item in self.children:
            item.disabled = True

async def execute(interaction: discord.Interaction):
    """Execute riddle game"""
    try:
        user_id = str(interaction.user.id)
        
        # Riddle database organized by difficulty
        riddles = {
            "easy": [
                {
                    "riddle": "I have keys but no locks. I have space but no room. You can enter, but you can't go outside. What am I?",
                    "answer": "keyboard"
                },
                {
                    "riddle": "What has hands but cannot clap?",
                    "answer": "clock"
                },
                {
                    "riddle": "What gets wet while drying?",
                    "answer": "towel"
                },
                {
                    "riddle": "I'm tall when I'm young, and I'm short when I'm old. What am I?",
                    "answer": "candle"
                },
                {
                    "riddle": "What has one eye but cannot see?",
                    "answer": "needle"
                },
                {
                    "riddle": "What goes up but never comes down?",
                    "answer": "age"
                }
            ],
            "medium": [
                {
                    "riddle": "I speak without a mouth and hear without ears. I have no body, but I come alive with wind. What am I?",
                    "answer": "echo"
                },
                {
                    "riddle": "The more you take, the more you leave behind. What are they?",
                    "answer": "footsteps"
                },
                {
                    "riddle": "I have cities, but no houses. I have mountains, but no trees. I have water, but no fish. What am I?",
                    "answer": "map"
                },
                {
                    "riddle": "What can travel around the world while staying in a corner?",
                    "answer": "stamp"
                },
                {
                    "riddle": "I am not alive, but I grow; I don't have lungs, but I need air; I don't have a mouth, but water kills me. What am I?",
                    "answer": "fire"
                }
            ],
            "hard": [
                {
                    "riddle": "I am taken from a mine, and shut up in a wooden case, from which I am never released, and yet I am used by almost everybody. What am I?",
                    "answer": "pencil lead"
                },
                {
                    "riddle": "What disappears as soon as you say its name?",
                    "answer": "silence"
                },
                {
                    "riddle": "I have no beginning, middle, or end. I am always moving, but I never go anywhere. What am I?",
                    "answer": "circle"
                },
                {
                    "riddle": "The person who makes it has no need for it. The person who purchases it does not use it. The person who does use it does not know they are. What is it?",
                    "answer": "coffin"
                },
                {
                    "riddle": "What word becomes shorter when you add two letters to it?",
                    "answer": "short"
                }
            ]
        }
        
        # Choose difficulty and riddle
        difficulty = random.choice(["easy", "medium", "hard"])
        riddle_data = random.choice(riddles[difficulty])
        
        # Create embed
        embed = discord.Embed(
            title="🤔 Riddle Challenge",
            description=riddle_data["riddle"],
            color=0x9b59b6
        )
        
        embed.add_field(
            name="📊 Difficulty",
            value=f"**{difficulty.title()}**",
            inline=True
        )
        
        embed.add_field(
            name="💰 Reward",
            value=f"**{15 if difficulty == 'easy' else 25 if difficulty == 'medium' else 40} coins**",
            inline=True
        )
        
        embed.add_field(
            name="⏰ Time Limit",
            value="**2 minutes**",
            inline=True
        )
        
        embed.add_field(
            name="💡 How to Answer",
            value="Type your answer in chat or click 'Give Up' to see the solution!",
            inline=False
        )
        
        embed.set_footer(text=f"Riddle for {interaction.user.display_name} • Think carefully!")
        
        # Create view
        view = RiddleView(riddle_data["answer"], user_id, difficulty)
        
        await interaction.response.send_message(embed=embed, view=view)
        
        # Wait for user response
        def check(message):
            return (message.author.id == interaction.user.id and 
                   message.channel == interaction.channel)
        
        try:
            # Wait for user's answer
            message = await interaction.client.wait_for('message', timeout=120.0, check=check)
            
            if view.answered:
                return  # Game already ended
            
            user_answer = message.content.lower().strip()
            correct_answer = riddle_data["answer"].lower()
            
            # Check for correct answer (allow some flexibility)
            is_correct = (user_answer == correct_answer or 
                         user_answer in correct_answer or 
                         correct_answer in user_answer)
            
            if is_correct:
                # Correct answer!
                view.answered = True
                
                coins_earned = view.rewards[difficulty]
                update_coins(user_id, coins_earned)
                update_game_stats(user_id, "riddle", played=1, won=1, score=coins_earned)
                
                # Disable buttons
                for item in view.children:
                    item.disabled = True
                
                # Create success embed
                success_embed = discord.Embed(
                    title="🎉 Riddle Solved!",
                    description=f"Brilliant! You solved the riddle!",
                    color=0x00ff00
                )
                
                success_embed.add_field(
                    name="✅ Correct Answer",
                    value=f"**{riddle_data['answer'].title()}**",
                    inline=False
                )
                
                success_embed.add_field(
                    name="💰 Coins Earned",
                    value=f"**{coins_earned} coins**",
                    inline=True
                )
                
                success_embed.add_field(
                    name="📊 Difficulty",
                    value=f"**{difficulty.title()}**",
                    inline=True
                )
                
                success_embed.add_field(
                    name="🧠 Your Answer",
                    value=f"'{user_answer}'",
                    inline=True
                )
                
                success_embed.set_footer(text=f"Solved by {interaction.user.display_name}")
                
                await interaction.edit_original_response(embed=success_embed, view=view)
                
                # React to user's message
                try:
                    await message.add_reaction("🎉")
                    await message.add_reaction("🧠")
                except:
                    pass
            else:
                # Wrong answer
                await message.add_reaction("❌")
                
                # Send hint
                hint_embed = discord.Embed(
                    title="❌ Not Quite Right",
                    description=f"'{user_answer}' is not the answer. Keep thinking!",
                    color=0xff6b6b
                )
                
                # Provide a hint based on difficulty
                if difficulty == "easy":
                    hint = "💡 **Hint:** Think about everyday objects around you!"
                elif difficulty == "medium":
                    hint = "💡 **Hint:** Consider abstract concepts or things with multiple meanings!"
                else:
                    hint = "💡 **Hint:** This requires creative thinking and wordplay!"
                
                hint_embed.add_field(
                    name="Hint",
                    value=hint,
                    inline=False
                )
                
                hint_embed.add_field(
                    name="⏰ Time Remaining",
                    value="You still have time to think!",
                    inline=False
                )
                
                await interaction.followup.send(embed=hint_embed, ephemeral=True)
                
        except asyncio.TimeoutError:
            if not view.answered:
                # Time's up
                view.answered = True
                update_game_stats(user_id, "riddle", played=1, won=0, score=0)
                
                for item in view.children:
                    item.disabled = True
                
                timeout_embed = discord.Embed(
                    title="⏰ Riddle - Time's Up!",
                    description=f"Time ran out! The answer was: **{riddle_data['answer'].title()}**",
                    color=0xf39c12
                )
                
                timeout_embed.add_field(
                    name="💡 Explanation",
                    value="Don't worry! Riddles get easier with practice.",
                    inline=False
                )
                
                timeout_embed.set_footer(text=f"Riddle timed out for {interaction.user.display_name}")
                
                await interaction.edit_original_response(embed=timeout_embed, view=view)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while generating the riddle. Please try again!", 
            ephemeral=True
        )
        print(f"Riddle error: {e}")
