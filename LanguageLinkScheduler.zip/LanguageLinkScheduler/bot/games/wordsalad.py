import discord
import random
from utils.economy import update_coins, update_game_stats

class WordSaladView(discord.ui.View):
    def __init__(self, original_word: str, user_id: str):
        super().__init__(timeout=60.0)
        self.original_word = original_word.lower()
        self.user_id = user_id
        self.answered = False
    
    @discord.ui.button(label="Give Up", style=discord.ButtonStyle.danger, emoji="🏳️")
    async def give_up(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != int(self.user_id):
            await interaction.response.send_message(
                "❌ This isn't your game!", ephemeral=True
            )
            return
        
        if self.answered:
            return
        
        self.answered = True
        
        # Update stats (played but not won)
        update_game_stats(self.user_id, "wordsalad", played=1, won=0, score=0)
        
        # Disable all buttons
        for item in self.children:
            item.disabled = True
        
        embed = discord.Embed(
            title="🔤 Word Salad - Game Over",
            description=f"You gave up! The word was: **{self.original_word.title()}**",
            color=0xff6b6b
        )
        
        embed.add_field(
            name="💡 Tip",
            value="Keep practicing to improve your word skills!",
            inline=False
        )
        
        embed.set_footer(text=f"Game ended by {interaction.user.display_name}")
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def on_timeout(self):
        if not self.answered:
            # Auto give up on timeout
            update_game_stats(self.user_id, "wordsalad", played=1, won=0, score=0)
        
        for item in self.children:
            item.disabled = True

async def execute(interaction: discord.Interaction):
    """Execute word salad game"""
    try:
        user_id = str(interaction.user.id)
        
        # Word lists by difficulty
        words = {
            "easy": [
                "apple", "house", "water", "music", "light", "happy", "green", "chair",
                "phone", "bread", "heart", "smile", "dance", "peace", "magic", "ocean"
            ],
            "medium": [
                "computer", "elephant", "rainbow", "mystery", "adventure", "chocolate", 
                "butterfly", "mountain", "treasure", "keyboard", "fantastic", "wonderful",
                "basketball", "sandwich", "umbrella", "photograph"
            ],
            "hard": [
                "programming", "extraordinary", "magnificent", "philosophical", "revolutionary",
                "sophisticated", "entrepreneurship", "pronunciation", "concentration", "refrigerator",
                "accommodation", "responsibility", "entertainment", "organization", "communication"
            ]
        }
        
        # Choose difficulty based on random chance
        difficulty_weights = {"easy": 50, "medium": 35, "hard": 15}
        difficulty = random.choices(
            list(difficulty_weights.keys()), 
            weights=list(difficulty_weights.values())
        )[0]
        
        # Select random word
        word = random.choice(words[difficulty])
        
        # Scramble the word
        word_letters = list(word.lower())
        scrambled_letters = word_letters.copy()
        
        # Ensure it's actually scrambled
        attempts = 0
        while ''.join(scrambled_letters) == word and attempts < 10:
            random.shuffle(scrambled_letters)
            attempts += 1
        
        scrambled_word = ''.join(scrambled_letters)
        
        # Calculate potential reward based on difficulty
        rewards = {"easy": 15, "medium": 25, "hard": 40}
        max_reward = rewards[difficulty]
        
        # Create embed
        embed = discord.Embed(
            title="🔤 Word Salad Challenge",
            description=f"Unscramble the letters to find the hidden word!",
            color=0x3498db
        )
        
        embed.add_field(
            name="🎯 Scrambled Word",
            value=f"**`{scrambled_word.upper()}`**",
            inline=False
        )
        
        embed.add_field(
            name="📊 Difficulty",
            value=f"**{difficulty.title()}**",
            inline=True
        )
        
        embed.add_field(
            name="💰 Reward",
            value=f"**{max_reward} coins**",
            inline=True
        )
        
        embed.add_field(
            name="⏰ Time Limit",
            value="**60 seconds**",
            inline=True
        )
        
        embed.add_field(
            name="💡 How to Play",
            value="Type your answer in chat or click 'Give Up' to see the solution!",
            inline=False
        )
        
        embed.set_footer(text=f"Game for {interaction.user.display_name} • Good luck!")
        
        # Create view
        view = WordSaladView(word, user_id)
        
        await interaction.response.send_message(embed=embed, view=view)
        
        # Wait for user response
        def check(message):
            return (message.author.id == interaction.user.id and 
                   message.channel == interaction.channel)
        
        try:
            # Wait for user's answer
            message = await interaction.client.wait_for('message', timeout=60.0, check=check)
            
            if view.answered:
                return  # Game already ended
            
            user_answer = message.content.lower().strip()
            
            if user_answer == word.lower():
                # Correct answer!
                view.answered = True
                
                # Calculate time bonus (rough estimation)
                time_bonus = random.randint(1, 10)  # Simulate time bonus
                total_coins = max_reward + time_bonus
                
                update_coins(user_id, total_coins)
                update_game_stats(user_id, "wordsalad", played=1, won=1, score=total_coins)
                
                # Disable buttons
                for item in view.children:
                    item.disabled = True
                
                # Create success embed
                success_embed = discord.Embed(
                    title="🎉 Word Salad - Correct!",
                    description=f"Excellent work! You unscrambled **{word.title()}**!",
                    color=0x00ff00
                )
                
                success_embed.add_field(
                    name="💰 Coins Earned",
                    value=f"**{total_coins} coins** ({max_reward} base + {time_bonus} time bonus)",
                    inline=False
                )
                
                success_embed.add_field(
                    name="📊 Difficulty",
                    value=f"**{difficulty.title()}**",
                    inline=True
                )
                
                success_embed.add_field(
                    name="🧠 Word Length",
                    value=f"**{len(word)} letters**",
                    inline=True
                )
                
                success_embed.set_footer(text=f"Solved by {interaction.user.display_name}")
                
                await interaction.edit_original_response(embed=success_embed, view=view)
                
                # React to user's message
                try:
                    await message.add_reaction("🎉")
                except:
                    pass
            else:
                # Wrong answer
                await message.add_reaction("❌")
                
                # Send hint after wrong answer
                hint_embed = discord.Embed(
                    title="❌ Incorrect!",
                    description=f"'{user_answer}' is not correct. Keep trying!",
                    color=0xff6b6b
                )
                
                # Give a hint based on word
                if len(word) > 5:
                    hint = f"💡 **Hint:** The word starts with '{word[0].upper()}' and has {len(word)} letters"
                else:
                    hint = f"💡 **Hint:** The word has {len(word)} letters"
                
                hint_embed.add_field(
                    name="Hint",
                    value=hint,
                    inline=False
                )
                
                await interaction.followup.send(embed=hint_embed, ephemeral=True)
                
        except asyncio.TimeoutError:
            if not view.answered:
                # Time's up
                view.answered = True
                update_game_stats(user_id, "wordsalad", played=1, won=0, score=0)
                
                for item in view.children:
                    item.disabled = True
                
                timeout_embed = discord.Embed(
                    title="⏰ Word Salad - Time's Up!",
                    description=f"Time ran out! The word was: **{word.title()}**",
                    color=0xf39c12
                )
                
                timeout_embed.add_field(
                    name="📚 Definition",
                    value="Try again to improve your word-solving skills!",
                    inline=False
                )
                
                timeout_embed.set_footer(text=f"Game timed out for {interaction.user.display_name}")
                
                await interaction.edit_original_response(embed=timeout_embed, view=view)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while generating the word salad. Please try again!", 
            ephemeral=True
        )
        print(f"Word salad error: {e}")
