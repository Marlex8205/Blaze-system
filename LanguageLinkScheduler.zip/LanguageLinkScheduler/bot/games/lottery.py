import discord
import random
from utils.economy import update_coins, update_game_stats

async def execute(interaction: discord.Interaction):
    """Execute lottery game"""
    try:
        user_id = str(interaction.user.id)
        
        # Lottery settings
        ticket_cost = 10
        max_number = 50
        
        # Generate user's random numbers (6 numbers)
        user_numbers = sorted(random.sample(range(1, max_number + 1), 6))
        
        # Generate winning numbers
        winning_numbers = sorted(random.sample(range(1, max_number + 1), 6))
        
        # Calculate matches
        matches = len(set(user_numbers) & set(winning_numbers))
        
        # Prize structure
        prizes = {
            6: 1000,  # Jackpot!
            5: 200,   # Second prize
            4: 50,    # Third prize
            3: 20,    # Fourth prize
            2: 5,     # Small prize
            1: 0,     # No prize
            0: 0      # No prize
        }
        
        coins_won = prizes.get(matches, 0)
        net_coins = coins_won - ticket_cost
        
        # Update user stats
        if net_coins > 0:
            update_coins(user_id, net_coins)
            update_game_stats(user_id, "lottery", played=1, won=1, score=net_coins)
        else:
            update_game_stats(user_id, "lottery", played=1, won=0, score=0)
        
        # Create embed
        embed = discord.Embed(
            title="🎫 Lottery Results",
            description="Let's see if you're a winner!",
            color=0xffd700 if matches >= 4 else 0x2ecc71 if matches >= 2 else 0xe74c3c
        )
        
        # Display numbers
        embed.add_field(
            name="🎯 Your Numbers",
            value=" ".join([f"**{num}**" for num in user_numbers]),
            inline=False
        )
        
        embed.add_field(
            name="🍀 Winning Numbers",
            value=" ".join([f"**{num}**" if num in user_numbers else str(num) for num in winning_numbers]),
            inline=False
        )
        
        # Show matches with visual indicator
        matched_display = []
        for num in user_numbers:
            if num in winning_numbers:
                matched_display.append(f"✅ **{num}**")
            else:
                matched_display.append(f"❌ {num}")
        
        embed.add_field(
            name="🔍 Your Matches",
            value=" ".join(matched_display),
            inline=False
        )
        
        # Results
        embed.add_field(
            name="📊 Match Results",
            value=f"**{matches}** out of 6 numbers matched!",
            inline=True
        )
        
        embed.add_field(
            name="💰 Ticket Cost",
            value=f"**{ticket_cost} coins**",
            inline=True
        )
        
        # Prize announcement
        if matches == 6:
            embed.add_field(
                name="🎰 JACKPOT! 🎰",
                value=f"**AMAZING!** You won the jackpot!\nPrize: {coins_won} coins\nProfit: +{net_coins} coins",
                inline=False
            )
            embed.color = 0xffd700
        elif matches == 5:
            embed.add_field(
                name="🏆 Second Prize!",
                value=f"Incredible! So close to the jackpot!\nPrize: {coins_won} coins\nProfit: +{net_coins} coins",
                inline=False
            )
            embed.color = 0xff6b6b
        elif matches == 4:
            embed.add_field(
                name="🥉 Third Prize!",
                value=f"Great job! You're a winner!\nPrize: {coins_won} coins\nProfit: +{net_coins} coins",
                inline=False
            )
            embed.color = 0xf39c12
        elif matches == 3:
            embed.add_field(
                name="🎉 Fourth Prize!",
                value=f"Nice! You won a prize!\nPrize: {coins_won} coins\nProfit: +{net_coins} coins",
                inline=False
            )
            embed.color = 0x2ecc71
        elif matches == 2:
            embed.add_field(
                name="🍀 Small Prize!",
                value=f"You got something!\nPrize: {coins_won} coins\nResult: {net_coins:+} coins",
                inline=False
            )
            embed.color = 0x3498db
        else:
            embed.add_field(
                name="😔 No Prize",
                value=f"Better luck next time!\nLoss: -{ticket_cost} coins",
                inline=False
            )
            embed.color = 0x95a5a6
        
        # Prize structure reference
        embed.add_field(
            name="🎰 Prize Structure",
            value="6 matches: 1000 coins 🎆\n5 matches: 200 coins 🏆\n4 matches: 50 coins 🥉\n3 matches: 20 coins 🎉\n2 matches: 5 coins 🍀",
            inline=False
        )
        
        # Add probability info
        embed.set_footer(text="Ticket cost: 10 coins | Good luck! 🍀")
        
        await interaction.response.send_message(embed=embed)
        
    except Exception as e:
        error_embed = discord.Embed(
            title="❌ Error",
            description="Something went wrong with the lottery. Please try again!",
            color=0xe74c3c
        )
        await interaction.response.send_message(embed=error_embed, ephemeral=True)