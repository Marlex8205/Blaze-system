import discord
import random
from utils.economy import update_coins, update_game_stats

async def execute(interaction: discord.Interaction):
    """Execute coinflip game"""
    try:
        user_id = str(interaction.user.id)
        
        # Flip the coin
        result = random.choice(["Heads", "Tails"])
        emoji = "🟡" if result == "Heads" else "🟢"
        
        # Determine reward (50% chance to win 10 coins)
        won = random.choice([True, False])
        coins_won = 10 if won else 0
        
        # Update user stats
        if coins_won > 0:
            update_coins(user_id, coins_won)
        
        update_game_stats(user_id, "coinflip", played=1, won=1 if won else 0, score=coins_won)
        
        # Create embed
        embed = discord.Embed(
            title="🪙 Coinflip Result",
            color=0xffd700 if won else 0x808080
        )
        
        embed.add_field(
            name="Result",
            value=f"{emoji} **{result}**",
            inline=False
        )
        
        if won:
            embed.add_field(
                name="🎉 You Win!",
                value=f"You earned **{coins_won} coins**!",
                inline=False
            )
            embed.color = 0x00ff00
        else:
            embed.add_field(
                name="😔 Better luck next time!",
                value="No coins this time, but keep trying!",
                inline=False
            )
            embed.color = 0xff6b6b
        
        embed.set_footer(text=f"Game played by {interaction.user.display_name}")
        
        await interaction.response.send_message(embed=embed)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while playing coinflip. Please try again!", 
            ephemeral=True
        )
        print(f"Coinflip error: {e}")
