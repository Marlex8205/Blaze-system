import discord
import random
from utils.economy import update_coins, update_game_stats

class MathQuizView(discord.ui.View):
    def __init__(self, correct_answer: int, user_id: str):
        super().__init__(timeout=30.0)
        self.correct_answer = correct_answer
        self.user_id = user_id
        self.answered = False
        
        # Generate 4 answer options (1 correct, 3 wrong)
        options = [correct_answer]
        
        # Generate wrong answers
        for _ in range(3):
            wrong = correct_answer + random.randint(-10, 10)
            if wrong != correct_answer and wrong not in options:
                options.append(wrong)
        
        # If we don't have enough unique options, fill randomly
        while len(options) < 4:
            wrong = random.randint(max(1, correct_answer - 20), correct_answer + 20)
            if wrong not in options:
                options.append(wrong)
        
        random.shuffle(options)
        
        # Create buttons
        for i, option in enumerate(options):
            button = discord.ui.Button(
                label=str(option),
                style=discord.ButtonStyle.primary,
                custom_id=f"answer_{option}"
            )
            button.callback = self.answer_callback
            self.add_item(button)
    
    async def answer_callback(self, interaction: discord.Interaction):
        if interaction.user.id != int(self.user_id):
            await interaction.response.send_message(
                "❌ This isn't your quiz!", ephemeral=True
            )
            return
        
        if self.answered:
            await interaction.response.send_message(
                "❌ You already answered this quiz!", ephemeral=True
            )
            return
        
        self.answered = True
        selected_answer = int(interaction.data['custom_id'].split('_')[1])
        correct = selected_answer == self.correct_answer
        
        # Update stats and coins
        coins_won = 0
        if correct:
            coins_won = 20
            update_coins(self.user_id, coins_won)
        
        update_game_stats(
            self.user_id, 
            "mathquiz", 
            played=1, 
            won=1 if correct else 0, 
            score=coins_won
        )
        
        # Disable all buttons
        for item in self.children:
            item.disabled = True
        
        # Update embed
        embed = discord.Embed(
            title="🧮 Math Quiz Results",
            color=0x00ff00 if correct else 0xff6b6b
        )
        
        if correct:
            embed.add_field(
                name="🎉 Correct!",
                value=f"Great job! You earned **{coins_won} coins**!",
                inline=False
            )
        else:
            embed.add_field(
                name="❌ Incorrect!",
                value=f"The correct answer was **{self.correct_answer}**. Better luck next time!",
                inline=False
            )
        
        embed.add_field(
            name="Your Answer",
            value=f"**{selected_answer}**",
            inline=True
        )
        
        embed.add_field(
            name="Correct Answer", 
            value=f"**{self.correct_answer}**",
            inline=True
        )
        
        embed.set_footer(text=f"Quiz completed by {interaction.user.display_name}")
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def on_timeout(self):
        # Disable all buttons on timeout
        for item in self.children:
            item.disabled = True

async def execute(interaction: discord.Interaction):
    """Execute math quiz game"""
    try:
        user_id = str(interaction.user.id)
        
        # Generate random math problem
        operation = random.choice(['+', '-', '*'])
        
        if operation == '+':
            a = random.randint(1, 50)
            b = random.randint(1, 50)
            answer = a + b
            problem = f"{a} + {b}"
        elif operation == '-':
            a = random.randint(10, 100)
            b = random.randint(1, a)  # Ensure positive result
            answer = a - b
            problem = f"{a} - {b}"
        else:  # multiplication
            a = random.randint(1, 12)
            b = random.randint(1, 12)
            answer = a * b
            problem = f"{a} × {b}"
        
        # Create embed
        embed = discord.Embed(
            title="🧮 Math Quiz Challenge",
            description=f"**What is {problem}?**",
            color=0x3498db
        )
        
        embed.add_field(
            name="⏰ Time Limit",
            value="30 seconds to answer!",
            inline=False
        )
        
        embed.add_field(
            name="💰 Reward",
            value="20 coins for correct answer!",
            inline=False
        )
        
        embed.set_footer(text=f"Quiz for {interaction.user.display_name}")
        
        # Create view with answer buttons
        view = MathQuizView(answer, user_id)
        
        await interaction.response.send_message(embed=embed, view=view)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while generating the math quiz. Please try again!", 
            ephemeral=True
        )
        print(f"Math quiz error: {e}")
