import discord
import random
from utils.economy import update_coins, update_game_stats

async def execute(interaction: discord.Interaction):
    """Execute dice roll game"""
    try:
        user_id = str(interaction.user.id)
        
        # Roll the dice
        result = random.randint(1, 6)
        
        # Dice emoji mapping
        dice_emojis = {
            1: "⚀",
            2: "⚁", 
            3: "⚂",
            4: "⚃",
            5: "⚄",
            6: "⚅"
        }
        
        # Calculate reward based on result
        coins_won = 0
        if result == 6:
            coins_won = 50  # Jackpot!
        elif result >= 4:
            coins_won = 10  # Good roll
        
        # Update user stats
        if coins_won > 0:
            update_coins(user_id, coins_won)
        
        update_game_stats(user_id, "dice", played=1, won=1 if coins_won > 0 else 0, score=result)
        
        # Create embed
        embed = discord.Embed(
            title="🎲 Dice Roll",
            color=0x3498db
        )
        
        embed.add_field(
            name="Your Roll",
            value=f"{dice_emojis[result]} **{result}**",
            inline=False
        )
        
        if result == 6:
            embed.add_field(
                name="🎉 JACKPOT!",
                value=f"Perfect roll! You earned **{coins_won} coins**!",
                inline=False
            )
            embed.color = 0xffd700
        elif result >= 4:
            embed.add_field(
                name="✨ Nice Roll!",
                value=f"Good roll! You earned **{coins_won} coins**!",
                inline=False
            )
            embed.color = 0x00ff00
        else:
            embed.add_field(
                name="😐 Better Luck Next Time",
                value="No coins this time, but keep rolling!",
                inline=False
            )
            embed.color = 0xff6b6b
        
        embed.set_footer(text=f"Game played by {interaction.user.display_name}")
        
        await interaction.response.send_message(embed=embed)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while rolling the dice. Please try again!", 
            ephemeral=True
        )
        print(f"Dice error: {e}")
