import discord
import random
import asyncio
import time
from utils.economy import update_coins, update_game_stats

class ReactionGameView(discord.ui.View):
    def __init__(self, start_time: float, user_id: str):
        super().__init__(timeout=10.0)
        self.start_time = start_time
        self.user_id = user_id
        self.clicked = False
    
    @discord.ui.button(label="CLICK NOW!", style=discord.ButtonStyle.success, emoji="⚡")
    async def reaction_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != int(self.user_id):
            await interaction.response.send_message(
                "❌ This isn't your reaction test!", ephemeral=True
            )
            return
        
        if self.clicked:
            await interaction.response.send_message(
                "❌ You already clicked!", ephemeral=True
            )
            return
        
        self.clicked = True
        end_time = time.perf_counter()
        reaction_time_ms = round((end_time - self.start_time) * 1000)
        
        # Disable the button
        button.disabled = True
        
        # Calculate score and coins based on reaction time
        coins_won = 0
        rank = ""
        color = 0x808080
        
        if reaction_time_ms < 200:
            coins_won = 50
            rank = "⚡ LIGHTNING FAST!"
            color = 0xffd700
        elif reaction_time_ms < 300:
            coins_won = 35
            rank = "🔥 SUPER FAST!"
            color = 0xff6b6b
        elif reaction_time_ms < 400:
            coins_won = 25
            rank = "✨ FAST!"
            color = 0x00ff00
        elif reaction_time_ms < 500:
            coins_won = 15
            rank = "👍 GOOD!"
            color = 0x3498db
        elif reaction_time_ms < 700:
            coins_won = 10
            rank = "🙂 OKAY"
            color = 0xf39c12
        else:
            coins_won = 5
            rank = "🐌 SLOW..."
            color = 0x95a5a6
        
        # Update user stats
        update_coins(self.user_id, coins_won)
        update_game_stats(
            self.user_id, 
            "reaction", 
            played=1, 
            won=1, 
            score=1000 - reaction_time_ms  # Higher score for faster reaction
        )
        
        # Create result embed
        embed = discord.Embed(
            title="⚡ Reaction Test Results",
            color=color
        )
        
        embed.add_field(
            name="⏱️ Your Time",
            value=f"**{reaction_time_ms}ms**",
            inline=True
        )
        
        embed.add_field(
            name="🏆 Rating",
            value=rank,
            inline=True
        )
        
        embed.add_field(
            name="💰 Coins Earned",
            value=f"**{coins_won} coins**",
            inline=True
        )
        
        # Add reaction time categories for reference
        embed.add_field(
            name="📊 Reaction Time Scale",
            value="""```
⚡ <200ms = Lightning (50 coins)
🔥 <300ms = Super Fast (35 coins)
✨ <400ms = Fast (25 coins)
👍 <500ms = Good (15 coins)
🙂 <700ms = Okay (10 coins)
🐌 700ms+ = Slow (5 coins)```""",
            inline=False
        )
        
        # Fun facts about reaction times
        if reaction_time_ms < 250:
            embed.add_field(
                name="🎉 Amazing!",
                value="You have the reflexes of a professional gamer!",
                inline=False
            )
        elif reaction_time_ms < 350:
            embed.add_field(
                name="👏 Excellent!",
                value="Your reaction time is above average!",
                inline=False
            )
        elif reaction_time_ms > 600:
            embed.add_field(
                name="💡 Tip",
                value="Try to stay focused and ready. Practice makes perfect!",
                inline=False
            )
        
        embed.set_footer(text=f"Reaction test by {interaction.user.display_name}")
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def on_timeout(self):
        # User didn't click in time
        if not self.clicked:
            update_game_stats(self.user_id, "reaction", played=1, won=0, score=0)
        
        for item in self.children:
            item.disabled = True

async def execute(interaction: discord.Interaction):
    """Execute reaction test game"""
    try:
        user_id = str(interaction.user.id)
        
        # Initial countdown embed
        embed = discord.Embed(
            title="⚡ Reaction Speed Test",
            description="Get ready to test your reflexes!",
            color=0xf39c12
        )
        
        embed.add_field(
            name="🎯 Instructions",
            value="Wait for the green signal, then click as fast as you can!",
            inline=False
        )
        
        embed.add_field(
            name="⏰ Preparation",
            value="The button will appear in 2-5 seconds...",
            inline=False
        )
        
        embed.add_field(
            name="🏆 Challenge",
            value="Can you react in under 300ms?",
            inline=False
        )
        
        embed.set_footer(text=f"Get ready, {interaction.user.display_name}!")
        
        await interaction.response.send_message(embed=embed)
        
        # Random delay between 2-5 seconds
        delay = random.uniform(2.0, 5.0)
        await asyncio.sleep(delay)
        
        # Record start time
        start_time = time.perf_counter()
        
        # Create the reaction button
        ready_embed = discord.Embed(
            title="🟢 GO! CLICK NOW!",
            description="Click the button as fast as you can!",
            color=0x00ff00
        )
        
        ready_embed.add_field(
            name="⚡ REACT NOW!",
            value="Your reaction time is being measured!",
            inline=False
        )
        
        ready_embed.set_footer(text=f"Reaction test for {interaction.user.display_name}")
        
        view = ReactionGameView(start_time, user_id)
        
        await interaction.edit_original_response(embed=ready_embed, view=view)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while starting the reaction test. Please try again!", 
            ephemeral=True
        )
        print(f"Reaction test error: {e}")
