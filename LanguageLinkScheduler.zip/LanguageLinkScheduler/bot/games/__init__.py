"""
Discord Bot Games Package
Contains all mini-game implementations
"""

# Import all game modules for easy access
from . import (
    coinflip,
    dice, 
    rps,
    guessnumber,
    eightball,
    mathquiz,
    slot,
    wordsalad,
    memory,
    reaction,
    trivia,
    hangman,
    riddle,
    emojiguess,
    tictactoe,
    blackjack,
    roulette,
    lottery,
    treasure,
    duel
)

__all__ = [
    'coinflip',
    'dice',
    'rps', 
    'guessnumber',
    'eightball',
    'mathquiz',
    'slot',
    'wordsalad',
    'memory',
    'reaction',
    'trivia',
    'hangman',
    'riddle',
    'emojiguess',
    'tictactoe',
    'blackjack',
    'roulette',
    'lottery',
    'treasure',
    'duel'
]
