import discord
import random
from utils.economy import update_coins, update_game_stats

class TreasureHuntView(discord.ui.View):
    def __init__(self, user_id: str):
        super().__init__(timeout=90.0)
        self.user_id = user_id
        self.explored_locations = set()
        self.treasure_found = False
        self.turns_taken = 0
        self.max_turns = 5
        
        # Set up treasure locations (one has treasure, others have various rewards/penalties)
        self.locations = {
            "🏔️": {"name": "Mountain Cave", "treasure": False, "reward": 15, "description": "A dark cave echoing with mysterious sounds"},
            "🏝️": {"name": "Desert Island", "treasure": False, "reward": 10, "description": "A small island with palm trees"},
            "🏛️": {"name": "Ancient Temple", "treasure": True, "reward": 100, "description": "An ancient temple filled with golden artifacts"},
            "🌊": {"name": "Underwater Grotto", "treasure": False, "reward": 20, "description": "A hidden grotto beneath the waves"},
            "🌲": {"name": "Enchanted Forest", "treasure": False, "reward": 8, "description": "A mystical forest with glowing mushrooms"},
            "🏰": {"name": "Abandoned Castle", "treasure": False, "reward": 25, "description": "A spooky castle on a hilltop"},
            "🗻": {"name": "Volcano Crater", "treasure": False, "reward": -5, "description": "A dangerous volcanic crater"},
            "❄️": {"name": "Ice Cave", "treasure": False, "reward": 12, "description": "A frozen cave with ice crystals"}
        }
        
        # Randomize which location has the treasure
        treasure_locations = [loc for loc, data in self.locations.items() if not data["treasure"]]
        random_treasure = random.choice(treasure_locations)
        
        # Reset all treasure flags and set new treasure location
        for loc_data in self.locations.values():
            loc_data["treasure"] = False
        self.locations[random_treasure]["treasure"] = True
        self.locations[random_treasure]["reward"] = 100
        
        # Create buttons for each location
        for emoji, data in self.locations.items():
            button = discord.ui.Button(
                emoji=emoji,
                label=data["name"],
                style=discord.ButtonStyle.primary,
                custom_id=f"explore_{emoji}"
            )
            button.callback = self.explore_callback
            self.add_item(button)
    
    async def explore_callback(self, interaction: discord.Interaction):
        if interaction.user.id != int(self.user_id):
            await interaction.response.send_message(
                "❌ This isn't your treasure hunt!", ephemeral=True
            )
            return
        
        if self.treasure_found:
            return
        
        # Get selected location
        location_emoji = interaction.data['custom_id'].split('_')[1]
        
        if location_emoji in self.explored_locations:
            await interaction.response.send_message(
                "❌ You already explored this location!", ephemeral=True
            )
            return
        
        self.explored_locations.add(location_emoji)
        self.turns_taken += 1
        location_data = self.locations[location_emoji]
        
        # Disable the explored button
        for item in self.children:
            if hasattr(item, 'custom_id') and item.custom_id == f"explore_{location_emoji}":
                item.disabled = True
                item.style = discord.ButtonStyle.secondary
                break
        
        # Check if treasure found
        if location_data["treasure"]:
            self.treasure_found = True
            await self.end_game(interaction, "treasure_found", location_data)
            return
        
        # Check if max turns reached
        if self.turns_taken >= self.max_turns:
            await self.end_game(interaction, "turns_exhausted", location_data)
            return
        
        # Continue exploring
        await self.update_exploration(interaction, location_data)
    
    async def update_exploration(self, interaction: discord.Interaction, location_data):
        """Update the exploration display"""
        reward = location_data["reward"]
        
        # Update coins for small rewards/penalties
        if reward != 0:
            update_coins(self.user_id, reward)
        
        embed = discord.Embed(
            title="🗺️ Treasure Hunt - Exploring",
            description=f"You explored the **{location_data['name']}**!",
            color=0x3498db
        )
        
        embed.add_field(
            name="🔍 Discovery",
            value=location_data["description"],
            inline=False
        )
        
        if reward > 0:
            embed.add_field(
                name="💰 Small Reward",
                value=f"You found **{reward} coins**!",
                inline=True
            )
            embed.color = 0x2ecc71
        elif reward < 0:
            embed.add_field(
                name="⚠️ Danger",
                value=f"You lost **{abs(reward)} coins** to dangers!",
                inline=True
            )
            embed.color = 0xe74c3c
        else:
            embed.add_field(
                name="🚫 Empty",
                value="Nothing of value here...",
                inline=True
            )
        
        embed.add_field(
            name="📊 Progress",
            value=f"Locations explored: {len(self.explored_locations)}/{len(self.locations)}\nTurns remaining: {self.max_turns - self.turns_taken}",
            inline=True
        )
        
        embed.add_field(
            name="🎯 Goal",
            value="Find the treasure before you run out of turns!",
            inline=False
        )
        
        embed.set_footer(text=f"Treasure hunt for {interaction.user.display_name}")
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def end_game(self, interaction: discord.Interaction, result: str, location_data):
        """End the treasure hunt game"""
        self.treasure_found = True
        
        # Disable all buttons
        for item in self.children:
            item.disabled = True
        
        total_coins = 0
        
        if result == "treasure_found":
            total_coins = location_data["reward"]
            update_coins(self.user_id, total_coins)
            update_game_stats(self.user_id, "treasure", played=1, won=1, score=total_coins)
            
            embed = discord.Embed(
                title="🎉 Treasure Hunt - TREASURE FOUND!",
                description=f"🏆 **CONGRATULATIONS!** You found the legendary treasure!",
                color=0xffd700
            )
            
            embed.add_field(
                name="💎 Treasure Location",
                value=f"**{location_data['name']}**\n{location_data['description']}",
                inline=False
            )
            
            embed.add_field(
                name="💰 Treasure Value",
                value=f"**{total_coins} coins**",
                inline=True
            )
            
            embed.add_field(
                name="🎯 Efficiency",
                value=f"Found in {self.turns_taken} turns!",
                inline=True
            )
            
            embed.add_field(
                name="🏅 Achievement",
                value="Master Treasure Hunter!",
                inline=True
            )
            
        else:  # turns_exhausted
            update_game_stats(self.user_id, "treasure", played=1, won=0, score=0)
            
            # Find the treasure location for reveal
            treasure_location = None
            for emoji, data in self.locations.items():
                if data["treasure"]:
                    treasure_location = data
                    break
            
            embed = discord.Embed(
                title="🗺️ Treasure Hunt - Quest Failed",
                description="You ran out of turns before finding the treasure!",
                color=0xe74c3c
            )
            
            embed.add_field(
                name="📍 Treasure Location Revealed",
                value=f"The treasure was hidden in the **{treasure_location['name']}**!",
                inline=False
            )
            
            embed.add_field(
                name="🔍 Last Exploration",
                value=f"**{location_data['name']}**\n{location_data['description']}",
                inline=False
            )
            
            embed.add_field(
                name="📊 Final Stats",
                value=f"Locations explored: {len(self.explored_locations)}/{len(self.locations)}\nTurns used: {self.turns_taken}/{self.max_turns}",
                inline=False
            )
        
        embed.add_field(
            name="🗺️ Exploration Summary",
            value=" ".join([f"✅{emoji}" if emoji in self.explored_locations else f"❓{emoji}" for emoji in self.locations.keys()]),
            inline=False
        )
        
        embed.set_footer(text=f"Treasure hunt completed by {interaction.user.display_name}")
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def on_timeout(self):
        if not self.treasure_found:
            update_game_stats(self.user_id, "treasure", played=1, won=0, score=0)
        
        for item in self.children:
            item.disabled = True

async def execute(interaction: discord.Interaction):
    """Execute treasure hunt game"""
    try:
        user_id = str(interaction.user.id)
        
        # Create initial embed
        embed = discord.Embed(
            title="🗺️ Treasure Hunt Adventure",
            description="Embark on an epic quest to find the legendary treasure!",
            color=0xf39c12
        )
        
        embed.add_field(
            name="🎯 Objective",
            value="Search different locations to find the hidden treasure before running out of turns!",
            inline=False
        )
        
        embed.add_field(
            name="⏱️ Turn Limit",
            value="**5 turns** to find the treasure",
            inline=True
        )
        
        embed.add_field(
            name="💰 Rewards",
            value="**100 coins** for finding treasure\n**Small rewards** from exploration",
            inline=True
        )
        
        embed.add_field(
            name="⚠️ Risks",
            value="Some locations may have dangers!",
            inline=True
        )
        
        embed.add_field(
            name="🗺️ Available Locations",
            value="Click on any location below to explore it. Choose wisely!",
            inline=False
        )
        
        embed.add_field(
            name="💡 Strategy Tip",
            value="Each location can only be explored once. Think about where treasure might be hidden!",
            inline=False
        )
        
        embed.set_footer(text=f"Treasure hunt for {interaction.user.display_name} • Good luck, adventurer!")
        
        # Create view
        view = TreasureHuntView(user_id)
        
        await interaction.response.send_message(embed=embed, view=view)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while starting the treasure hunt. Please try again!", 
            ephemeral=True
        )
        print(f"Treasure hunt error: {e}")
