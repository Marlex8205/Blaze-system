import discord
import random
from utils.economy import update_coins, update_game_stats

async def execute(interaction: discord.Interaction, bet: int, choice: str):
    """Execute roulette game"""
    try:
        user_id = str(interaction.user.id)
        
        # Validate bet amount
        if bet < 5:
            await interaction.response.send_message(
                "❌ Minimum bet is 5 coins!", ephemeral=True
            )
            return
        
        if bet > 100:
            await interaction.response.send_message(
                "❌ Maximum bet is 100 coins!", ephemeral=True
            )
            return
        
        # Validate choice
        choice = choice.lower().strip()
        valid_numbers = [str(i) for i in range(37)]  # 0-36
        valid_colors = ["red", "black"]
        valid_choices = valid_numbers + valid_colors + ["even", "odd", "low", "high"]
        
        if choice not in valid_choices:
            await interaction.response.send_message(
                "❌ Invalid choice! Use: red, black, even, odd, low (1-18), high (19-36), or a number (0-36)",
                ephemeral=True
            )
            return
        
        # Roulette wheel setup
        red_numbers = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]
        black_numbers = [2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35]
        
        # Spin the wheel
        winning_number = random.randint(0, 36)
        
        # Determine color
        if winning_number == 0:
            winning_color = "green"
        elif winning_number in red_numbers:
            winning_color = "red"
        else:
            winning_color = "black"
        
        # Calculate winnings
        coins_won = 0
        win_type = ""
        multiplier = 0
        
        # Check different bet types
        if choice == str(winning_number):
            # Straight up bet (single number)
            coins_won = bet * 35
            win_type = "Straight Up (35:1)"
            multiplier = 35
        elif choice == winning_color and winning_number != 0:
            # Color bet
            coins_won = bet * 2
            win_type = "Color (1:1)"
            multiplier = 1
        elif choice == "even" and winning_number != 0 and winning_number % 2 == 0:
            # Even bet
            coins_won = bet * 2
            win_type = "Even (1:1)"
            multiplier = 1
        elif choice == "odd" and winning_number % 2 == 1:
            # Odd bet
            coins_won = bet * 2
            win_type = "Odd (1:1)"
            multiplier = 1
        elif choice == "low" and 1 <= winning_number <= 18:
            # Low bet (1-18)
            coins_won = bet * 2
            win_type = "Low 1-18 (1:1)"
            multiplier = 1
        elif choice == "high" and 19 <= winning_number <= 36:
            # High bet (19-36)
            coins_won = bet * 2
            win_type = "High 19-36 (1:1)"
            multiplier = 1
        
        # Net coins (subtract original bet if lost)
        net_coins = coins_won - bet if coins_won > 0 else -bet
        
        # Update user stats
        if net_coins > 0:
            update_coins(user_id, net_coins)
            update_game_stats(user_id, "roulette", played=1, won=1, score=net_coins)
        else:
            update_game_stats(user_id, "roulette", played=1, won=0, score=0)
        
        # Create embed
        embed = discord.Embed(
            title="🎡 Roulette Results",
            color=0x2ecc71 if net_coins > 0 else 0xe74c3c if net_coins < 0 else 0xf39c12
        )
        
        # Roulette wheel display
        wheel_emojis = {
            "red": "🔴",
            "black": "⚫",
            "green": "🟢"
        }
        
        embed.add_field(
            name="🎯 Winning Number",
            value=f"{wheel_emojis[winning_color]} **{winning_number}** ({winning_color.title()})",
            inline=False
        )
        
        embed.add_field(
            name="🎲 Your Bet",
            value=f"**{choice.title()}** ({bet} coins)",
            inline=True
        )
        
        if net_coins > 0:
            embed.add_field(
                name="🎉 You Win!",
                value=f"**{win_type}**\nPayout: {coins_won} coins\nProfit: +{net_coins} coins",
                inline=True
            )
        elif net_coins < 0:
            embed.add_field(
                name="😔 You Lose!",
                value=f"Better luck next time!\nLoss: {bet} coins",
                inline=True
            )
        else:
            embed.add_field(
                name="🤝 Push",
                value="Your bet is returned!",
                inline=True
            )
        
        # Add roulette table reference
        embed.add_field(
            name="🎰 Roulette Payouts",
            value="""```
Single Number: 35:1
Red/Black: 1:1
Even/Odd: 1:1
Low (1-18): 1:1
High (19-36): 1:1
Green 0: House wins```""",
            inline=False
        )
        
        # Visual representation of the wheel spin
        spin_animation = "🎡 " + " ".join([
            "🔴" if i in red_numbers else "⚫" if i in black_numbers else "🟢"
            for i in range(max(0, winning_number - 2), min(37, winning_number + 3))
        ])
        
        embed.add_field(
            name="🎡 Wheel Section",
            value=spin_animation,
            inline=False
        )
        
        # Add some fun facts
        if winning_number == 0:
            embed.add_field(
                name="🍀 Fun Fact",
                value="Green 0 gives the house its edge in roulette!",
                inline=False
            )
        elif multiplier == 35:
            embed.add_field(
                name="🎰 Amazing!",
                value="You hit a straight number! The odds were 1 in 37!",
                inline=False
            )
        
        embed.set_footer(text=f"Roulette spin by {interaction.user.display_name}")
        
        await interaction.response.send_message(embed=embed)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while spinning the roulette wheel. Please try again!", 
            ephemeral=True
        )
        print(f"Roulette error: {e}")
