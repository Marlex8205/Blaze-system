import discord
import random
import asyncio
from utils.economy import update_coins, update_game_stats

class DuelView(discord.ui.View):
    def __init__(self, challenger_id: str, opponent_id: str, challenger_name: str, opponent_name: str):
        super().__init__(timeout=60.0)
        self.challenger_id = challenger_id
        self.opponent_id = opponent_id
        self.challenger_name = challenger_name
        self.opponent_name = opponent_name
        self.challenger_accepted = True  # Challenger automatically accepts
        self.opponent_accepted = False
        self.duel_started = False
        
        # Duel stats
        self.challenger_hp = 100
        self.opponent_hp = 100
        self.current_turn = challenger_id  # Challenger goes first
        self.turn_count = 0
        self.max_turns = 10  # Maximum turns before draw
        
        # Move history
        self.move_history = []
    
    @discord.ui.button(label="Accept Duel", style=discord.ButtonStyle.success, emoji="⚔️")
    async def accept_duel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.opponent_id:
            await interaction.response.send_message(
                "❌ Only the challenged player can accept this duel!", ephemeral=True
            )
            return
        
        if self.duel_started:
            return
        
        self.opponent_accepted = True
        self.duel_started = True
        
        # Remove accept/decline buttons and add combat buttons
        self.clear_items()
        self.add_combat_buttons()
        
        await self.start_duel(interaction)
    
    @discord.ui.button(label="Decline Duel", style=discord.ButtonStyle.danger, emoji="🏳️")
    async def decline_duel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.opponent_id:
            await interaction.response.send_message(
                "❌ Only the challenged player can decline this duel!", ephemeral=True
            )
            return
        
        embed = discord.Embed(
            title="⚔️ Duel Declined",
            description=f"{self.opponent_name} has declined the duel challenge.",
            color=0x95a5a6
        )
        
        embed.add_field(
            name="🏳️ Result",
            value="The duel has been cancelled. No honor lost!",
            inline=False
        )
        
        self.clear_items()
        await interaction.response.edit_message(embed=embed, view=self)
    
    def add_combat_buttons(self):
        """Add combat action buttons"""
        # Attack button
        attack_button = discord.ui.Button(
            label="Attack",
            style=discord.ButtonStyle.danger,
            emoji="⚔️",
            custom_id="attack"
        )
        attack_button.callback = self.combat_action
        self.add_item(attack_button)
        
        # Defend button
        defend_button = discord.ui.Button(
            label="Defend",
            style=discord.ButtonStyle.primary,
            emoji="🛡️",
            custom_id="defend"
        )
        defend_button.callback = self.combat_action
        self.add_item(defend_button)
        
        # Special Attack button
        special_button = discord.ui.Button(
            label="Special Attack",
            style=discord.ButtonStyle.secondary,
            emoji="💥",
            custom_id="special"
        )
        special_button.callback = self.combat_action
        self.add_item(special_button)
    
    async def combat_action(self, interaction: discord.Interaction):
        if not self.duel_started:
            return
        
        user_id = str(interaction.user.id)
        
        # Check if it's the player's turn
        if user_id != self.current_turn:
            await interaction.response.send_message(
                "❌ It's not your turn!", ephemeral=True
            )
            return
        
        # Get action type
        action = interaction.data['custom_id']
        
        # Process the action
        await self.process_combat_turn(interaction, action)
    
    async def process_combat_turn(self, interaction: discord.Interaction, action: str):
        """Process a combat turn"""
        self.turn_count += 1
        
        # Determine attacker and defender
        if self.current_turn == self.challenger_id:
            attacker_name = self.challenger_name
            defender_name = self.opponent_name
            attacker_hp = self.challenger_hp
            defender_hp = self.opponent_hp
        else:
            attacker_name = self.opponent_name
            defender_name = self.challenger_name
            attacker_hp = self.opponent_hp
            defender_hp = self.challenger_hp
        
        # Calculate damage and effects
        damage = 0
        effect_text = ""
        
        if action == "attack":
            damage = random.randint(15, 25)
            effect_text = f"🗡️ {attacker_name} attacks {defender_name} for **{damage} damage**!"
        
        elif action == "defend":
            # Defending reduces incoming damage and heals slightly
            heal = random.randint(5, 10)
            if self.current_turn == self.challenger_id:
                self.challenger_hp = min(100, self.challenger_hp + heal)
            else:
                self.opponent_hp = min(100, self.opponent_hp + heal)
            effect_text = f"🛡️ {attacker_name} defends and recovers **{heal} HP**!"
        
        elif action == "special":
            # Special attack: High damage but random
            if random.random() < 0.7:  # 70% success rate
                damage = random.randint(25, 35)
                effect_text = f"💥 {attacker_name}'s special attack hits for **{damage} damage**!"
            else:
                effect_text = f"💨 {attacker_name}'s special attack missed!"
        
        # Apply damage
        if damage > 0:
            if self.current_turn == self.challenger_id:
                self.opponent_hp = max(0, self.opponent_hp - damage)
            else:
                self.challenger_hp = max(0, self.challenger_hp - damage)
        
        # Add to move history
        self.move_history.append(effect_text)
        
        # Check for winner
        if self.challenger_hp <= 0 or self.opponent_hp <= 0 or self.turn_count >= self.max_turns:
            await self.end_duel(interaction)
            return
        
        # Switch turns
        self.current_turn = self.opponent_id if self.current_turn == self.challenger_id else self.challenger_id
        
        # Update display
        await self.update_duel_display(interaction, effect_text)
    
    async def start_duel(self, interaction: discord.Interaction):
        """Start the duel"""
        embed = discord.Embed(
            title="⚔️ Duel Commenced!",
            description=f"**{self.challenger_name}** vs **{self.opponent_name}**\n\nLet the battle begin!",
            color=0xe74c3c
        )
        
        embed.add_field(
            name="🏥 Health Status",
            value=f"**{self.challenger_name}:** {self.challenger_hp}/100 HP\n**{self.opponent_name}:** {self.opponent_hp}/100 HP",
            inline=False
        )
        
        embed.add_field(
            name="⚡ Current Turn",
            value=f"**{self.challenger_name}** goes first!",
            inline=True
        )
        
        embed.add_field(
            name="🎯 Actions",
            value="⚔️ **Attack:** Deal 15-25 damage\n🛡️ **Defend:** Heal 5-10 HP\n💥 **Special:** Deal 25-35 damage (70% chance)",
            inline=False
        )
        
        embed.set_footer(text=f"Turn {self.turn_count}/{self.max_turns}")
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def update_duel_display(self, interaction: discord.Interaction, last_action: str):
        """Update the duel display"""
        current_player = self.challenger_name if self.current_turn == self.challenger_id else self.opponent_name
        
        embed = discord.Embed(
            title="⚔️ Duel in Progress",
            description=f"**{self.challenger_name}** vs **{self.opponent_name}**",
            color=0xf39c12
        )
        
        embed.add_field(
            name="💥 Last Action",
            value=last_action,
            inline=False
        )
        
        # Health bars
        challenger_bar = self.create_health_bar(self.challenger_hp)
        opponent_bar = self.create_health_bar(self.opponent_hp)
        
        embed.add_field(
            name="🏥 Health Status",
            value=f"**{self.challenger_name}:** {challenger_bar} {self.challenger_hp}/100\n**{self.opponent_name}:** {opponent_bar} {self.opponent_hp}/100",
            inline=False
        )
        
        embed.add_field(
            name="⚡ Current Turn",
            value=f"**{current_player}**'s turn to act!",
            inline=True
        )
        
        embed.add_field(
            name="📊 Turn",
            value=f"{self.turn_count}/{self.max_turns}",
            inline=True
        )
        
        # Show recent move history
        if len(self.move_history) > 3:
            recent_moves = self.move_history[-3:]
        else:
            recent_moves = self.move_history
        
        if recent_moves:
            embed.add_field(
                name="📜 Recent Actions",
                value="\n".join(recent_moves),
                inline=False
            )
        
        embed.set_footer(text=f"Duel between {self.challenger_name} and {self.opponent_name}")
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    def create_health_bar(self, hp: int) -> str:
        """Create a visual health bar"""
        bar_length = 10
        filled = int((hp / 100) * bar_length)
        empty = bar_length - filled
        
        if hp > 60:
            return "🟢" * filled + "⬜" * empty
        elif hp > 30:
            return "🟡" * filled + "⬜" * empty
        else:
            return "🔴" * filled + "⬜" * empty
    
    async def end_duel(self, interaction: discord.Interaction):
        """End the duel and determine winner"""
        self.clear_items()
        
        # Determine winner
        if self.challenger_hp <= 0:
            winner = self.opponent_name
            winner_id = self.opponent_id
            loser = self.challenger_name
            loser_id = self.challenger_id
            result = "opponent_wins"
        elif self.opponent_hp <= 0:
            winner = self.challenger_name
            winner_id = self.challenger_id
            loser = self.opponent_name
            loser_id = self.opponent_id
            result = "challenger_wins"
        else:
            # Draw (max turns reached)
            result = "draw"
        
        # Calculate rewards
        if result == "draw":
            # Both players get participation reward
            update_coins(self.challenger_id, 10)
            update_coins(self.opponent_id, 10)
            update_game_stats(self.challenger_id, "duel", played=1, won=0, score=10)
            update_game_stats(self.opponent_id, "duel", played=1, won=0, score=10)
            
            embed = discord.Embed(
                title="⚔️ Duel Result: Draw!",
                description="Both warriors fought valiantly to a standstill!",
                color=0xf39c12
            )
            
            embed.add_field(
                name="🤝 Honorable Draw",
                value="Both players receive **10 coins** for their effort!",
                inline=False
            )
        else:
            # Winner gets more coins
            update_coins(winner_id, 30)
            update_coins(loser_id, 5)  # Participation reward
            update_game_stats(winner_id, "duel", played=1, won=1, score=30)
            update_game_stats(loser_id, "duel", played=1, won=0, score=5)
            
            embed = discord.Embed(
                title="⚔️ Duel Result: Victory!",
                description=f"**{winner}** emerges victorious!",
                color=0x2ecc71
            )
            
            embed.add_field(
                name="🏆 Winner",
                value=f"**{winner}** receives **30 coins**!",
                inline=True
            )
            
            embed.add_field(
                name="🥈 Participant",
                value=f"**{loser}** receives **5 coins** for fighting!",
                inline=True
            )
        
        # Final health status
        embed.add_field(
            name="🏥 Final Health",
            value=f"**{self.challenger_name}:** {self.challenger_hp}/100 HP\n**{self.opponent_name}:** {self.opponent_hp}/100 HP",
            inline=False
        )
        
        embed.add_field(
            name="📊 Duel Statistics",
            value=f"Total turns: {self.turn_count}\nActions taken: {len(self.move_history)}",
            inline=True
        )
        
        embed.add_field(
            name="🎖️ Honor",
            value="Both warriors showed great courage!",
            inline=True
        )
        
        embed.set_footer(text=f"Duel completed • GG!")
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def on_timeout(self):
        # If duel never started, just clean up
        if not self.duel_started:
            return
        
        # If duel was in progress, give participation rewards
        update_game_stats(self.challenger_id, "duel", played=1, won=0, score=0)
        update_game_stats(self.opponent_id, "duel", played=1, won=0, score=0)
        
        for item in self.children:
            item.disabled = True

async def execute(interaction: discord.Interaction, opponent: discord.User):
    """Execute duel game"""
    try:
        challenger_id = str(interaction.user.id)
        opponent_id = str(opponent.id)
        
        # Check if user is trying to duel themselves
        if challenger_id == opponent_id:
            await interaction.response.send_message(
                "❌ You cannot duel yourself! Challenge another player.",
                ephemeral=True
            )
            return
        
        # Check if opponent is a bot
        if opponent.bot:
            await interaction.response.send_message(
                "❌ You cannot duel bots! Challenge a real player.",
                ephemeral=True
            )
            return
        
        # Create initial embed
        embed = discord.Embed(
            title="⚔️ Duel Challenge!",
            description=f"**{interaction.user.display_name}** has challenged **{opponent.display_name}** to a duel!",
            color=0xe74c3c
        )
        
        embed.add_field(
            name="🎯 Challenge Details",
            value="A battle of skill and strategy awaits!",
            inline=False
        )
        
        embed.add_field(
            name="⚔️ Combat System",
            value="Turn-based combat with Attack, Defend, and Special moves",
            inline=True
        )
        
        embed.add_field(
            name="🏆 Rewards",
            value="**Winner:** 30 coins\n**Participant:** 5 coins\n**Draw:** 10 coins each",
            inline=True
        )
        
        embed.add_field(
            name="⏰ Time Limit",
            value="60 seconds to accept",
            inline=True
        )
        
        embed.add_field(
            name="🎮 Rules",
            value="• Turn-based combat\n• 100 HP each\n• 10 turn limit\n• Best strategy wins!",
            inline=False
        )
        
        embed.add_field(
            name="📢 Awaiting Response",
            value=f"{opponent.mention}, do you accept this duel challenge?",
            inline=False
        )
        
        embed.set_thumbnail(url=opponent.display_avatar.url)
        embed.set_footer(text=f"Duel challenge from {interaction.user.display_name}")
        
        # Create view
        view = DuelView(challenger_id, opponent_id, interaction.user.display_name, opponent.display_name)
        
        await interaction.response.send_message(embed=embed, view=view)
        
    except Exception as e:
        await interaction.response.send_message(
            "❌ An error occurred while setting up the duel. Please try again!", 
            ephemeral=True
        )
        print(f"Duel error: {e}")
