#!/usr/bin/env python3
"""
Permanent Bot Starter - Keeps the Discord bot running 24/7
"""
import asyncio
import subprocess
import time
import threading
import logging
from keep_alive import start_keep_alive

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def start_discord_bot():
    """Start the Discord bot in a subprocess"""
    try:
        logger.info("🚀 Starting Discord bot...")
        process = subprocess.Popen(
            ["python3", "bot/index.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        # Monitor the process
        while True:
            if process.poll() is not None:
                logger.warning("⚠️ Bot process ended, restarting...")
                process = subprocess.Popen(
                    ["python3", "bot/index.py"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
            time.sleep(10)  # Check every 10 seconds
            
    except Exception as e:
        logger.error(f"❌ Error starting bot: {e}")
        time.sleep(5)
        start_discord_bot()  # Restart on error

def main():
    """Main function to start both keep-alive and bot"""
    logger.info("🔄 Starting 24/7 Bot System...")
    
    # Start keep-alive web server in background
    keep_alive_thread = threading.Thread(target=start_keep_alive, daemon=True)
    keep_alive_thread.start()
    logger.info("✅ Keep-alive server started")
    
    # Start Discord bot (this will run forever with auto-restart)
    start_discord_bot()

if __name__ == "__main__":
    main()