import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Play, Users } from "lucide-react";

interface GameCardProps {
  name: string;
  description: string;
  category: string;
  emoji: string;
  totalPlayed?: number;
  topScore?: number;
  players?: number;
}

export function GameCard({ 
  name, 
  description, 
  category, 
  emoji, 
  totalPlayed = 0, 
  topScore, 
  players = 0 
}: GameCardProps) {
  return (
    <Card className="hover:shadow-lg transition-shadow duration-200 bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <span className="text-3xl">{emoji}</span>
            <div>
              <CardTitle className="text-lg text-gray-900 dark:text-white">{name}</CardTitle>
              <Badge variant="secondary" className="mt-1">
                {category}
              </Badge>
            </div>
          </div>
          {topScore && (
            <div className="flex items-center space-x-1 text-yellow-600 dark:text-yellow-400">
              <Trophy className="h-4 w-4" />
              <span className="text-sm font-medium">{topScore}</span>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <CardDescription className="text-gray-600 dark:text-gray-300 mb-4">
          {description}
        </CardDescription>
        <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
          <div className="flex items-center space-x-1">
            <Play className="h-4 w-4" />
            <span>{totalPlayed} plays</span>
          </div>
          <div className="flex items-center space-x-1">
            <Users className="h-4 w-4" />
            <span>{players} players</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
