import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Coins, Trophy, Star, TrendingUp } from "lucide-react";
import type { DiscordUser } from "@shared/schema";

interface UserStatsProps {
  user: DiscordUser;
  rank?: number;
}

export function UserStats({ user, rank }: UserStatsProps) {
  const winRate = user.gamesPlayed ? Math.round((user.gamesWon / user.gamesPlayed) * 100) : 0;
  const experienceToNext = (user.level || 1) * 1000;
  const currentExperience = user.experience || 0;
  const progressToNext = Math.min((currentExperience % 1000) / 10, 100);

  return (
    <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg text-gray-900 dark:text-white flex items-center space-x-2">
              <span>{user.username}</span>
              {rank && (
                <Badge variant={rank <= 3 ? "default" : "secondary"} className="flex items-center space-x-1">
                  <Trophy className="h-3 w-3" />
                  <span>#{rank}</span>
                </Badge>
              )}
            </CardTitle>
            <CardDescription className="text-gray-600 dark:text-gray-300">
              Level {user.level || 1} • Joined {new Date(user.joinedAt || new Date()).toLocaleDateString()}
            </CardDescription>
          </div>
          <div className="text-right">
            <div className="flex items-center space-x-1 text-yellow-600 dark:text-yellow-400">
              <Coins className="h-4 w-4" />
              <span className="font-medium">{user.coins || 0}</span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-300 mb-2">
            <span>Experience Progress</span>
            <span>{currentExperience % 1000}/1000 XP</span>
          </div>
          <Progress value={progressToNext} className="h-2" />
        </div>
        
        <div className="grid grid-cols-3 gap-4 text-center">
          <div className="space-y-1">
            <div className="flex items-center justify-center text-blue-600 dark:text-blue-400">
              <Star className="h-4 w-4 mr-1" />
              <span className="text-sm font-medium">Games</span>
            </div>
            <p className="text-lg font-bold text-gray-900 dark:text-white">{user.gamesPlayed || 0}</p>
          </div>
          
          <div className="space-y-1">
            <div className="flex items-center justify-center text-green-600 dark:text-green-400">
              <Trophy className="h-4 w-4 mr-1" />
              <span className="text-sm font-medium">Wins</span>
            </div>
            <p className="text-lg font-bold text-gray-900 dark:text-white">{user.gamesWon || 0}</p>
          </div>
          
          <div className="space-y-1">
            <div className="flex items-center justify-center text-purple-600 dark:text-purple-400">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span className="text-sm font-medium">Win Rate</span>
            </div>
            <p className="text-lg font-bold text-gray-900 dark:text-white">{winRate}%</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
