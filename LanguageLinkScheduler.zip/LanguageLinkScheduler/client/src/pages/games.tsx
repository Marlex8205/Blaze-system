import { GameCard } from "@/components/game-card";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Filter } from "lucide-react";
import { useState } from "react";

const games = [
  {
    name: "Coinflip",
    description: "Flip a coin and test your luck! Simple heads or tails game.",
    category: "Luck",
    emoji: "🪙",
    totalPlayed: 1250,
    players: 45
  },
  {
    name: "Dice Roll",
    description: "Roll a 6-sided die and see what number you get.",
    category: "Luck",
    emoji: "🎲",
    totalPlayed: 980,
    players: 38
  },
  {
    name: "Rock Paper Scissors",
    description: "Classic game against the bot. Choose wisely!",
    category: "Strategy",
    emoji: "✂️",
    totalPlayed: 2100,
    topScore: 15,
    players: 67
  },
  {
    name: "Number Guessing",
    description: "Guess a number between 1 and 100. How many tries will it take?",
    category: "Puzzle",
    emoji: "🔢",
    totalPlayed: 1560,
    topScore: 3,
    players: 52
  },
  {
    name: "Magic 8-Ball",
    description: "Ask the magic 8-ball a question and receive mystical answers.",
    category: "Fun",
    emoji: "🎱",
    totalPlayed: 890,
    players: 41
  },
  {
    name: "Math Quiz",
    description: "Solve math problems and test your arithmetic skills.",
    category: "Education",
    emoji: "🧮",
    totalPlayed: 670,
    topScore: 25,
    players: 29
  },
  {
    name: "Slot Machine",
    description: "Pull the lever and hope for matching symbols!",
    category: "Luck",
    emoji: "🎰",
    totalPlayed: 1890,
    players: 73
  },
  {
    name: "Word Salad",
    description: "Unscramble the mixed-up letters to find the hidden word.",
    category: "Puzzle",
    emoji: "🔤",
    totalPlayed: 1120,
    topScore: 12,
    players: 48
  },
  {
    name: "Memory Game",
    description: "Remember the sequence of emojis and repeat it back.",
    category: "Memory",
    emoji: "🧠",
    totalPlayed: 780,
    topScore: 8,
    players: 35
  },
  {
    name: "Reaction Test",
    description: "Test how fast you can react to the green light!",
    category: "Speed",
    emoji: "⚡",
    totalPlayed: 1340,
    topScore: 180,
    players: 56
  },
  {
    name: "Trivia Quiz",
    description: "Answer general knowledge questions and learn new facts.",
    category: "Education",
    emoji: "🧐",
    totalPlayed: 920,
    topScore: 18,
    players: 42
  },
  {
    name: "Hangman",
    description: "Guess the word letter by letter before the drawing is complete.",
    category: "Puzzle",
    emoji: "🎪",
    totalPlayed: 1450,
    topScore: 6,
    players: 61
  },
  {
    name: "Riddle Challenge",
    description: "Solve brain-teasing riddles and puzzles.",
    category: "Puzzle",
    emoji: "🤔",
    totalPlayed: 650,
    topScore: 10,
    players: 28
  },
  {
    name: "Emoji Guess",
    description: "Guess the movie, song, or phrase from emoji clues.",
    category: "Fun",
    emoji: "😄",
    totalPlayed: 1180,
    topScore: 14,
    players: 49
  },
  {
    name: "Tic Tac Toe",
    description: "Classic 3x3 grid game against the bot.",
    category: "Strategy",
    emoji: "❌",
    totalPlayed: 2250,
    topScore: 12,
    players: 78
  },
  {
    name: "Blackjack",
    description: "Try to get as close to 21 as possible without going over.",
    category: "Card",
    emoji: "🃏",
    totalPlayed: 1680,
    topScore: 21,
    players: 64
  },
  {
    name: "Roulette",
    description: "Place your bets and spin the wheel of fortune!",
    category: "Luck",
    emoji: "🎡",
    totalPlayed: 1420,
    players: 58
  },
  {
    name: "Lottery",
    description: "Buy tickets and hope your numbers are drawn!",
    category: "Luck",
    emoji: "🎫",
    totalPlayed: 890,
    players: 43
  },
  {
    name: "Treasure Hunt",
    description: "Search for hidden treasures in mysterious locations.",
    category: "Adventure",
    emoji: "🗺️",
    totalPlayed: 760,
    topScore: 5,
    players: 32
  },
  {
    name: "Player Duel",
    description: "Challenge another player to a one-on-one duel!",
    category: "PvP",
    emoji: "⚔️",
    totalPlayed: 540,
    topScore: 8,
    players: 26
  }
];

const categories = ["All", "Luck", "Strategy", "Puzzle", "Fun", "Education", "Memory", "Speed", "Card", "Adventure", "PvP"];

export default function Games() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredGames = games.filter(game => {
    const matchesSearch = game.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         game.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "All" || game.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const totalPlays = games.reduce((sum, game) => sum + game.totalPlayed, 0);
  const totalPlayers = Math.max(...games.map(g => g.players));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Games</h1>
        <p className="text-gray-600 dark:text-gray-300">
          Explore all {games.length} mini-games available in your Discord bot
        </p>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-300">
              Total Games
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">{games.length}</div>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-300">
              Total Plays
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">
              {totalPlays.toLocaleString()}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-300">
              Active Players
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">{totalPlayers}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-gray-900 dark:text-white">
            <Filter className="h-5 w-5" />
            <span>Filters</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search games..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600"
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Badge
                key={category}
                variant={selectedCategory === category ? "default" : "secondary"}
                className="cursor-pointer hover:bg-blue-600 hover:text-white transition-colors"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Games Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredGames.map((game) => (
          <GameCard key={game.name} {...game} />
        ))}
      </div>

      {filteredGames.length === 0 && (
        <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
          <CardContent className="text-center py-12">
            <p className="text-gray-500 dark:text-gray-400">
              No games found matching your search criteria.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
