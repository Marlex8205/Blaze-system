import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Settings as SettingsIcon, Bot, Database, Coins, MessageSquare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { BotConfig, Quote } from "@shared/schema";

export default function Settings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [newQuote, setNewQuote] = useState({ content: "", author: "" });
  const [botSettings, setBotSettings] = useState({
    prefix: "!",
    startingCoins: "1000",
    dailyCoins: "100",
    levelUpBonus: "50"
  });

  const { data: quotes, isLoading: quotesLoading } = useQuery<Quote[]>({
    queryKey: ["/api/quotes"],
  });

  const { data: configs } = useQuery<BotConfig[]>({
    queryKey: ["/api/bot-config"],
  });

  const addQuoteMutation = useMutation({
    mutationFn: async (quote: { content: string; author: string; addedBy: string }) => {
      return apiRequest("POST", "/api/quotes", quote);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quotes"] });
      setNewQuote({ content: "", author: "" });
      toast({
        title: "Quote Added",
        description: "The quote has been successfully added to the collection.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add quote. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteQuoteMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/quotes/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quotes"] });
      toast({
        title: "Quote Deleted",
        description: "The quote has been removed from the collection.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete quote. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateConfigMutation = useMutation({
    mutationFn: async (config: { key: string; value: string }) => {
      return apiRequest("POST", "/api/bot-config", config);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bot-config"] });
      toast({
        title: "Settings Updated",
        description: "Bot configuration has been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update settings. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAddQuote = () => {
    if (!newQuote.content.trim()) {
      toast({
        title: "Error",
        description: "Quote content cannot be empty.",
        variant: "destructive",
      });
      return;
    }

    addQuoteMutation.mutate({
      content: newQuote.content,
      author: newQuote.author || "Unknown",
      addedBy: "Admin Dashboard"
    });
  };

  const handleUpdateConfig = (key: string, value: string) => {
    updateConfigMutation.mutate({ key, value });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Settings</h1>
        <p className="text-gray-600 dark:text-gray-300">
          Configure your Discord bot's behavior and manage content
        </p>
      </div>

      {/* Bot Configuration */}
      <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-gray-900 dark:text-white">
            <Bot className="h-5 w-5" />
            <span>Bot Configuration</span>
          </CardTitle>
          <CardDescription className="text-gray-600 dark:text-gray-300">
            Basic bot settings and behavior
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="prefix" className="text-gray-700 dark:text-gray-300">
                Command Prefix
              </Label>
              <Input
                id="prefix"
                value={botSettings.prefix}
                onChange={(e) => setBotSettings({ ...botSettings, prefix: e.target.value })}
                className="bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600"
              />
              <p className="text-xs text-gray-500 dark:text-gray-400">
                The prefix used for text commands (slash commands don't need this)
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="startingCoins" className="text-gray-700 dark:text-gray-300">
                Starting Coins
              </Label>
              <Input
                id="startingCoins"
                type="number"
                value={botSettings.startingCoins}
                onChange={(e) => setBotSettings({ ...botSettings, startingCoins: e.target.value })}
                className="bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600"
              />
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Initial coins given to new users
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="dailyCoins" className="text-gray-700 dark:text-gray-300">
                Daily Coins Reward
              </Label>
              <Input
                id="dailyCoins"
                type="number"
                value={botSettings.dailyCoins}
                onChange={(e) => setBotSettings({ ...botSettings, dailyCoins: e.target.value })}
                className="bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600"
              />
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Coins given for daily check-in
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="levelUpBonus" className="text-gray-700 dark:text-gray-300">
                Level Up Bonus
              </Label>
              <Input
                id="levelUpBonus"
                type="number"
                value={botSettings.levelUpBonus}
                onChange={(e) => setBotSettings({ ...botSettings, levelUpBonus: e.target.value })}
                className="bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600"
              />
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Coins awarded when leveling up
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white">Game Settings</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-gray-700 dark:text-gray-300">Enable Economy System</Label>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Allow users to earn and spend coins
                  </p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-gray-700 dark:text-gray-300">Enable Leaderboards</Label>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Show user rankings and statistics
                  </p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-gray-700 dark:text-gray-300">Daily Rewards</Label>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Give daily coin bonuses to active users
                  </p>
                </div>
                <Switch defaultChecked />
              </div>
            </div>
          </div>

          <Button 
            onClick={() => {
              Object.entries(botSettings).forEach(([key, value]) => {
                handleUpdateConfig(key, value);
              });
            }}
            className="w-full"
          >
            Save Bot Configuration
          </Button>
        </CardContent>
      </Card>

      {/* Quote Management */}
      <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-gray-900 dark:text-white">
            <MessageSquare className="h-5 w-5" />
            <span>Quote Management</span>
          </CardTitle>
          <CardDescription className="text-gray-600 dark:text-gray-300">
            Manage quotes used by the /quote command
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white">Add New Quote</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="quoteContent" className="text-gray-700 dark:text-gray-300">
                  Quote Content *
                </Label>
                <Textarea
                  id="quoteContent"
                  placeholder="Enter the quote text..."
                  value={newQuote.content}
                  onChange={(e) => setNewQuote({ ...newQuote, content: e.target.value })}
                  className="bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600"
                  rows={3}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="quoteAuthor" className="text-gray-700 dark:text-gray-300">
                  Author (Optional)
                </Label>
                <Input
                  id="quoteAuthor"
                  placeholder="Quote author..."
                  value={newQuote.author}
                  onChange={(e) => setNewQuote({ ...newQuote, author: e.target.value })}
                  className="bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600"
                />
              </div>
              
              <Button 
                onClick={handleAddQuote}
                disabled={addQuoteMutation.isPending}
                className="w-full"
              >
                {addQuoteMutation.isPending ? "Adding..." : "Add Quote"}
              </Button>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">Existing Quotes</h3>
              <Badge variant="secondary" className="text-gray-600 dark:text-gray-300">
                {quotes?.length || 0} quotes
              </Badge>
            </div>
            
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {quotesLoading ? (
                <p className="text-gray-500 dark:text-gray-400">Loading quotes...</p>
              ) : quotes?.length === 0 ? (
                <p className="text-gray-500 dark:text-gray-400 text-center py-8">
                  No quotes added yet. Add your first quote above!
                </p>
              ) : (
                quotes?.map((quote) => (
                  <Card key={quote.id} className="bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-600">
                    <CardContent className="pt-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="text-gray-900 dark:text-white italic">
                            "{quote.content}"
                          </p>
                          {quote.author && (
                            <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">
                              — {quote.author}
                            </p>
                          )}
                          <p className="text-xs text-gray-400 mt-2">
                            Added by {quote.addedBy} on {new Date(quote.addedAt || new Date()).toLocaleDateString()}
                          </p>
                        </div>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => deleteQuoteMutation.mutate(quote.id)}
                          disabled={deleteQuoteMutation.isPending}
                        >
                          Delete
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Information */}
      <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-gray-900 dark:text-white">
            <Database className="h-5 w-5" />
            <span>System Information</span>
          </CardTitle>
          <CardDescription className="text-gray-600 dark:text-gray-300">
            Bot status and system details
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-300">Bot Version:</span>
                <span className="text-gray-900 dark:text-white">1.0.0</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-300">Discord.py Version:</span>
                <span className="text-gray-900 dark:text-white">2.3.2</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-300">Python Version:</span>
                <span className="text-gray-900 dark:text-white">3.11.0</span>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-300">Uptime:</span>
                <span className="text-gray-900 dark:text-white">24h 30m</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-300">Memory Usage:</span>
                <span className="text-gray-900 dark:text-white">45 MB</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-300">Active Games:</span>
                <span className="text-gray-900 dark:text-white">20</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
