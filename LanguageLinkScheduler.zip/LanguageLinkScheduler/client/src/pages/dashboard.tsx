import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bot, Users, Gamepad2, Activity, Clock, Server } from "lucide-react";
import { UserStats } from "@/components/user-stats";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { data: botStatus, isLoading: statusLoading } = useQuery({
    queryKey: ["/api/bot/status"],
  });

  const { data: topUsers, isLoading: usersLoading } = useQuery({
    queryKey: ["/api/discord-users/top?limit=5"],
  });

  const { data: allUsers } = useQuery({
    queryKey: ["/api/discord-users"],
  });

  const totalUsers = allUsers?.length || 0;

  if (statusLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-20" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
        <p className="text-gray-600 dark:text-gray-300">
          Overview of your Discord bot's performance and statistics
        </p>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-300">
              Bot Status
            </CardTitle>
            <Bot className="h-4 w-4 text-green-600 dark:text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">
              <Badge variant={botStatus?.online ? "default" : "destructive"}>
                {botStatus?.online ? "Online" : "Offline"}
              </Badge>
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-300">
              Uptime: {botStatus?.uptime || "0m"}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-300">
              Total Users
            </CardTitle>
            <Users className="h-4 w-4 text-blue-600 dark:text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">
              {totalUsers}
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-300">
              Registered players
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-300">
              Available Games
            </CardTitle>
            <Gamepad2 className="h-4 w-4 text-purple-600 dark:text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">
              {botStatus?.commands || 20}
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-300">
              Mini-games available
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-300">
              Servers
            </CardTitle>
            <Server className="h-4 w-4 text-orange-600 dark:text-orange-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">
              {botStatus?.servers || 1}
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-300">
              Connected servers
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-gray-900 dark:text-white">
              <Activity className="h-5 w-5" />
              <span>Recent Activity</span>
            </CardTitle>
            <CardDescription className="text-gray-600 dark:text-gray-300">
              Latest bot interactions and events
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-3 text-sm">
              <div className="h-2 w-2 bg-green-500 rounded-full"></div>
              <span className="text-gray-600 dark:text-gray-300">
                Bot started successfully
              </span>
              <span className="text-xs text-gray-400 ml-auto">2 hours ago</span>
            </div>
            <div className="flex items-center space-x-3 text-sm">
              <div className="h-2 w-2 bg-blue-500 rounded-full"></div>
              <span className="text-gray-600 dark:text-gray-300">
                New user registered
              </span>
              <span className="text-xs text-gray-400 ml-auto">3 hours ago</span>
            </div>
            <div className="flex items-center space-x-3 text-sm">
              <div className="h-2 w-2 bg-purple-500 rounded-full"></div>
              <span className="text-gray-600 dark:text-gray-300">
                Coinflip game played
              </span>
              <span className="text-xs text-gray-400 ml-auto">5 hours ago</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-gray-900 dark:text-white">
              <Clock className="h-5 w-5" />
              <span>System Info</span>
            </CardTitle>
            <CardDescription className="text-gray-600 dark:text-gray-300">
              Bot runtime information
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600 dark:text-gray-300">Last Restart:</span>
              <span className="text-gray-900 dark:text-white">
                {botStatus?.lastRestart ? new Date(botStatus.lastRestart).toLocaleString() : "Unknown"}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600 dark:text-gray-300">Python Version:</span>
              <span className="text-gray-900 dark:text-white">3.11.0</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600 dark:text-gray-300">Discord.py Version:</span>
              <span className="text-gray-900 dark:text-white">2.3.2</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600 dark:text-gray-300">Memory Usage:</span>
              <span className="text-gray-900 dark:text-white">45 MB</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top Users */}
      <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="text-gray-900 dark:text-white">Top Players</CardTitle>
          <CardDescription className="text-gray-600 dark:text-gray-300">
            Leading players by coins earned
          </CardDescription>
        </CardHeader>
        <CardContent>
          {usersLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <Skeleton key={i} className="h-24 w-full" />
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {topUsers?.map((user, index) => (
                <UserStats key={user.id} user={user} rank={index + 1} />
              ))}
              {(!topUsers || topUsers.length === 0) && (
                <p className="text-gray-500 dark:text-gray-400 text-center py-8">
                  No users found. Start using the bot to see player statistics!
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
