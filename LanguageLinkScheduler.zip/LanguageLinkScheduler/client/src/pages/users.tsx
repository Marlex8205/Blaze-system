import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { UserStats } from "@/components/user-stats";
import { Search, Users as UsersIcon, TrendingUp, Crown } from "lucide-react";
import { useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import type { DiscordUser } from "@shared/schema";

export default function Users() {
  const [searchTerm, setSearchTerm] = useState("");

  const { data: users, isLoading } = useQuery<DiscordUser[]>({
    queryKey: ["/api/discord-users"],
  });

  const filteredUsers = users?.filter(user =>
    user.username.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  const sortedUsers = filteredUsers.sort((a, b) => (b.coins || 0) - (a.coins || 0));

  const totalCoins = users?.reduce((sum, user) => sum + (user.coins || 0), 0) || 0;
  const totalGames = users?.reduce((sum, user) => sum + (user.gamesPlayed || 0), 0) || 0;
  const averageLevel = users?.length ? 
    Math.round(users.reduce((sum, user) => sum + (user.level || 1), 0) / users.length) : 0;

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Users</h1>
          <p className="text-gray-600 dark:text-gray-300">
            Manage and view Discord bot users
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-20" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16" />
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-32 w-full" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Users</h1>
        <p className="text-gray-600 dark:text-gray-300">
          Manage and view Discord bot users ({users?.length || 0} total)
        </p>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-300">
              Total Users
            </CardTitle>
            <UsersIcon className="h-4 w-4 text-blue-600 dark:text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">
              {users?.length || 0}
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-300">
              Registered players
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-300">
              Total Coins
            </CardTitle>
            <Crown className="h-4 w-4 text-yellow-600 dark:text-yellow-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">
              {totalCoins.toLocaleString()}
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-300">
              Economy circulation
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-300">
              Games Played
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600 dark:text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">
              {totalGames.toLocaleString()}
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-300">
              Total activity
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-300">
              Average Level
            </CardTitle>
            <Badge variant="secondary" className="h-4 px-2 text-xs">
              LVL
            </Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">
              {averageLevel}
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-300">
              Player progression
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-gray-900 dark:text-white">
            <Search className="h-5 w-5" />
            <span>Search Users</span>
          </CardTitle>
          <CardDescription className="text-gray-600 dark:text-gray-300">
            Find users by username
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search by username..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600"
            />
          </div>
        </CardContent>
      </Card>

      {/* Users List */}
      <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="text-gray-900 dark:text-white">
            User Leaderboard
          </CardTitle>
          <CardDescription className="text-gray-600 dark:text-gray-300">
            Users ranked by coins earned
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {sortedUsers.map((user, index) => (
              <UserStats key={user.id} user={user} rank={index + 1} />
            ))}
            
            {sortedUsers.length === 0 && !isLoading && (
              <div className="text-center py-12">
                <UsersIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 dark:text-gray-400 text-lg">
                  {searchTerm ? "No users found matching your search." : "No users registered yet."}
                </p>
                <p className="text-gray-400 dark:text-gray-500 text-sm mt-2">
                  {searchTerm ? "Try a different search term." : "Users will appear here once they start using the bot."}
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
