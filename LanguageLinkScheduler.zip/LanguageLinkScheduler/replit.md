# Discord Mini-Games Bot

## Overview

This is a full-stack Discord bot application featuring 20+ mini-games, an economy system, and utility features. The project combines a Python Discord bot backend with a modern React/TypeScript web dashboard for management and analytics.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Hybrid Architecture
The application uses a dual-language architecture:
- **Python Discord Bot**: Handles Discord interactions and game logic using discord.py
- **Node.js Web Application**: Provides a management dashboard built with React and Express
- **Shared Database**: PostgreSQL database accessed by both Python and Node.js components

### Technology Stack
- **Frontend**: React 18, TypeScript, Tailwind CSS, shadcn/ui components
- **Backend API**: Express.js with TypeScript
- **Discord Bot**: Python with discord.py, Flask for keep-alive
- **Database**: PostgreSQL with Drizzle ORM
- **Build Tools**: Vite for frontend bundling, esbuild for backend
- **Deployment**: Replit with 24/7 hosting support

## Key Components

### Frontend (React Dashboard)
- **Location**: `client/` directory
- **Purpose**: Web dashboard for bot management and analytics
- **Pages**: Dashboard, Games, Users, Settings
- **Components**: Reusable UI components using shadcn/ui
- **State Management**: TanStack Query for server state
- **Routing**: Wouter for lightweight routing

### Backend API (Express.js)
- **Location**: `server/` directory
- **Purpose**: REST API for dashboard data and bot management
- **Routes**: Discord users, game stats, quotes, reminders
- **Database**: Drizzle ORM with PostgreSQL
- **Features**: CRUD operations for all bot data

### Discord Bot (Python)
- **Purpose**: Discord interactions and game logic
- **Games**: 20+ mini-games including coinflip, dice, trivia, etc.
- **Economy**: Coin system with daily rewards and leveling
- **Utilities**: Translation, reminders, quotes
- **Keep-alive**: Flask server for 24/7 hosting

### Shared Schema
- **Location**: `shared/schema.ts`
- **Purpose**: Database schema definitions shared between components
- **Tables**: Discord users, game stats, quotes, reminders, bot config
- **Validation**: Zod schemas for type safety

## Data Flow

### Bot → Database
1. Discord bot processes user interactions
2. Updates user stats, game results, economy data
3. Stores data in PostgreSQL database

### Dashboard → API → Database
1. React dashboard makes API requests
2. Express server processes requests
3. Drizzle ORM handles database operations
4. Data returned to dashboard for display

### Real-time Sync
- Both Python bot and Node.js API access same database
- Dashboard shows live bot data and statistics
- Changes in dashboard can affect bot behavior

## External Dependencies

### Discord Integration
- **discord.py**: Python library for Discord bot functionality
- **Discord Developer Portal**: Bot token and permissions

### Database
- **PostgreSQL**: Primary database (Replit provides instance)
- **Drizzle**: ORM for type-safe database operations

### Optional APIs
- **OpenAI API**: For future AI features
- **Google Translate API**: For translation features

### UI/Styling
- **Tailwind CSS**: Utility-first CSS framework
- **shadcn/ui**: Pre-built React components
- **Radix UI**: Headless UI primitives

## Deployment Strategy

### Replit Environment
- **Target**: Autoscale deployment on Replit
- **Modules**: Node.js 20, Python 3.11, PostgreSQL 16
- **Port**: Application runs on port 5000, exposed as port 80

### Build Process
1. **Development**: `npm run dev` - Runs both frontend and backend in development mode
2. **Production Build**: 
   - `vite build` - Builds React frontend
   - `esbuild` - Bundles Express backend
3. **Start**: `npm run start` - Runs production build

### Keep-Alive Strategy
- Python Flask server (`keep_alive.py`) maintains 24/7 uptime
- Web interface shows bot status and statistics
- Essential for free hosting platforms

### Environment Configuration
- Environment variables in `.env` file
- Database URL automatically provided by Replit
- Bot tokens and API keys configurable
- Admin user IDs for permissions

### Development Workflow
- TypeScript throughout for type safety
- Hot reloading in development
- Shared schema ensures data consistency
- Modular component architecture for maintainability