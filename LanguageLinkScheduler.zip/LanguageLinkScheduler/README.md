# 🤖 Discord Mini-Games Bot

A comprehensive Discord bot featuring 20+ mini-games, economy system, and utility features with 24/7 hosting capabilities.

## 🎮 Features

### 🎲 Mini-Games (20+)
- **🪙 Coinflip** - Test your luck with coin tosses
- **🎲 Dice Roll** - Roll virtual dice with rewards
- **✂️ Rock Paper Scissors** - Classic strategy game
- **🔢 Number Guessing** - Guess the secret number
- **🎱 Magic 8-Ball** - Get mystical answers to questions
- **🧮 Math Quiz** - Test your arithmetic skills
- **🎰 Slot Machine** - Try your luck at the slots
- **🔤 Word Salad** - Unscramble mixed-up words
- **🧠 Memory Game** - Remember emoji sequences
- **⚡ Reaction Test** - Test your reflexes
- **🧐 Trivia Quiz** - Answer knowledge questions
- **🎪 Hangman** - Classic word guessing game
- **🤔 Riddles** - Solve brain-teasing riddles
- **😄 Emoji Guess** - Decode emoji puzzles
- **❌ Tic Tac Toe** - Strategic grid game against bot
- **🃏 Blackjack** - Casino-style card game
- **🎡 Roulette** - Spin the wheel and place bets
- **🎫 Lottery** - Buy tickets for big prizes
- **🗺️ Treasure Hunt** - Search for hidden treasure
- **⚔️ Player Duel** - Challenge other players to combat

### 💰 Economy System
- **Coin Balance** - Earn and spend virtual coins
- **Daily Bonuses** - Claim rewards every 24 hours
- **Leveling System** - Gain XP and level up
- **Leaderboards** - Compete with other players
- **Game Statistics** - Track wins, losses, and performance

### 🛠️ Utility Features
- **🌍 Translation** - Multi-language text translation
- **⏰ Reminders** - Set personal reminders with DM notifications
- **💭 Quote Collection** - Add and view inspirational quotes
- **📊 Statistics** - Detailed game and user analytics
- **🔧 Admin Commands** - Bot management and configuration

## 🚀 Installation & Setup

### Prerequisites
- Python 3.8+
- Discord Bot Token
- SQLite3 (included with Python)

### 1. Clone the Repository
```bash
git clone <repository-url>
cd discord-minigames-bot
