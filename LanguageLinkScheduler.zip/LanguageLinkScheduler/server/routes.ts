import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertDiscordUserSchema, insertGameStatSchema, insertQuoteSchema, insertReminderSchema, insertBotConfigSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Discord Users endpoints
  app.get("/api/discord-users", async (req, res) => {
    try {
      const users = await storage.getAllDiscordUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch discord users" });
    }
  });

  app.get("/api/discord-users/top", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const users = await storage.getTopDiscordUsers(limit);
      res.json(users);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch top discord users" });
    }
  });

  app.get("/api/discord-users/:discordId", async (req, res) => {
    try {
      const user = await storage.getDiscordUser(req.params.discordId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch discord user" });
    }
  });

  app.post("/api/discord-users", async (req, res) => {
    try {
      const userData = insertDiscordUserSchema.parse(req.body);
      const user = await storage.createDiscordUser(userData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid user data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create discord user" });
    }
  });

  // Game Stats endpoints
  app.get("/api/game-stats/:userId", async (req, res) => {
    try {
      const gameName = req.query.game as string;
      const stats = await storage.getGameStats(req.params.userId, gameName);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch game stats" });
    }
  });

  app.get("/api/game-stats/top/:gameName", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const stats = await storage.getTopGameStats(req.params.gameName, limit);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch top game stats" });
    }
  });

  app.post("/api/game-stats/:userId/:gameName", async (req, res) => {
    try {
      const statsData = insertGameStatSchema.parse(req.body);
      const stats = await storage.updateGameStats(req.params.userId, req.params.gameName, statsData);
      res.json(stats);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid stats data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to update game stats" });
    }
  });

  // Quotes endpoints
  app.get("/api/quotes", async (req, res) => {
    try {
      const quotes = await storage.getQuotes();
      res.json(quotes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch quotes" });
    }
  });

  app.get("/api/quotes/random", async (req, res) => {
    try {
      const quote = await storage.getRandomQuote();
      if (!quote) {
        return res.status(404).json({ error: "No quotes found" });
      }
      res.json(quote);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch random quote" });
    }
  });

  app.post("/api/quotes", async (req, res) => {
    try {
      const quoteData = insertQuoteSchema.parse(req.body);
      const quote = await storage.createQuote(quoteData);
      res.status(201).json(quote);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid quote data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create quote" });
    }
  });

  app.delete("/api/quotes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteQuote(id);
      if (!deleted) {
        return res.status(404).json({ error: "Quote not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete quote" });
    }
  });

  // Reminders endpoints
  app.get("/api/reminders/:userId", async (req, res) => {
    try {
      const reminders = await storage.getReminders(req.params.userId);
      res.json(reminders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch reminders" });
    }
  });

  app.post("/api/reminders", async (req, res) => {
    try {
      const reminderData = insertReminderSchema.parse(req.body);
      const reminder = await storage.createReminder(reminderData);
      res.status(201).json(reminder);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid reminder data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create reminder" });
    }
  });

  // Bot Config endpoints
  app.get("/api/bot-config", async (req, res) => {
    try {
      const configs = await storage.getAllBotConfigs();
      res.json(configs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch bot config" });
    }
  });

  app.get("/api/bot-config/:key", async (req, res) => {
    try {
      const config = await storage.getBotConfig(req.params.key);
      if (!config) {
        return res.status(404).json({ error: "Config not found" });
      }
      res.json(config);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch bot config" });
    }
  });

  app.post("/api/bot-config", async (req, res) => {
    try {
      const configData = insertBotConfigSchema.parse(req.body);
      const config = await storage.setBotConfig(configData);
      res.json(config);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid config data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to set bot config" });
    }
  });

  // Bot status endpoint
  app.get("/api/bot/status", async (req, res) => {
    try {
      // In a real implementation, this would check if the bot is running
      const status = {
        online: true,
        uptime: "24h 30m",
        servers: 1,
        users: (await storage.getAllDiscordUsers()).length,
        commands: 20,
        lastRestart: new Date().toISOString()
      };
      res.json(status);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch bot status" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
