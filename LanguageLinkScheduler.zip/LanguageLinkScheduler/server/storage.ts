import { 
  users, 
  discordUsers, 
  gameStats, 
  quotes, 
  reminders, 
  botConfig,
  type User, 
  type InsertUser,
  type DiscordUser,
  type InsertDiscordUser,
  type GameStat,
  type InsertGameStat,
  type Quote,
  type InsertQuote,
  type Reminder,
  type InsertReminder,
  type BotConfig,
  type InsertBotConfig
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Discord User methods
  getDiscordUser(discordId: string): Promise<DiscordUser | undefined>;
  createDiscordUser(user: InsertDiscordUser): Promise<DiscordUser>;
  updateDiscordUser(discordId: string, updates: Partial<DiscordUser>): Promise<DiscordUser | undefined>;
  getTopDiscordUsers(limit: number): Promise<DiscordUser[]>;
  getAllDiscordUsers(): Promise<DiscordUser[]>;
  
  // Game Stats methods
  getGameStats(userId: string, gameName?: string): Promise<GameStat[]>;
  updateGameStats(userId: string, gameName: string, stats: Partial<InsertGameStat>): Promise<GameStat>;
  getTopGameStats(gameName: string, limit: number): Promise<GameStat[]>;
  
  // Quote methods
  getQuotes(): Promise<Quote[]>;
  createQuote(quote: InsertQuote): Promise<Quote>;
  deleteQuote(id: number): Promise<boolean>;
  getRandomQuote(): Promise<Quote | undefined>;
  
  // Reminder methods
  getReminders(userId: string): Promise<Reminder[]>;
  createReminder(reminder: InsertReminder): Promise<Reminder>;
  markReminderComplete(id: number): Promise<boolean>;
  getPendingReminders(): Promise<Reminder[]>;
  
  // Bot Config methods
  getBotConfig(key: string): Promise<BotConfig | undefined>;
  setBotConfig(config: InsertBotConfig): Promise<BotConfig>;
  getAllBotConfigs(): Promise<BotConfig[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private discordUsers: Map<string, DiscordUser>;
  private gameStats: Map<string, GameStat>;
  private quotes: Map<number, Quote>;
  private reminders: Map<number, Reminder>;
  private botConfigs: Map<string, BotConfig>;
  
  private currentUserId: number;
  private currentDiscordUserId: number;
  private currentGameStatId: number;
  private currentQuoteId: number;
  private currentReminderId: number;
  private currentBotConfigId: number;

  constructor() {
    this.users = new Map();
    this.discordUsers = new Map();
    this.gameStats = new Map();
    this.quotes = new Map();
    this.reminders = new Map();
    this.botConfigs = new Map();
    
    this.currentUserId = 1;
    this.currentDiscordUserId = 1;
    this.currentGameStatId = 1;
    this.currentQuoteId = 1;
    this.currentReminderId = 1;
    this.currentBotConfigId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getDiscordUser(discordId: string): Promise<DiscordUser | undefined> {
    return this.discordUsers.get(discordId);
  }

  async createDiscordUser(insertUser: InsertDiscordUser): Promise<DiscordUser> {
    const id = this.currentDiscordUserId++;
    const user: DiscordUser = { 
      ...insertUser, 
      id,
      coins: insertUser.coins || 1000,
      level: insertUser.level || 1,
      experience: insertUser.experience || 0,
      gamesPlayed: insertUser.gamesPlayed || 0,
      gamesWon: insertUser.gamesWon || 0,
      joinedAt: new Date()
    };
    this.discordUsers.set(insertUser.discordId, user);
    return user;
  }

  async updateDiscordUser(discordId: string, updates: Partial<DiscordUser>): Promise<DiscordUser | undefined> {
    const user = this.discordUsers.get(discordId);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.discordUsers.set(discordId, updatedUser);
    return updatedUser;
  }

  async getTopDiscordUsers(limit: number): Promise<DiscordUser[]> {
    return Array.from(this.discordUsers.values())
      .sort((a, b) => (b.coins || 0) - (a.coins || 0))
      .slice(0, limit);
  }

  async getAllDiscordUsers(): Promise<DiscordUser[]> {
    return Array.from(this.discordUsers.values());
  }

  async getGameStats(userId: string, gameName?: string): Promise<GameStat[]> {
    const stats = Array.from(this.gameStats.values()).filter(stat => stat.userId === userId);
    if (gameName) {
      return stats.filter(stat => stat.gameName === gameName);
    }
    return stats;
  }

  async updateGameStats(userId: string, gameName: string, stats: Partial<InsertGameStat>): Promise<GameStat> {
    const key = `${userId}-${gameName}`;
    const existing = this.gameStats.get(key);
    
    if (existing) {
      const updated = { ...existing, ...stats, lastPlayed: new Date() };
      this.gameStats.set(key, updated);
      return updated;
    } else {
      const id = this.currentGameStatId++;
      const newStat: GameStat = {
        id,
        userId,
        gameName,
        played: stats.played || 0,
        won: stats.won || 0,
        totalScore: stats.totalScore || 0,
        bestScore: stats.bestScore || 0,
        lastPlayed: new Date()
      };
      this.gameStats.set(key, newStat);
      return newStat;
    }
  }

  async getTopGameStats(gameName: string, limit: number): Promise<GameStat[]> {
    return Array.from(this.gameStats.values())
      .filter(stat => stat.gameName === gameName)
      .sort((a, b) => (b.bestScore || 0) - (a.bestScore || 0))
      .slice(0, limit);
  }

  async getQuotes(): Promise<Quote[]> {
    return Array.from(this.quotes.values());
  }

  async createQuote(insertQuote: InsertQuote): Promise<Quote> {
    const id = this.currentQuoteId++;
    const quote: Quote = { ...insertQuote, id, addedAt: new Date() };
    this.quotes.set(id, quote);
    return quote;
  }

  async deleteQuote(id: number): Promise<boolean> {
    return this.quotes.delete(id);
  }

  async getRandomQuote(): Promise<Quote | undefined> {
    const quotes = Array.from(this.quotes.values());
    if (quotes.length === 0) return undefined;
    return quotes[Math.floor(Math.random() * quotes.length)];
  }

  async getReminders(userId: string): Promise<Reminder[]> {
    return Array.from(this.reminders.values()).filter(reminder => reminder.userId === userId);
  }

  async createReminder(insertReminder: InsertReminder): Promise<Reminder> {
    const id = this.currentReminderId++;
    const reminder: Reminder = { 
      ...insertReminder, 
      id, 
      completed: false, 
      createdAt: new Date() 
    };
    this.reminders.set(id, reminder);
    return reminder;
  }

  async markReminderComplete(id: number): Promise<boolean> {
    const reminder = this.reminders.get(id);
    if (!reminder) return false;
    
    reminder.completed = true;
    this.reminders.set(id, reminder);
    return true;
  }

  async getPendingReminders(): Promise<Reminder[]> {
    const now = new Date();
    return Array.from(this.reminders.values()).filter(
      reminder => !reminder.completed && reminder.scheduledFor <= now
    );
  }

  async getBotConfig(key: string): Promise<BotConfig | undefined> {
    return this.botConfigs.get(key);
  }

  async setBotConfig(insertConfig: InsertBotConfig): Promise<BotConfig> {
    const existing = this.botConfigs.get(insertConfig.key);
    if (existing) {
      const updated = { ...existing, ...insertConfig, updatedAt: new Date() };
      this.botConfigs.set(insertConfig.key, updated);
      return updated;
    } else {
      const id = this.currentBotConfigId++;
      const config: BotConfig = { 
        ...insertConfig, 
        id, 
        updatedAt: new Date() 
      };
      this.botConfigs.set(insertConfig.key, config);
      return config;
    }
  }

  async getAllBotConfigs(): Promise<BotConfig[]> {
    return Array.from(this.botConfigs.values());
  }
}

export const storage = new MemStorage();
