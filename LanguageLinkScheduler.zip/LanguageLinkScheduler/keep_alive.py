"""
Keep Alive Web Server for 24/7 Bot Hosting
This creates a simple web server to keep the bot alive on free hosting platforms
"""

from flask import Flask, jsonify, render_template_string
import threading
import time
import os
from datetime import datetime
import sqlite3

app = Flask(__name__)

# HTML template for the status page
STATUS_PAGE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discord Bot Status</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
            min-height: 100vh;
            color: white;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 30px;
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }
        .status-badge {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: bold;
            margin: 10px 0;
        }
        .online { background: #2ecc71; }
        .offline { background: #e74c3c; }
        .stat-card {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 20px;
            margin: 15px 0;
            border-left: 4px solid #3498db;
        }
        .stat-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .emoji { font-size: 1.5em; margin-right: 10px; }
        h1 { text-align: center; margin-bottom: 30px; }
        .last-updated { text-align: center; margin-top: 20px; opacity: 0.8; }
        .feature-list {
            list-style: none;
            padding: 0;
        }
        .feature-list li {
            padding: 8px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .feature-list li:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🤖 Discord Bot Status Dashboard</h1>
        
        <div class="stat-card">
            <h2><span class="emoji">⚡</span>Bot Status</h2>
            <div class="status-badge {{ status_class }}">{{ status }}</div>
            <p>Uptime: {{ uptime }}</p>
        </div>
        
        <div class="stat-grid">
            <div class="stat-card">
                <h3><span class="emoji">👥</span>Users</h3>
                <p style="font-size: 2em; margin: 0;">{{ total_users }}</p>
                <small>Registered players</small>
            </div>
            
            <div class="stat-card">
                <h3><span class="emoji">🎮</span>Games</h3>
                <p style="font-size: 2em; margin: 0;">{{ total_games }}</p>
                <small>Games played</small>
            </div>
            
            <div class="stat-card">
                <h3><span class="emoji">💰</span>Economy</h3>
                <p style="font-size: 2em; margin: 0;">{{ total_coins }}</p>
                <small>Coins in circulation</small>
            </div>
            
            <div class="stat-card">
                <h3><span class="emoji">💭</span>Quotes</h3>
                <p style="font-size: 2em; margin: 0;">{{ total_quotes }}</p>
                <small>Inspirational quotes</small>
            </div>
        </div>
        
        <div class="stat-card">
            <h2><span class="emoji">🎲</span>Available Games</h2>
            <ul class="feature-list">
                <li>🪙 Coinflip - Test your luck with coin tosses</li>
                <li>🎲 Dice Roll - Roll virtual dice</li>
                <li>✂️ Rock Paper Scissors - Classic strategy game</li>
                <li>🔢 Number Guessing - Guess the secret number</li>
                <li>🎱 Magic 8-Ball - Get mystical answers</li>
                <li>🧮 Math Quiz - Test your arithmetic skills</li>
                <li>🎰 Slot Machine - Try your luck at slots</li>
                <li>🔤 Word Salad - Unscramble words</li>
                <li>🧠 Memory Game - Remember emoji sequences</li>
                <li>⚡ Reaction Test - Test your reflexes</li>
                <li>🧐 Trivia Quiz - Answer knowledge questions</li>
                <li>🎪 Hangman - Classic word guessing</li>
                <li>🤔 Riddles - Solve brain teasers</li>
                <li>😄 Emoji Guess - Decode emoji puzzles</li>
                <li>❌ Tic Tac Toe - Strategic grid game</li>
                <li>🃏 Blackjack - Casino card game</li>
                <li>🎡 Roulette - Spin the wheel</li>
                <li>🎫 Lottery - Buy tickets for prizes</li>
                <li>🗺️ Treasure Hunt - Search for hidden treasure</li>
                <li>⚔️ Player Duel - Challenge other players</li>
            </ul>
        </div>
        
        <div class="stat-card">
            <h2><span class="emoji">🛠️</span>Utility Features</h2>
            <ul class="feature-list">
                <li>💰 Economy System - Earn and spend coins</li>
                <li>🏆 Leaderboards - Compete with other players</li>
                <li>📊 Statistics - Track your performance</li>
                <li>🌍 Translation - Multi-language support</li>
                <li>⏰ Reminders - Set personal reminders</li>
                <li>💭 Quotes - Inspirational quote collection</li>
                <li>🎁 Daily Bonuses - Claim daily rewards</li>
                <li>⭐ Leveling System - Gain XP and level up</li>
            </ul>
        </div>
        
        <div class="last-updated">
            Last updated: {{ timestamp }}
        </div>
    </div>
</body>
</html>
"""

def get_bot_stats():
    """Get bot statistics from database"""
    try:
        if not os.path.exists("bot_data.db"):
            return {
                'total_users': 0,
                'total_games': 0,
                'total_coins': 0,
                'total_quotes': 0
            }
        
        conn = sqlite3.connect("bot_data.db")
        cursor = conn.cursor()
        
        # Get user count
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]
        
        # Get total games played
        cursor.execute("SELECT SUM(games_played) FROM users")
        result = cursor.fetchone()[0]
        total_games = result if result else 0
        
        # Get total coins
        cursor.execute("SELECT SUM(coins) FROM users")
        result = cursor.fetchone()[0]
        total_coins = result if result else 0
        
        # Get quote count
        cursor.execute("SELECT COUNT(*) FROM quotes")
        total_quotes = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            'total_users': total_users,
            'total_games': total_games,
            'total_coins': total_coins,
            'total_quotes': total_quotes
        }
    except Exception as e:
        print(f"Error getting bot stats: {e}")
        return {
            'total_users': 0,
            'total_games': 0,
            'total_coins': 0,
            'total_quotes': 0
        }

# Global variables for tracking
start_time = time.time()
bot_online = False

@app.route('/')
def status_page():
    """Main status page"""
    global start_time, bot_online
    
    # Calculate uptime
    uptime_seconds = time.time() - start_time
    uptime_hours = int(uptime_seconds // 3600)
    uptime_minutes = int((uptime_seconds % 3600) // 60)
    uptime_str = f"{uptime_hours}h {uptime_minutes}m"
    
    # Get bot statistics
    stats = get_bot_stats()
    
    # Determine bot status
    status = "🟢 Online" if bot_online else "🔴 Starting..."
    status_class = "online" if bot_online else "offline"
    
    return render_template_string(STATUS_PAGE,
        status=status,
        status_class=status_class,
        uptime=uptime_str,
        total_users=stats['total_users'],
        total_games=stats['total_games'],
        total_coins=f"{stats['total_coins']:,}",
        total_quotes=stats['total_quotes'],
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")
    )

@app.route('/api/status')
def api_status():
    """API endpoint for bot status"""
    global start_time, bot_online
    
    uptime_seconds = time.time() - start_time
    stats = get_bot_stats()
    
    return jsonify({
        'status': 'online' if bot_online else 'starting',
        'uptime_seconds': int(uptime_seconds),
        'stats': stats,
        'timestamp': datetime.now().isoformat(),
        'games_available': 20,
        'features': [
            'Economy System',
            'Leaderboards',
            'Translation',
            'Reminders',
            'Quote Collection',
            'Daily Bonuses',
            'Leveling System'
        ]
    })

@app.route('/api/ping')
def ping():
    """Simple ping endpoint for monitoring services"""
    return jsonify({
        'status': 'ok',
        'timestamp': datetime.now().isoformat(),
        'message': 'Bot is running'
    })

@app.route('/health')
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'uptime': int(time.time() - start_time),
        'bot_online': bot_online
    })

def set_bot_status(online: bool):
    """Update bot online status"""
    global bot_online
    bot_online = online

def keep_alive():
    """Run the web server"""
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port, debug=False)

def start_keep_alive():
    """Start keep alive server in a separate thread"""
    print("🌐 Starting keep-alive web server...")
    thread = threading.Thread(target=keep_alive)
    thread.daemon = True
    thread.start()
    print(f"✅ Keep-alive server started on port 8080")

if __name__ == "__main__":
    start_keep_alive()
    # Keep the main thread alive
    while True:
        time.sleep(1)
